//
//  Calender.swift
//  Calender
//
//  Created by swathi m on 2/17/16.
//  Copyright © 2016 swathi m. All rights reserved.
//

import Cocoa

class Calender: NSWindowController {
    
    var calenderViewSelection : NSDate?
 
    @IBOutlet var calenderViewOutlet: NSDatePicker!
    
   
    
    @IBAction func todayButtonAction(sender: NSButton) {
         let todaysDate:NSDate = NSDate()
        if(calenderViewOutlet.dateValue.isGreaterThan(todaysDate)){
            print("33333333333")
        }
        
       
        print("today's date\(todaysDate)")
       
        calenderViewOutlet.dateValue = todaysDate
        
        var dataString = todaysDate
        var dateFormatter = NSDateFormatter()
        dateFormatter.dateFormat = "MM-dd-yyyy"
        dateFormatter.timeZone = NSTimeZone.localTimeZone()
//
        
        
    }
    @IBOutlet var todayButtonOutlet: NSButton!
    let date = NSDate()
    

    

   
    override var windowNibName : String? {
        return "Calender"
    }

    override func windowDidLoad() {
        super.windowDidLoad()
        

        // Implement this method to handle any initialization after your window controller's window has been loaded from its nib file.
    }
    
}
