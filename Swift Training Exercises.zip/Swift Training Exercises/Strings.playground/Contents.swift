//: Playground - noun: a place where people can play

import Cocoa

var mutablePlayground = "Hello,playground"
let playground = "Immutable Playground"
mutablePlayground += "!"
for c:Character in mutablePlayground.characters{
    print("\(c)")
}


var str = "\u{0061}"
print(str)

var strEmoji = "\u{1F60E}"
print(strEmoji)

let oneCoolDude = "\u{1F60E}"
let aAcute = "\u{0061}\u{0301}"

for scalar in playground.unicodeScalars{
    print("\(scalar.value)")
}
let aAcutePrecomposed = "\u{00E1}"
let b = (aAcute == aAcutePrecomposed)

print("aAcute: \(aAcute.characters.count) aAcutePrecomposed: \(aAcutePrecomposed.characters.count)")


//Finding the fifth character
let fromStart = playground.startIndex
let toPosition = 4
let end = fromStart.advancedBy(toPosition)
let fifthCharacter = playground[end]

//to grab the first five characters
let range = fromStart...end
print(playground[range]) //prints first five characters


//Assignment chapter 8 Strings
let a = "\u{68}\u{65}\u{49}\u{49}"
let fromStartUnicode = a.startIndex
let toPositionUnicode = 3
let endUnicode = fromStartUnicode.advancedBy(toPositionUnicode)
let rangeUnicode = fromStartUnicode...endUnicode
print(a[rangeUnicode])