//
//  DetailStatus+CoreDataProperties.swift
//  ReportTimeMacApp
//
//  Created by swathi m on 2/11/16.
//  Copyright © 2016 swathi m. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

import Foundation
import CoreData

extension DetailStatus {

    @NSManaged var detailPersonName: String?
    @NSManaged var detailWeekendDate: String?
    @NSManaged var businessUnit: String?
    @NSManaged var customerName: String?
    @NSManaged var projectName: String?
    @NSManaged var moduleName: String?
    @NSManaged var taskName: String?
    @NSManaged var duration: NSNumber?
    @NSManaged var detailDescription: String?
    @NSManaged var detailStatus: String?
    @NSManaged var dayCount: NSNumber?

}
