//
//  DetailStatus.swift
//  ReportTimeMacApp
//
//  Created by swathi m on 2/11/16.
//  Copyright © 2016 swathi m. All rights reserved.
//

import Foundation
import CoreData


class DetailStatus: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
