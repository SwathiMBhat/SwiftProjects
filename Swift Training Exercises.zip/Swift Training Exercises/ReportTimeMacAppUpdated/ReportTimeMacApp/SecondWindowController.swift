//
//  SecondWindowController.swift
//  ReportTimeMacApp
//
//  Created by swathi m on 2/4/16.
//  Copyright © 2016 swathi m. All rights reserved.
//

import Cocoa

class SecondWindowController: NSWindowController {
    
    @IBOutlet var abstractArrayControllerOutlet: NSArrayController!
    var coreData:CoreDataCommonFile?
    @IBAction func abstractSearchCloseButtonAction(sender: NSButton) {
        window?.close()
    }
  
    override func windowDidLoad() {
        super.windowDidLoad()
        
        coreData = CoreDataCommonFile()
        
        coreData!.insertData("swathi", weekendDate: "21-01-1345", status: "saved")
        abstractArrayControllerOutlet.addObjects(coreData!.fetchData())
//        coreData!.fetchData()
//        print("Hi")

        // Implement this method to handle any initialization after your window controller's window has been loaded from its nib file.
    }
        
}
