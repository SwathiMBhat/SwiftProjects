//
//  DetailWindowController.swift
//  ReportTimeMacApp
//
//  Created by swathi m on 2/4/16.
//  Copyright © 2016 swathi m. All rights reserved.
//

import Cocoa

class DetailWindowController: NSWindowController {
    @IBOutlet var detailArrayController: NSArrayController!
    var detailViewCoreData : CoreDataCommonFile?
    override func windowDidLoad() {
        super.windowDidLoad()
detailViewCoreData = CoreDataCommonFile()
        detailViewCoreData?.insertDetailData("Swathi", detailWeekendDate: "02-Feb-2016", businessUnit: "Bangalore Development Center", customerName: "Apple", projectName: "Time App", moduleName: "Mac", taskName: "SRS", duration:8.56, detailDescription: "Swift training", detailStatus: "Submitted", dayCount: 1)
        detailViewCoreData?.insertDetailData("swer", detailWeekendDate: "02-Feb-2016", businessUnit: "Bangalore Development Center", customerName: "Apple", projectName: "Time App", moduleName: "Mac", taskName: "SRS", duration:8.56, detailDescription: "Swift training", detailStatus: "Submitted", dayCount: 1)
        detailArrayController.addObjects(detailViewCoreData!.fetchDetailData())
        //detailViewCoreData?.fetchDetailData()
        // Implement this method to handle any initialization after your window controller's window has been loaded from its nib file.
    }
    
    @IBAction func detailWindowCloseButtonAction(sender: NSButton) {
        window?.close()
    }
    
    
    
    
    
    
    
    
    
    
}







