//
//  CalenderView.swift
//  CalenderCode
//
//  Created by swathi m on 2/19/16.
//  Copyright © 2016 swathi m. All rights reserved.
//

import Cocoa

class CalenderView: NSView {

    override func drawRect(dirtyRect: NSRect) {
        super.drawRect(dirtyRect)

        // Drawing code here.
    }
    
}
