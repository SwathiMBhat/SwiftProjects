//
//  AppDelegate.swift
//  CalenderCode
//
//  Created by swathi m on 2/19/16.
//  Copyright © 2016 swathi m. All rights reserved.
//

import Cocoa

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {

    //@IBOutlet weak var window: NSWindow!
 var calender : CalenderLayout?

    func applicationDidFinishLaunching(aNotification: NSNotification) {
        let calender = CalenderLayout()
        calender.showWindow(self)
        self.calender = calender
        // Insert code here to initialize your application
    }

    func applicationWillTerminate(aNotification: NSNotification) {
        // Insert code here to tear down your application
    }


}

