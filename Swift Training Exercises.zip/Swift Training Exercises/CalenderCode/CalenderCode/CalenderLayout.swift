//
//  CalenderLayout.swift
//  CalenderCode
//
//  Created by swathi m on 2/19/16.
//  Copyright © 2016 swathi m. All rights reserved.
//

import Cocoa

class CalenderLayout: NSWindowController {

    
    @IBOutlet var calenderView: NSView!
    override func windowDidLoad() {
        super.windowDidLoad()
        
        calendarView. = 1
        calendarView.layer.borderColor = UIColor.lightGrayColor().CGColor
        calendarView.backgroundColor = UIColor.whiteColor()

        // Implement this method to handle any initialization after your window controller's window has been loaded from its nib file.
    }
    override var windowNibName : String? {
        return "CalenderLayout"
    }
    
}
