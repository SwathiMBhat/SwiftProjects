//
//  Employee.swift
//  DemoRaiseMan
//
//  Created by swathi m on 1/19/16.
//  Copyright © 2016 swathi m. All rights reserved.
//

import Foundation

class Employee : NSObject {
    var name : String? = "New Employee"
    var raise : Float = 0.5
}