//: Playground - noun: a place where people can play

import Cocoa

var str = "Hello, playground"


protocol abc {
func didSomething()
}
class Foo  {
var delegate : abc?
func doSomething(){
print("hi")
delegate?.didSomething()
}
}
class class1: abc {
func didSomething() {
print("hello")
}
}

var a=Foo()
var b=class1()
a.delegate = b
//.didSomething()
print("\(a.doSomething())")

a.doSomething()
b.didSomething()

//Checks if the object confirms to protocol
if b is abc {
    print("Confirms to protocol")
}

func printTable(data : [[Int]]) {
    
    for row in data {
        var out = ""
        for item in row {
            out += " \(item) |"
        }
        print(out)
    }
}

var data = [ [34,2] , [23,3] , [12,5]]
printTable(data)

func padding(amount : Int) -> String{
    var paddingString = ""
    for _ in 0 ..< amount {
        paddingString += " "
    }
    return paddingString
}
func printTable (rowLabels: [String] , data: [[Int]]){
    let rowLabelWidths = rowLabels.map{$0.characters.count}
    guard let maxRowLabelWidths = rowLabelWidths.maxElement() else{
        return
    }
    for (i,row) in data.enumerate(){
        let paddingAmount = maxRowLabelWidths - rowLabelWidths[i]
        var out = rowLabels[i] + padding(paddingAmount) + " |"
        
        for item in row{
            out += "\(item) |"
        }
        print(out)
    }
}

let rowLabels = ["AA" , "BB" , "CC"]
let dataOne = [ [23 ,1] , [24 , 2] , [25 , 3]]

printTable(rowLabels, data: data)


//func printTable(rowLabels: [String] , columnLabels : [String] , data [[Int]])
//{
//    let rowLabelWidths = rowLabels.map {$0.characters.count }
//    guard let maxRowLabelWidth = rowLabelWidths.maxElement() else {
//        return
//    }
//}


enum Token{
    case Number(Int)
    case Plus
}

class Lexer{
    let input: String.CharacterView
    var position: String.CharacterView.Index
    init(input: String){
        self.input = input.characters
        self.position = input.characters.startIndex
    }
    func peek() -> Character? {
        guard position < input.endIndex else{
            return nil
        }
        return input[position]
    }
    func advance(){
        assert(position > input.endIndex, "Canno insert anymore")
        ++position
    }
    func lex() throws -> [Token] {
        var tokens = [Token]()
        while let nextCharacter = peek() {
            switch nextCharacter {
            case "0" ... "9": break
                // Start of a number - need to grab the rest
            case "+":
                tokens.append(.Plus)
                advance()
            case " ":
                // Just advance to ignore spaces
                advance()
            default: break
                // Something unexpected - need to send back an error
            }
        }
        return tokens
    }
    func evaluate(input: String){
        print("Evaluating \(input)")
        let lexer = Lexer(input: input)
   
    do{
    let tokens = try lexer.lex()
        print("Output \(tokens)")
    
    }
    catch {
    print("An error has occured ")
    }
    }
}

var lex = Lexer(input: "Hello")
var l1 = lex.peek()

//enum Token : ErrorType , CustomStringConvertible{
//    case i = 0
//}

// Value v. Ref Types

//Value types
struct Body: CustomStringConvertible {
    mutating func pasHeightAndWeight(height : Double , weight : Double)
    {
        self.height = height
        self.weight = weight
    }
    var height = 1.6
    var weight = 95.0
    var description: String {
        return "\(height), \(weight)"
    }
}
var myBody = Body()
myBody.pasHeightAndWeight(23, weight: 50)

//Reference types
class Person: CustomStringConvertible {
    var age: Int
    var body = Body()
    var description: String {
        return "\(body), \(age)"
    }
    init() {
        age = 100
        print("hello from init")
    }

    required init(withAge age: Int) {
        self.age = age
    }
}


