//: Playground - noun: a place where people can play

import Cocoa

var str = "Hello, playground"
//First Collection type in Swift is Array

//var bucketList : Array <String> = ["Swathi"] //First way of initializing array
var bucketList = ["Climb Mt. Everest"]
//bucketList.insert( 56 , atIndex: 3) //Adding an element at particular index
//bucketList.append("Sahara desert") //Appendind an element to array
bucketList.append("Fly Hot air baloon to fiji")
bucketList.append("Watch the lord of rings trilogy in one day")
bucketList.append("Go on a walkabout")
bucketList.append("Scuba dive in the great Blue hole")
bucketList.append("Find a triple rainbow")

//To remove one item from array
bucketList.removeAtIndex(2)
bucketList

//Counting the number of items in an array
print(bucketList.count)

//Printing a range of values that is subscripting to find top three values and a specific value
print(bucketList[0...2])
print(bucketList[1])

//Appending item at index 2
bucketList[2] += " in Australia"
print(bucketList)

//Instead of adding each item separately i can use loops
var newList = ["First new element" , "Second new element" , "Third new element"]

for itemList in newList{
    bucketList.append(itemList)
}
print(bucketList)

//Adding new items using +=
var newListTwo = ["Fourth new element" , "Fifth new element" , "Sixth new element"]
bucketList += newListTwo
print(bucketList)

//To insert at a particular index
bucketList.insert("tobogganing across Alaska" , atIndex: 2)
print(bucketList)


//Created new variable myronsList and check for equality with bucketList, true if order of the items are same

var myronsList = ["Climb Mt. Everest", "Fly Hot air baloon to fiji", "tobogganing across Alaska", "Go on a walkabout in Australia", "Scuba dive in the great Blue hole", "Find a triple rainbow", "First new element", "Second new element", "Third new element", "Fourth new element", "Fifth new element", "Sixth new element"]

        if (myronsList.isEmpty)
    {
        print("Do not contain element")
}
else
{
    print("Contains Element")
}

let equal = (bucketList == myronsList)

//Creating an immutable array
let lunches = ["Cheeseburger",
    "Veggie Pizza",
    "Chicken Caesar Salad",
    "Black Bean Burrito",
"Falafel wrap"]
print(lunches)
//lunches.append("sss") //Cannot use any of the functions in immutable array

//var bucketListArray : [String] = ["Mount Everest"] // Another way of initializing array


//bucketListArray = ["Swathi" , "Bhat" , "Seetha"]

//var arrayListReserved = ["Swat"]
//arrayListReserved.reserveCapacity(3) //reserve capacity when you know the size of array
//arrayListReserved.append("Sush")
//arrayListReserved.capacity
//arrayListReserved.count
//arrayListReserved.append("Veda")
//arrayListReserved.append("Navya")
//arrayListReserved.append("aa")
//print(arrayListReserved)

//Assignment Bronze challenge chapter 10
var toDoList = ["Take out garbage", "Pay bills", "Cross off finished items"]
if(toDoList.isEmpty)
{
    print("Do not contain elements")
}
else
{
    print("Contains elements")
}
//Assignment silver challenge chapter 10

print(toDoList , " Before reversing")
toDoList = toDoList.reverse()
print(toDoList , "After Reversing")

//for toDoList1 in toDoList{
//    while buffer >= 0{
//    buffer = toDoList.endIndex
//    print(toDoList[buffer])
//        buffer--;
//    }
//}

//Create an array with default values
var defaultArray = [Double] (count : 3 ,repeatedValue : 0.0) //contains 3 elements with value 0

var anotherDefaultArray = [Double] (count : 4 , repeatedValue : 2.5)

var thirdDefaultArray = defaultArray + anotherDefaultArray // adding two default arrays to one array

//to print array using index value
for (index , value) in thirdDefaultArray.enumerate(){
    print("Item\(index+1) : \(value)")
}
let possibleMiddleName: String? = "Swathi"
var name: String
if let middleName = possibleMiddleName {
    name = middleName
} else {
    name = ""
}
// equivalent:
name = possibleMiddleName ?? ""






public class ThermometerClass {
    private(set) var temperature: Double = 0.0
    public func registerTemperature(temperature: Double) {
        self.temperature = temperature
    }
}

let thermometerClass = ThermometerClass()
thermometerClass.registerTemperature(56.0)

public struct ThermometerStruct {
    private(set) var temperature: Double = 0.0
    public mutating func registerTemperature(temperature: Double) {
        self.temperature = temperature
    }
}

var thermometerStruct = ThermometerStruct()
thermometerStruct.registerTemperature(56.0)


var thing = "cars"

let closure = { [thing] in
    print("I love \(thing)")
}

thing = "airplanes"

print(closure())

func countUniques<T: Comparable>(array: Array<T>) -> Int {
    let sorted = array.sort(<)
    let initial: (T?, Int) = (.None, 0)
    let reduced = sorted.reduce(initial) { ($1, $0.0 == $1 ? $0.1 : $0.1 + 1) }
    return reduced.1
}

countUniques([1, 2, 3, 3, 3, 4 ,1])

extension Array where Element: Comparable {
    func countUniques() -> Int {
        let sorted = sort(<)
        let initial: (Element?, Int) = (.None, 0)
        let reduced = sorted.reduce(initial) { ($1, $0.0 == $1 ? $0.1 : $0.1 + 1) }
        return reduced.1
    }
}



