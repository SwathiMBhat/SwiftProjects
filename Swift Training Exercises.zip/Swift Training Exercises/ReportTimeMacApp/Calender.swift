//
//  Calender.swift
//  ReportTimeMacApp
//
//  Created by swathi m on 2/2/16.
//  Copyright © 2016 swathi m. All rights reserved.
//

import Cocoa

class Calender: NSWindowController {

    override func windowDidLoad() {
        super.windowDidLoad()

        // Implement this method to handle any initialization after your window controller's window has been loaded from its nib file.
    }
    
}
