//
//  DetailWindowController.swift
//  ReportTimeMacApp
//
//  Created by swathi m on 2/4/16.
//  Copyright © 2016 swathi m. All rights reserved.
//

import Cocoa

class DetailWindowController: NSWindowController {

    override func windowDidLoad() {
        super.windowDidLoad()

        // Implement this method to handle any initialization after your window controller's window has been loaded from its nib file.
    }
    
    @IBAction func detailWindowCloseButtonAction(sender: NSButton) {
        window?.close()
    }
}
