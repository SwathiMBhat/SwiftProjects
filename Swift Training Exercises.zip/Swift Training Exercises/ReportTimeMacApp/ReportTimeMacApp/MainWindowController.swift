//
//  MainWindowController.swift
//  ReportTimeMacApp
//
//  Created by swathi m on 2/2/16.
//  Copyright © 2016 swathi m. All rights reserved.
//

import Cocoa
import EventKit

class MainWindowController: NSWindowController {
//    // Create an Event Store instance
//    let eventStore = EKEventStore();
//    
//    // Use Event Store to create a new calendar instance
//    // Configure its title
    
//    let newCalendar = EKCalendar(forEntityType: EKEntityTypeEvent, eventStore: eventStore)
//    newCalendar.title = "Calender"
//    / Access list of available sources from the Event Store
//    let sourcesInEventStore = eventStore.sources() as! [EKSource]
//    
//    // Filter the available sources and select the "Local" source to assign to the new calendar's
//    // source property
//    newCalendar.source = sourcesInEventStore.filter{
//    (source: EKSource) -> Bool in
//    source.sourceType.value == EKSourceTypeLocal.value
//    }.first
//    
//    // Save the calendar using the Event Store instance
//    var error: NSError? = nil
//    let calendarWasSaved = eventStore.saveCalendar(newCalendar, commit: true, error: &error)
//    
//    // Handle situation if the calendar could not be saved
//    if calendarWasSaved == false {
//    let alert = UIAlertController(title: "Calendar could not save", message: error?.localizedDescription, preferredStyle: .Alert)
//    let OKAction = UIAlertAction(title: "OK", style: .Default, handler: nil)
//    alert.addAction(OKAction)
//    
//    self.presentViewController(alert, animated: true, completion: nil)
//    } else {
//    NSUserDefaults.standardUserDefaults().setObject(newCalendar.calendarIdentifier, forKey: "EventTrackerPrimaryCalendar")
//    }
//    
   
    @IBOutlet var resetButtonOutlet: NSButton!
    @IBOutlet var timePeriodOutlet: NSPopUpButton!
    @IBOutlet var projectNameOutlet: NSTextField!
    var abstractSearch : SecondWindowController?
    var detailSearch : DetailWindowController?
    @IBOutlet var detailRadioButtonOutlet: NSButton!
    @IBOutlet var abstractRadioButtonOutlet: NSButton!
    
    @IBOutlet var timeSheetStatusItemListOutlet: NSPopUpButton!
    
    @IBOutlet var searchButtonOutlet: NSButton!
    
    @IBOutlet var generateButtonOutlet: NSButton!
    override var windowNibName : String? {
        return "MainWindowController"
    }
    
    
    @IBAction func resetButtonAction(sender: NSButton) {
      
    }
    
    
    @IBAction func searchButtonAction(sender: NSButton) {
        if (abstractRadioButtonOutlet.integerValue == 1){
        abstractSearch = SecondWindowController(windowNibName: "SecondWindowController")
        window?.beginSheet(abstractSearch!.window!, completionHandler: nil)
        }
        else {
            detailSearch = DetailWindowController(windowNibName: "DetailWindowController")
            window?.beginSheet(detailSearch!.window!, completionHandler: nil)
        }
    }
    
    @IBAction func mainWindowCloseButton(sender: NSButton) {
        window?.close()
    }
    @IBAction func abstractDetailButtonAction(sender: NSButton) {
        if (sender.tag == 0)
        {
            abstractRadioButtonOutlet.integerValue=1
            
        }
        else
        {
            detailRadioButtonOutlet.integerValue = 1
        }
        
    }
    
    
    @IBAction func calenderAction(sender: AnyObject) {
        
        
    }
    
    override func windowDidLoad() {
        super.windowDidLoad()
        //self.searchButtonOutlet.wantsLayer = true
//         func awakeFromNib() {
//            if self.searchButtonOutlet.layer != nil {
//                let color : CGColorRef = CGColorCreateGenericRGB(1.0, 0, 0, 1.0)
//                self.searchButtonOutlet.layer?.backgroundColor = color
//            }
//            
//        }
        
       // self.searchButtonOutlet?.backgroundColor = NSColor(calibratedRed: 0.0, green: 1.0, blue: 0.0 , alpha : 1.0)
//      let timeSheetStatusItemList = ["Approved" , "Pending" , "Returned" , "Saved" , "Submitted" , "Verified" , "Withdrawn"]
//        timeSheetStatusItemListOutlet.addItemsWithTitles(timeSheetStatusItemList)
        

        // Implement this method to handle any initialization after your window controller's window has been loaded from its nib file.
    }
        
}
