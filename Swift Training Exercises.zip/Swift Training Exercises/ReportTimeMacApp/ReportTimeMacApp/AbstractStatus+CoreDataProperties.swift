//
//  AbstractStatus+CoreDataProperties.swift
//  ReportTimeMacApp
//
//  Created by swathi m on 2/8/16.
//  Copyright © 2016 swathi m. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

import Foundation
import CoreData

extension AbstractStatus {

    @NSManaged var personName: String?
    @NSManaged var status: String?
    @NSManaged var weekendDate: String?

}
