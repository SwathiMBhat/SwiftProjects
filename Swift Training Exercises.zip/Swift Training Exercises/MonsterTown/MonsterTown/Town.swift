//
//  Town.swift
//  MonsterTown
//
//  Created by swathi m on 1/17/16.
//  Copyright © 2016 swathi m. All rights reserved.
//

import Foundation
struct Town{
    var region : String
    var population : Int {
        //property Observer of oldPopulation
    didSet(oldPopulation) {
    print("The population has changed to \(population) from \(oldPopulation)")
    }
    }
    var numberOfStoplights : Int
    init (population : Int , numberOfStoplights : Int ,  region : String){
        self.population = population;
        self.numberOfStoplights = numberOfStoplights
        self.region = region
    }
    enum Size{
        case Small
        case Medium
        case Large
    }
    //Calculating townsize at the time of call //Computed Property
    //Placing it inside Get method
    var townSize : Size {
        get {
        switch self.population {
        case 0...10000 : return Size.Small
        case 10001...100000 :return Size.Medium
        default : return Size.Large
        }
    }
    }
     func printTownDescription() {
        print("Population: \(population)number of stoplights: \(numberOfStoplights) and region : \(region)");
    }
        mutating func changePopulation(amount: Int){
            population += amount
        }
  
}

