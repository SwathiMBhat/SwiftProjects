//
//  Zombie.swift
//  MonsterTown
//
//  Created by swathi m on 1/17/16.
//  Copyright © 2016 swathi m. All rights reserved.
//

import Foundation
class Zombie: Monster {
    //Computed type property since its not taking any parameters
    //class func makeSpookyNoise() -> String {
    class override var makeSpookyNoise : String{
        return "Brains..."
    }
    
    var walksWithLimp = true
    
    final override func terrorizeTown() {
        town?.changePopulation(-10)
        super.terrorizeTown()
    }
    
    func changeName(name: String, walksWithLimp: Bool) {
        self.name = name
        self.walksWithLimp = walksWithLimp
    }
}