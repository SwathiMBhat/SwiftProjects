//
//  main.swift
//  MonsterTown
//
//  Created by swathi m on 1/17/16.
//  Copyright © 2016 swathi m. All rights reserved.
//

import Foundation

//Creating an instance of town

var myTown = Town(population : 2345 , numberOfStoplights: 3)
let ts = myTown.townSize
var q = myTown.population
print("\(q)")
print(ts)
myTown.changePopulation(10000)
print("Size: \(myTown.townSize); population: \(myTown.population)")
let gm = Monster()
gm.town = myTown
gm.terrorizeTown()
let fredTheZombie = Zombie()
fredTheZombie.town = myTown
fredTheZombie.terrorizeTown()
fredTheZombie.town?.printTownDescription()
fredTheZombie.changeName("Fred the Zombie", walksWithLimp: false)
print("FredTheZombie : \(fredTheZombie.victimPool)");
fredTheZombie.victimPool = 500
print("VictimPool : (\(fredTheZombie.victimPool)")
print(Zombie.makeSpookyNoise)

if Monster.isTerrifying{
    print("Run away")
}