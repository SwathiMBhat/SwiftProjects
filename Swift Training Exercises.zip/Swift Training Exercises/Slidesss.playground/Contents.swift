//: Playground - noun: a place where people can play

import Cocoa

var str = "Hello, playground"

var a : [Int : String] = [1 : "swa"]