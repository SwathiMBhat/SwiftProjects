//: Playground - noun: a place where people can play

import Cocoa

var str = "Hello, playground"

//Switch showing HTTP errorcodes and status codes

var statusCode = 404
var errorString : String
switch statusCode{
case 400: errorString = "Bad String"
case 401 : errorString = "Unauthorized"
case 403:
    errorString = "Forbidden"
case 404:
    errorString = "Not found"
default:
    errorString = "None "
}

switch statusCode{
case 400,401,402,403,404 : errorString = "Bad request"
default : errorString += "Try again"
}

switch statusCode {
case 100, 101:
    errorString += " Informational, 1xx."
case 204:
    errorString += " Successful but no content, 204."
case 300...307:
    errorString += " Redirection, 3xx."
case 400...417:
    errorString += " Client error, 4xx."
case 500...505:
    errorString += " Server error, 5xx."
default:
    errorString = "Unknown. Please review the request and try again."
}

statusCode = 1000
switch statusCode {
case 100, 101:
    errorString += " Informational, \(statusCode)."
case 204:
    errorString += " Successful but no content, 204."
case 300...307:
    errorString += " Redirection, \(statusCode)."
case 400...417:
    errorString += " Client error, \(statusCode)."
case 500...505:
    errorString += " Server error, \(statusCode)."
case let unknownCode where (unknownCode >= 200 && unknownCode <= 500) || unknownCode > 500:
    errorString = "\(unknownCode) Please review the request and try again."
default : errorString += "\(statusCode) not found"
}

statusCode = 418
errorString = "the request failed with the error:"
switch statusCode{
case 100, 101:
    errorString += " Informational, \(statusCode)."
case 204:
    errorString += " Successful but no content, 204."
case 300...307:
    errorString += " Redirection, \(statusCode)."
case 400...417:
    errorString += " Client error, \(statusCode)."
case 500...505:
    errorString += " Server error, \(statusCode)."
case let unknownCode where (unknownCode >= 200 && unknownCode < 300) || unknownCode > 505:
    errorString = "\(unknownCode) is not a known error code."
default:
    errorString = "Unknown error encountered."
}

let errorTuple = (code : statusCode, error :errorString)
errorTuple.code; //or errorTuple.0
errorTuple.error // or errorTuple.1

//Comparing Two variables in switch
let firstErrorCode = 404
let secondErrorCode = 200
let errorCodes = (firstErrorCode, secondErrorCode)
switch errorCodes {
case (404, 404):
    print("No items found.")
case (404, _): // _ wildcard expression can take any character
    print("First item not found.")
case (_, 404):
    print("Second item not found.")
default:
    print("All items found.")
}


var status : Int = 1
var error : String = "Entered value is false"
switch status{
case 1...3 : print(error); break;
case 1,3 : print(status); break;
default : print(error)
}

switch status{
case 1...3 :  print(status); break;
default: let error1 = "error ,\(status)";
print(error1)
}


switch status{
case 1 : print (error); break;
case let statusOne where (statusOne >= 10 || statusOne == 10):
print(error);
default : print("Less than 10")
}


let result = (code : status , value: error)

result.0;
result.1;

result.code;
result.value;


let errorcodes = (errorcodeOne : result.0, errorcodeTwo : result.1)


let age = 22
switch age{
case 18...25: print(age)
break;
default: break;
}



if case 18...25 = age where age >= 21   {
    print("Swathi \(age)");
    
}


let point = (x: 1, y: 4)
switch point {
case let q1 where (point.x > 0) && (point.y > 0):
    print("\(q1) is in quadrant 1")
case let q2 where (point.x < 0) && point.y > 0:
    print("\(q2) is in quadrant 2")
case let q3 where (point.x < 0) && point.y < 0:
    print("\(q3) is in quadrant 3")
case let q4 where (point.x > 0) && point.y < 0:
    print("\(q4) is in quadrant 4")
case (_, 0):
    print("\(point) sits on the x-axis")
case (0, _):
    print("\(point) sits on the y-axis")
default:
    print("Case not covered.")
}
