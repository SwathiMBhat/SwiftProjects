//: Playground - noun: a place where people can play

import Cocoa

var str = "Hello, playground"

//Defining a function
//non parameterized function
func printGreeting()
{
    print("Hello, Welcome to Xcode")
}
printGreeting()

//Function using a name parameter
func personalGreeting(name : String)
{
    print("Welcome to playground \(name)")
}

personalGreeting("Swathi")

//function for division of two numbers with default parameter punctuation
func divisionOfTwoNumbers(fornumerator : Double , fordenominator : Double , withPunctuation punctuation : String = ".")
{
    print("\(fornumerator) divided by \(fordenominator) equals \(fornumerator/fordenominator) \(punctuation)")
}
divisionOfTwoNumbers(9.0, fordenominator: 3.0)
divisionOfTwoNumbers(10, fordenominator: 5, withPunctuation: "!")
divisionOfTwoNumbers(34, fordenominator: 2 )

//Demo of variadic parameter, there can be only one variadic parameter
func sampleVariadicParameter (name : String...)
{
    for names in name{
        print("\(names) , Welcome to playground")
    }
    for namesTwo in name{
        print("\(namesTwo)")
    }
}

sampleVariadicParameter("Swathi", "Veda")

//Sample for inOut ~ in-out parameter cannot have default value and inout parameter cannot be variadic
var error = "The request failed."
func appendErrorCode(code: Int, inout toErrorString errorString: String){
    if code == 404{
        errorString += " Bad  request"
    }
}
appendErrorCode(404, toErrorString: &error)
 print(error) // Act as a reference pointer and modifies the error parameter itself
var errorNumberTwo = "Request failed"
func removeErrorCode(codeValue: Int , inout toErrorStr errorStr : String){
    if codeValue == 405{
    errorStr += " Remove error"
    }
}
removeErrorCode(405, toErrorStr: &errorNumberTwo)
//Returning value from a function
func divide(num : Int , den : Int , punctuation : String = ".") -> String
{
    return "\(num) divided by \(den) gives \(num/den) \(punctuation)"
}
divide(9, den: 3, punctuation: "!")
divide(10, den: 5)

//Nested function or func inside another func
func areaOfTriangle(withBase : Double , withHeight : Double) -> Double{
    let numerator = withBase * withHeight
    func divides() -> Double {
        return numerator / 2
    }
    return divides()
}
areaOfTriangle(20, withHeight: 2)

//Multiple return values - Sorting evens and odds
func sortEvenOdd(numbers: [Int]) -> (evens: [Int], odds: [Int]) {
    var evens = [Int]()
    var odds = [Int]()
    for number in numbers {
        if number % 2 == 0 {
            evens.append(number)
        } else {
            odds.append(number)
        }
    }
    return (evens, odds)
}
sortEvenOdd([12 ,13,14, 45,65, 78])
let aBunchOfNumbers = [10,1,4,3,57,43,84,27,156,111]
let theSortedNumbers = sortEvenOdd(aBunchOfNumbers)
print("The even numbers are: \(theSortedNumbers.evens) and the odd numbers are: \(theSortedNumbers.odds)")

//Optional Return Values

func grabMiddleName ( name : (String , String? , String)) -> String? {
    return name.1
}
let middleName = grabMiddleName(("Swathi" , nil , "Bhat"))

if let theName = middleName {
    print(theName)
}


//Using Guard statements - Acts like if else - If there is no value in the optional then generic code that is part of guard statement is executed


//ASsignment to use where clause inside guard statement - Bronze challenge chapter 13
func grabLastName (name : (first : String , middle : String , last : String?)) {
    
    guard let lastName = name.last where lastName.characters.count < 4  else {
        print("Hello ! Welcome")
        return
    }
        print("Welcome \(lastName)")
    
}

grabLastName(("Swathi" , "M","Bhat"))
let evenOddFunction: ([Int]) -> ([Int], [Int]) = sortEvenOdd


//Assignment silver challenge chapter 13 functions
func beanSifter (groceryList : [String]) -> (beans: [String], otherGroceries: [String]){
    var beans = [String]()
    var otherGroceries = [String]()
    for groceryListName in groceryList{
        if groceryListName.hasSuffix("beans"){
            beans.append(groceryListName)
        }
        else
        {
            otherGroceries.append(groceryListName)
        }
    }
    return (beans , otherGroceries)
}
let result = beanSifter(["green beans",
    "milk",
    "black beans",
    "pinto beans",
    "apples"])
let beansResult = result.beans
let otherGroceriesResult = result.otherGroceries


func simpleMax<T: Comparable>(x: T, _ y: T) -> T {
    if x < y {
        return y
    }
    return x
}
simpleMax(34, 35)

var arr1 = [1,2,3,4]
var arr2 = ["Swathi" , "M"]
var arr = [String]?()
arr?.append("Swathi")
print(arr)


//Returning function inside another function
typealias EmptyFuncType = () -> ()
func functionReturner() -> EmptyFuncType{
    func myInnerFunc() {
    print("Hello")
    }
    return myInnerFunc
}

var things = [1,2,3]
things.reverse()
print(things)
//for thing in things.reverse(){
//    print(things)
//}


