//
//  RowTableView.swift
//  TableViewTimeAppPractice
//
//  Created by swathi m on 2/17/16.
//  Copyright © 2016 swathi m. All rights reserved.
//

import Cocoa

class RowTableView: NSTableView {

    
    override func drawRect(dirtyRect: NSRect) {
        super.drawRect(dirtyRect)

         //Drawing code here.
    }
    
}
