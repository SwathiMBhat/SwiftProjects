//
//  AppDelegate.swift
//  TableViewTimeAppPractice
//
//  Created by swathi m on 2/17/16.
//  Copyright © 2016 swathi m. All rights reserved.
//

import Cocoa

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {

    //@IBOutlet weak var window: NSWindow!
    var timeTable : TimeTable?

    func applicationDidFinishLaunching(aNotification: NSNotification) {
        // Insert code here to initialize your application
        let timeTable = TimeTable()
        timeTable.showWindow(self)
        self.timeTable = timeTable
    }

    func applicationWillTerminate(aNotification: NSNotification) {
        // Insert code here to tear down your application
    }


}

