//
//  TimeTable.swift
//  TableViewTimeAppPractice
//
//  Created by swathi m on 2/17/16.
//  Copyright © 2016 swathi m. All rights reserved.
//

import Cocoa

class TimeTable: NSWindowController {

    @IBOutlet var scrollViewOutlet: NSScrollView!
    
    @IBOutlet var tableViewOutlet: NSTableView!
    
    override var windowNibName : String? {
        return "TimeTable"
    }
    
    var timeArray : Array<String> = ["12AM","1AM","2AM","3AM","4AM","5AM","6AM","7AM","8AM","9AM","10AM","11AM","12PM","1PM","2PM","3PM","4PM","5PM","6PM","7PM","8PM","9PM","10PM","11PM","12PM"]
    
    func tableView(tableView: NSTableView,
        heightOfRow row: Int) -> CGFloat{
            return 100
    }
    override func windowDidLoad() {
        super.windowDidLoad()

        // Implement this method to handle any initialization after your window controller's window has been loaded from its nib file.
    }
    
}
