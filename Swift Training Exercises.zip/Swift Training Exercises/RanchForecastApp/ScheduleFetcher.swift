//
//  ScheduleFetcher.swift
//  RanchForecastApp
//
//  Created by swathi m on 1/20/16.
//  Copyright © 2016 swathi m. All rights reserved.
//

import Foundation

class ScheduleFetcher {
    enum FetchCoursesResult {
        case Success([Course])
        case Failure(NSError)
    }
    let session : NSURLSession
    
    init() {
        let config = NSURLSessionConfiguration.defaultSessionConfiguration()
        session = NSURLSession(configuration: config)
    }
    func fetchCoursesUsingCompletionHandler(completionHandler:
        FetchCoursesResult -> Void) {
        let url = NSURL(string: "http://bookapi.bignerdranch.com/courses.json")!
        let request = NSURLRequest(URL: url)
        let task = session.dataTaskWithRequest(request) { data, response, error in
        let result: FetchCoursesResult
        if let data = data {
        print("Received \(data.length) bytes.")
        result = .Success([])  // Empty array until parsing is added
    }
        else {
        result = .Failure(error!)
        }
        NSOperationQueue.mainQueue().addOperationWithBlock {
        completionHandler(result)
        }
        }
        task.resume()
    }
    func errorWithCode (code : Int , localizedDescription: String) -> NSError {
            
    
}

