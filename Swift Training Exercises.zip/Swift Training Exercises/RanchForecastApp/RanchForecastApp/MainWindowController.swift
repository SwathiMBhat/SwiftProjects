//
//  MainWindowController.swift
//  RanchForecastApp
//
//  Created by swathi m on 1/20/16.
//  Copyright © 2016 swathi m. All rights reserved.
//

import Cocoa

class MainWindowController: NSWindowController {
    let fetcher = ScheduleFetcher()
    dynamic var courses: [Course] = []

    override func windowDidLoad() {
        super.windowDidLoad()
    fetcher.fetchCoursesUsingCompletionHandler { result in switch result{
        case .Success(let courses) : print("Got courses \(courses)")
            self.courses = courses
        case .Failure(let error) : print("Got error \(error)")
            NSAlert(error: error).runModal()
            self.courses = []
    }
            override var windowNibName: String! {
        return "MainWindowController"
            }

        // Implement this method to handle any initialization after your window controller's window has been loaded from its nib file.
    }
    
    
    
}
