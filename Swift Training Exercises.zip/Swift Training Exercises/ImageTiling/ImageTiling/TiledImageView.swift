//
//  TiledImageView.swift
//  ImageTiling
//
//  Created by swathi m on 1/21/16.
//  Copyright © 2016 swathi m. All rights reserved.
//

import Cocoa

class TiledImageView: NSView {

    override func drawRect(dirtyRect: NSRect) {
        super.drawRect(dirtyRect)

        // Drawing code here.
    }
    
}
