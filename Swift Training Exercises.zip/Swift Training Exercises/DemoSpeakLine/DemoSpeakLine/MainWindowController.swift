//
//  MainWindowController.swift
//  DemoSpeakLine
//
//  Created by swathi m on 1/18/16.
//  Copyright © 2016 swathi m. All rights reserved.
//

import Cocoa

class MainWindowController: NSWindowController, NSSpeechSynthesizer  {
    
    @IBOutlet weak var textField: NSTextField!
    @IBOutlet weak var speakButton: NSButton!
    @IBOutlet weak var stopButton: NSButton!
    
    let speechSynth: NSSpeechSynthesizer = NSSpeechSynthesizer()
    
    let voices = NSSpeechSynthesizer.availableVoices()
    
    var isStarted: Bool = false {
        didSet {
            updateButtons()
        }
    }
    
    
    override func windowDidLoad() {
        super.windowDidLoad()
        updateButtons()
        speechSynth.delegate = self
        print(voices)
    }
    
    
    // MARK: Action methods
    @IBAction func speakIt(sender: NSButton) {
        
        // Get typed-in text as a string
        let string = textField.stringValue
        if string.isEmpty {
            print("string from \(textField) is empty")
        } else {
            speechSynth.startSpeakingString(string)
            isStarted = true
        }
    }
    
    
    @IBAction func stopIt(sender: NSButton) {
        speechSynth.stopSpeaking()
        isStarted = false
    }
    func voiceNameForIdentifier(identifier :String) -> String? {
        let attributes = NSSpeechSynthesizer.attributesForVoice(identifier)
        return attributes[NSVoiceName] as? String }
    func updateButtons() {
        if isStarted {
            speakButton.enabled = false
            stopButton.enabled = true
        } else {
            stopButton.enabled = false
            speakButton.enabled = true
        }
    }
    func numberOfRowsInTableView(tableView: NSTableView) -> Int {
        return voices.count }
    func tableView(tableView: NSTableView,
        objectValueForTableColumn tableColumn: NSTableColumn?,
        row: Int) -> AnyObject? {
        let voice = voices[row]
        let voiceName = voiceNameForIdentifier(voice)
        return voiceName
    }
}
    func speechSynthesizer(sender: NSSpeechSynthesizer, didFinishSpeaking finishedSpeaking: Bool) {
        isStarted = false
        print("finishedSpeaking=\(finishedSpeaking)")
    }
    
    
    
    func windowShouldClose(sender: AnyObject) -> Bool {
        if isStarted {
            return !isStarted
        } else {
            return isStarted
        }
    }
    
}

