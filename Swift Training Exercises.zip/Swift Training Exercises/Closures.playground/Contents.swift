//: Playground - noun: a place where people can play

import Cocoa

var str = "Hello, playground"

//closures have bundles of functionality. Function is named closure


//Example of sorting Array using Closures
let volunteerCounts = [1,3,34,23,45,12,11]
func sortAscending(i: Int , j:Int) -> Bool { // Closure Function which checks for i<j and return true or false. If i>j then it interchanges the value
    return i<j
}
let sortedVolunteers = volunteerCounts.sort(sortAscending)

//Using Closure Expression - in the destination variable add the closure function itself inline {parameters -> return type in statement}

let volunteersSorted = volunteerCounts.sort(
    {(i: Int , j: Int) -> Bool in
        return i<j
    })
volunteersSorted

//Without giving parameter types and return type
let volunteersSortedClosure = volunteerCounts.sort({i , j in i<j})
volunteersSortedClosure

//Closures for sort using values
let volunteersClosureSorted = volunteerCounts.sort{$0<$1}

//Functions as return types makeTownGrand returns a function which has parameters int and int which returns int. Function defn is written inside makeTownGrand
func makeTownGrand() -> (Int ,Int) -> Int{
   func buildRoads(addLights: Int , toLights: Int) -> Int{
   
        return  addLights + toLights
    }
    return buildRoads
}


var stopLights = 4
let townPlan = makeTownGrand()
stopLights = townPlan(4 , stopLights)
print("Knowhere has \(stopLights) stoplights")

//Sorting in Alphabetical order
let volunteerNames = ["Swathi" , "Veda" , "Basavagond" , "Manohar"]
let volunteerAlphabeticalOrder = volunteerNames.sort({$1>$0})
volunteerAlphabeticalOrder


//Functions as arguments to other functions - adding budget parameter and condition param
func makeTownGrandSecond(budget: Int, condition: Int -> Bool) -> ((Int, Int) -> Int)? {
    if condition(budget)
    {
        func buildRoadsSecond(addToLights: Int , toLightsSecond: Int) -> Int{
            return addToLights + toLightsSecond
        }
         return buildRoadsSecond
    } else {
        return nil
    }
   
}

func evaluateBudget (budget: Int) -> Bool{
    return budget > 10000
}
var stopLightsSecond = 7
if let townPlanSecond = makeTownGrandSecond(1000000 , condition: evaluateBudget){
    stopLightsSecond = townPlanSecond(6,stopLightsSecond)
}
print("Knowwhere has \(stopLightsSecond) stoplights")

//Closures capture values - growth Tracker - currentPopulation + growth
func makeGrowthTracker(forGrowth growth: Int) -> () -> Int{
    var totalGrowth = 0
    func growthTracker() -> Int {
        totalGrowth+=growth
        return totalGrowth
    }
    return growthTracker
}
var currentPoulation = 34567
let growBy500 = makeGrowthTracker(forGrowth: 500)
growBy500()
growBy500()
growBy500()
currentPoulation
currentPoulation += growBy500()

//Closures are reference types - When assigning function to constant or variable we are pointing to that function
let anotherGrowBy500 = growBy500
anotherGrowBy500()

currentPoulation += anotherGrowBy500()
var someOtherPopulation = 123456
let growBy1000 = makeGrowthTracker(forGrowth: 1000)
someOtherPopulation += growBy1000()
currentPoulation

//map  - transforms an array's contents
let precinctpopulations = [1234, 2343 , 4565]
let projectedPopulations = precinctpopulations.map{ // maps with each value of precinctpopulations
    (population : Int) -> Int in return population * 2
}
projectedPopulations

//filter - projected condition - if > 3000 will print
let bigProjections = projectedPopulations.filter{
    (projection : Int) -> Bool in return projection > 3000
}
bigProjections

//let accumulatedPopulation = [123 , 234, 345]
//let totalProjection = projectedPopulations.reduce(0) {
//    (i: Int, j: Int) -> Int in
//    return i + j
//}
//totalProjection

//Reducing an array to a single array and combining it
//Gold challenge
let totalProjection = projectedPopulations.reduce(0, combine: {$0+$1}) // One line code to reduce and combine projectedPopulations to one array. It prints the sum of projected population. Here 0 is initialization

//let totalProjection = projectedPopulations.reduce(0){
//    (accumulatedPopulation : Int , projectedPopulations : Int) -> Int in
//    return accumulatedPopulation + projectedPopulations
//    }

//var qw = 4686 + 9130 + 2468
