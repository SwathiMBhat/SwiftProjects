//: Playground - noun: a place where people can play

import Cocoa

var str = "Hello, playground"

enum LightBulb {
    case On
    case Off
    func temperatureChange (ambientTemp : Double) -> Double {
        switch self{
        case .On : return ambientTemp + 20
        case .Off : return ambientTemp
        }
    }
    mutating func toggle()
    {
        switch self{
        case .On : self = .Off
        case .Off : self = .On
        }
    }
}
var instVar = LightBulb.On
var ambient = 103.0
var instVar1 = instVar.temperatureChange(123.0)
print(instVar1)

enum ShapeDimensions {
    // Point has no associated value - it is dimensionless
    case Point
    // Square's associated value is the length of one side
    case Square(Double)
    // Rectangle's associated value defines its width and height
    case Rectangle(width: Double, height: Double)
    func area() -> Double {
        switch self {
        case .Point:
            return 0
        case let .Square(side):
            return side * side
        case let .Rectangle(width: w, height: h):
            return w * h }
    }
    func perimeter() -> Double {
        switch self{
        case let .Square(length) : return 4 * length
        case let .Rectangle(width: w, height: h) : return ((2 * w) + (2 * h))
        case .Point : return 0
        }
    }
}

var squareShape = ShapeDimensions.Square(10.0)
var rectShape = ShapeDimensions.Rectangle(width: 5.0, height: 10.0)
var pointShape = ShapeDimensions.Point
print("square's area = \(squareShape.area())")
print("rectangle's area = \(rectShape.area())")
print("point's area = \(pointShape.area())")

var squarePerimeter = ShapeDimensions.Square(20.0)
var sqPerimeter = ShapeDimensions.perimeter(squarePerimeter)
print(squarePerimeter.perimeter())
