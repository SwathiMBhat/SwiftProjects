//: Playground - noun: a place where people can play

import Cocoa

var str = "Hello, playground"


//MODEL A SMALL TOWN

//var numberOfStopLights = "Four" // Here numberOfStopLights is taking type inference as String
//numberOfStopLights += 2 - Compiler Error since String cannot take Int values

//var numberOfStoplights : Int = 4
//numberOfStoplights += 2


//Assignment
let numberOfStoplights = 4
var population : Int
population = 12345
let townName : String = "Knowwhere"
var unemployed : Int = 123
let townSescription = "\(townName) has a population of \(population) and has \(numberOfStoplights) stoplights with \(unemployed) people unemployed"
print(townSescription)

