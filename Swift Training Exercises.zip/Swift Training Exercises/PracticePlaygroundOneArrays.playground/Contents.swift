//: Playground - noun: a place where people can play

import Cocoa

var str = "Hello, playground"


//var bucketList : Array <String>

//Initializing Array
//var bucketList : [String] = ["Climb Mt. Everest"]

var bucketList = ["Climb Mt. Everest"]
bucketList.append("Fly hot air baloon to fuji")
bucketList.append("Watch the Lord of the Rings trilogy in one day")
bucketList.append("Go on a walkabout")
bucketList.append("Scuba dive in the Great Blue Hole")
bucketList.append("Find a triple rainbow")
bucketList.removeAtIndex(2)
print(bucketList)

//Counting items of array
print(bucketList.count)

//To find top three items
print(bucketList[0...2])

//Using subscripting to append new item information
bucketList[2] += " in Australia"
print(bucketList)

//Replacing an array item
bucketList[0] = "Climb Mt. Kilimanjaro"
print(bucketList)

//Using loop to append one item to another
var newItems = ["Fly hot air balloon to Fiji",
    "Watch the Lord of the Rings trilogy in one day",
    "Go on a walkabout",
    "Scuba dive in the Great Blue Hole",
    "Find a triple rainbow"
    ]

for item in newItems{
    print(item)
}
//removing one item from bucketlist
bucketList.removeAtIndex(2)
print(bucketList.count)
print(bucketList[0...2])
print(bucketList)

//refactoring with assignment operator
bucketList += newItems
print(bucketList)
bucketList.insert("Toboggan across Alaska", atIndex: 2)
print(bucketList)

//Checking for array equality
var myronsList = [ "Climb Mt Kilimanjaro" ,
    "Fly hot air balloon to Fiji",
    "Toboggan across Alaska",
    "Go on a walkabout in Australia",
    "Find a triple rainbow",
    "Scuba dive in the Great Blue Hole"
]
//let equal = (bucketList == myronsList)

myronsList = [ "Climb Mt. Kilimanjaro",
    "Fly hot air baloon to fuji",
    "Toboggan across Alaska",
    "Scuba dive in the Great Blue Hole",
    "Find a triple rainbow",
    "Fly hot air balloon to Fiji",
    "Watch the Lord of the Rings trilogy in one day",
    "Go on a walkabout",
    "Scuba dive in the Great Blue Hole",
    "Find a triple rainbow"
    
]
print(bucketList)
let equal = (bucketList == myronsList)

//Immutable array
let lunch = ["Veg Pizza" , "Burger" , "Black bean" ]

//lunch.append("Chicken burger") // Immutable array cannot append items


var toDoList = ["Take out garbage" , "pay bills" , "Cross off finished items"]

//To check if there are any elements in the array
if toDoList.isEmpty{
    print("TodoList do not have any elements inside it")
}
else
{
    print("ToDoList has elements that is \(toDoList)")
}
//Silver Challenge
print(toDoList)
toDoList = toDoList.reverse()
print(toDoList)

//to print index and contents using for in
for (index , list) in toDoList.enumerate(){
    print("\(index) : \(list)")
}

//toDoList.start



//OPTIONALS

