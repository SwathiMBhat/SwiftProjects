//: Playground - noun: a place where people can play

import Cocoa

var str = "Hello, playground"

//To print the max and min values for int
print("The maximum Int value is \(Int.max).") // 64 bit
print("The minimum Int value is \(Int.min).") //64 bit

print("The maximum Int value is \(Int32.max).") // 32 bit
print("The minimum Int value is \(Int32.min).") //32 bit

print("Maximum value for float is \(FLT_MAX)") // To get Float and Double max and min values
print("Minimum value for Double is \(DBL_MIN)")

let numberOfPeople:Int = 10
//let firstBadValue : UInt = -23 //Unsigned integer takes only positive values
//let secondBadValue : Int8 = 129 //Int8 range from 127 to -128

//operations 
print((4*23)-12)


//Increment and decrement
var x = 10
x++
x--

//Overflow operators
//let y: Int8 = 120
//let z = y + 10 //Since z also becomes an Int8 type it gives error as the answer is 130 and it exceeds max value of Int8

let y: Int8 = 120
let z = y &+ 10 //Takes till 127 then goes behind like -128,-127....

let a: Int16 = 200
let b: Int8 = 50
//let c = a + b //Gives error since operation is on two different Int types, Not supported


//Floating values and Double values
let d1 = 1.1 // Implicitly Double
let d2: Double = 1.1
let f1: Float = 100.3

print(10.0 + 11.4)
print(11.0 / 3.0)
print(12.4 % 5.0)

if d1 == d2 {
    print("d1 and d2 are the same!")
}
print("d1 + 0.1 is \(d1 + 0.1)")
if d1 + 0.1 == 1.2 {  //if statement does not execute as it is not same since internally 1.2 can be taken as 1.99999 or 1.200001, never use floating for exact values
    print("d1 + 0.1 is equal to 1.2")
}
