//: Playground - noun: a place where people can play

import Cocoa

var str = "Hello, playground"

//Raw value succeeds since 40 is defined in left case
enum TextAlignment : Int {
    case Left = 40
    case Right
    case Center
    case Justify
}
print(TextAlignment.Left.rawValue)
print(TextAlignment.Justify.rawValue)
var myRawValue = 40 // If the case has the value then conversion will be succeeded
if let myAlignment = TextAlignment(rawValue: myRawValue) {
    print("Conversion succeeded")
}
else
{
    print("Conversion not succeeded")
}
var alignment = TextAlignment.Left
alignment = .Right

switch alignment
{
case .Left : print("Left alignment")
case .Right : print("Right Alignment")
case .Center : print("Center Alignment")
case .Justify : print("Justify alignment")
}

enum Barcode{
    case UPCA(Int , Int ,Int ,Int)
    case QR(String)
}
var product = Barcode.UPCA(8,56,78,98)
var QRProduct = Barcode.QR("Product Name")

switch QRProduct{
case .UPCA( var numberOne , var NumberTwo , var NumberThree , var NumberFour) : print("UPCA product")
case .QR( var name) : print("QR Product")
}

enum ASCIIControlCharacter : Character {
    case Tab = "\t"
    case NewLine = "\n"
    case carriage = "\r"
}

enum Planet : Int {
    case mercury = 1, Venus , Earth , Mars , Jupiter
}
print(Planet.mercury.rawValue)
print(Planet.Venus.rawValue)
let positionToFind = 3
if let somePlanet = Planet(rawValue: positionToFind)
{
    switch somePlanet{
    case .Earth : print("there is a planet at position \(positionToFind)")
    default : print("Not safe")
    }
}

indirect enum ArithmeticExpression {
    case Number(Int)
    case Addition(ArithmeticExpression , ArithmeticExpression)
    case Multiplication(ArithmeticExpression , ArithmeticExpression)
}
func evaluate(expression : ArithmeticExpression) -> Int{
    switch expression{
    case .Number(let valueNumber) : return valueNumber;
    case .Addition( let firstNum , let secondNum) : return evaluate(firstNum) + evaluate(secondNum)
    case .Multiplication( let first , let second ) : return evaluate(first) * evaluate(second);
    }
}



//var value = ArithmeticExpression.Addition(5, 6)

enum ProgrammingLanguage : String {
    case Swift = "Swift"
    case ObjectiveC = "Objective C"
    case Java = "Java"
}
let myFavourite = ProgrammingLanguage.Swift //This will give myFavourite as Swift and if value is not defined then casename will be given
print("My favourite language is \(myFavourite)")


enum Lightbulb {
    case On
    case Off
    
func surfaceTempForAmbient (ambient : Double) -> Double{
    switch self {
    case .On : return ambient + 150.0
    case .Off : return ambient
    }
}

mutating func toggle()
{
    switch self {
    case .On : self = .Off
    case .Off : self = .On
    }
  }
    
}
var bulb = Lightbulb.On
var ambientTemperature = 120.0
var bulbTemperature = bulb.surfaceTempForAmbient(ambientTemperature)
bulb.toggle()
bulbTemperature = bulb.surfaceTempForAmbient(ambientTemperature)




//Shape dimension example
enum ShapeDimension {
    case Square(length : Double)
    case Rectangle(width : Double , height : Double)
    func area () -> Double {
        switch self{
         case let .Square(length) : return length * length;
        case let .Rectangle(width,height) : return width * height;
        
    }
}
}