//
//  ViewController.swift
//  RanchForecast
//
//  Created by swathi m on 1/20/16.
//  Copyright © 2016 swathi m. All rights reserved.
//

import Cocoa

class ViewController: NSViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override var representedObject: AnyObject? {
        didSet {
        // Update the view, if already loaded.
        }
    }


}

