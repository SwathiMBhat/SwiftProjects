//: Playground - noun: a place where people can play

import Cocoa

var str = "Hello, playground"

//Optional type declaration
var errorCodeString : String?
errorCodeString = "404"
print(errorCodeString)

//Checking if the type is optional
if errorCodeString != nil {
    let theError = errorCodeString!
    print(theError)
}

//optional Binding
//if let theError = errorCodeString {
//    print(theError)
//}

//Nested optional binding
if let theError = errorCodeString{
    if let errorCodeInteger = Int(theError){
        print("\(theError) : \(errorCodeInteger)")
    }
}


//Unwrapping multiple optionals in a single stmt
if let theError = errorCodeString , errorCodeInteger = Int(theError) {
    print("\(theError) : \(errorCodeInteger)")
}

//optional chaining
var errorDescription : String?
if let theError = errorCodeString , errorCodeInteger = Int(theError) where errorCodeString == "404"{
    errorDescription = ("\(errorCodeInteger + 200) : request not found")
}
var upCaseErrorDesc = errorDescription?.uppercaseString

//nil coalescing operator
//let description: String
//if let errorDescription = errorDescription {
//    description = errorDescription
//} else {
//    description = "No error"
//}

let description = errorDescription ?? "No error"

//Forceful unwrapping variable
var optionalVar : String?
//let forceUnwrappedVariable = optionalVar!

var a : Optional<String>

var VolunteerCounts = [2,5,6,3,12,9]
//
//func sortDescending (i : Int , j : Int) -> Bool{
//    return i>j
//}
let sortedVolunteers = VolunteerCounts.sort({(i : Int , j : Int) -> Bool in
    i>j})

let sortedVolunteersList = VolunteerCounts.sort({i,j in i>j})
print(sortedVolunteersList)
let SortedVolunteers = VolunteerCounts.sort({$0>$1})
//Suppose we want to map an array to another array
let mappedArray = VolunteerCounts.map {
    (i : Int) -> Int in
    return i * 2
}

//Returning function inside another function
typealias EmptyFuncType = () -> ()
func functionReturner() -> EmptyFuncType{
    func myInnerFunc() {
        print("Hello")
    }
    return myInnerFunc
}

let returnedVariable = functionReturner()
returnedVariable()

//func makeTownGrand() -> (Int, Int) -> Int{
//    func buildRoads() (lightsToAdd : Int , toLights : Int) -> Int{
//        return toLights + lightsToAdd
//    }
//}
//var stopLights = 3
//var townPlan = makeTownGrand()
//stopLights = townPlan(4,stopLights)

//Sorting a dictionary
let dict = ["AAA" : 23 , "BBB" : 13]
let sortedDict = dict.sort({ (i : (String,Int) , j : (String,Int) ) -> Bool in i.1<j.1})
print(sortedDict)

//Converting int to String using Map

let numbers = [2,3,4,5,6]
let mappedNumbers = numbers.map{
    (i:Int) -> String in
    i.description
}


let stringNumbers = ["2","3","4","5","6"]
let mappedNumbersToInt = stringNumbers.map{
    (i : String) -> Int in
    return Int(i)!
}

enum Shapes : Int? {
    case Square = 0
    case Rectangle = 1
    case Circle = 2
}

var shapeList = Shapes.Rectangle.rawVal
shapeList = .Circle
switch shapeList{
case .Rectangle : print("Rectangle")
case .Circle : print("Circle")
case .Square : print("Square")
}



//enum Shapes? : Int{
    
//}

// Passing two different arrays of different datatypes
var arrOne = [1,2,3,4]
var arrTwo = ["AAA" , "BBB" , "CCC"]
var setOne : Set<NSArray> = [arrOne , arrTwo]


