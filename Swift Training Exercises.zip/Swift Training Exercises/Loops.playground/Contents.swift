//: Playground - noun: a place where people can play

import Cocoa

var str = "Hello, playground"

var int:Int = 0
for k in 1...5 {
    ++int
    print(int)
    print("int equals \(int) at iteration \(k)")
}

for case let i in 1...20 where i%3==0 {
    print(i)
}

//Assignment bronze challenge 7
for i in 0...100 where i % 2 == 0{
        while(i==10)
        {
        print ("Loop executed five times")
    break
        }
    
}

//Using break continue in if else
var shields = 5
var blastersOverheating = false
var blasterFireCount = 0
var spaceDemonsDestroyed = 0;
while shields > 0 {
    if spaceDemonsDestroyed == 500 {
        print("You beat the game!")
        break }
    if blastersOverheating {
        print("Blasters are overheated!  Cooldown initiated.")
        sleep(5)
        print("Blasters ready to fire")
        sleep(1)
        blastersOverheating = false
        blasterFireCount = 0
        continue
    }
    if blasterFireCount > 100 {
        blastersOverheating = true
        continue }
    // Fire blasters!
    print("Fire blasters!")
    ++blasterFireCount
    ++spaceDemonsDestroyed
}
