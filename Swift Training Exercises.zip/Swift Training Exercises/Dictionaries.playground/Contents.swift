//: Playground - noun: a place where people can play

import Cocoa

var str = "Hello, playground"

//Items inside dictionary are of key - value type

//Declarations of dictionary
var dict : Dictionary < String , Int > = [:]
var dict1 = Dictionary <String , Double > ()
var dict3 : [String:Double] = [:]
var dict4 = [String : Double]()

//Populating a dictionary
//Creating movieratings
var movieratings = ["Donnie Darko" : 4 , "Chungking Express": 5, "Dark City": 4]
print(movieratings)
print("I have rated \(movieratings.count) movies") //Total no of key-value pairs

//Reading value from dictionary
let darkoRating = movieratings["Donnie Darko"]

//modifying value in a dictionary
movieratings["Dark City"] = 5
print(movieratings)
movieratings.updateValue(4, forKey: "Dark City") // Another way of updating
print(movieratings)

//Updating a value
let oldRating : Int? = movieratings.updateValue(5, forKey: "Donnie Darko")
print(oldRating)
if let lastRating = oldRating, currentRating = movieratings["Donnie Darko"]{
    print("Old Rating: \(lastRating) , CurrentRating : \(currentRating)")
}
print(movieratings)

//Adding a key value pair
movieratings["The Cabinet of Dr. Caligari"] = 3
print(movieratings)

//removing a key value pair
movieratings.removeValueForKey("Dark City")
print(movieratings)

//Also we can remove dictionary item by making the key value as nil
movieratings["Donnie Darko"] = nil
print(movieratings)

//Looping through the dictionary to get key value pairs

for (key, value) in movieratings{
    print("The movie \(key) was rated \(value)")
}
//Taking key- value pair as one variable movie and accessing both key and value
for movie in movieratings{
    print("User has rated \(movie)")
}

//Immutable Dictionary
let rates = ["Pizza" : 120 , "Burger" : 50 , "Sandwich" : 40]
for list in rates{
    print("Menu and its cost \(list)")
}

//Translating Dictionary to an array
let watchedMovies = Array(movieratings.keys) //Converting all key elements in dictionary to array
print(watchedMovies) //watchedMovies constant instance of array type

//Assignment chapter 11 silver challenge
var countryOne = [30306, 30307, 30308, 30309, 30310]
var countryTwo = [30311, 30312, 30313, 30314, 30315]
var countryThree = [30301, 30302, 30303, 30304, 30305]

var countryDict = ["India" : countryOne , "US" : countryTwo , "UK" : countryThree]
print(countryDict)
let loggedZipCodes = Array(countryDict.values)
print(loggedZipCodes)
