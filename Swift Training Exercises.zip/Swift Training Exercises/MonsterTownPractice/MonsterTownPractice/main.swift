//
//  main.swift
//  MonsterTownPractice
//
//  Created by swathi m on 1/27/16.
//  Copyright © 2016 swathi m. All rights reserved.
//

import Foundation

var town = Town()
print(town.population)
print(town.noOfStoplights)

town.printDescription()
town.changePopulation(34)
town.printDescription()

var monster = Monster()
//if monster.town == nil {
//    print("No value")
//    else {
//    monster.terrorize()
//    }
//}