//
//  MyTown.swift
//  MonsterTownPractice
//
//  Created by swathi m on 1/27/16.
//  Copyright © 2016 swathi m. All rights reserved.
//

import Cocoa

class Monster {
    var name = "Monster"
    var town : Town?
    
    func terrorize () {
        print("\(name) has population of \(town)")
    }
}