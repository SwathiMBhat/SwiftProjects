//
//  Town.swift
//  MonsterTownPractice
//
//  Created by swathi m on 1/27/16.
//  Copyright © 2016 swathi m. All rights reserved.
//

import Foundation

struct Town {
    var population = 2345
    var noOfStoplights = 3
    
    func printDescription(){
        print("\(town.population) \(town.noOfStoplights)")
    }
    
    mutating func changePopulation(popValue : Int) {
        population += popValue
    }
}