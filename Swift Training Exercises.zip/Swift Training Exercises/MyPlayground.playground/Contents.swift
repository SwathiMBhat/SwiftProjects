//: Playground - noun: a place where people can play

import Cocoa

var str = "Hello, playground"



//addition assignment operator
str += "!!!"
print(str)


//Assignment Chapter 2
var lastname = "Swathi"
print(lastname)

