//: Playground - noun: a place where people can play

import Cocoa

var str = "Hello, playground"

//Optional type declaration

var errorCodeString : String? //It can have a value or nil
errorCodeString = "404" //If i don't give value here errorCodeString will be nil
print(errorCodeString)  // Displays Optional(value) 

if errorCodeString != nil{
    let theError = errorCodeString! //Here we are doing forced unwrapping of the optional variable errorCodeString, if there is no value for errorCodeString it will give runtime error
    print(theError) //Result will be the actual value and not optional
}

//Optional Binding - Conditionally checks if there is a value in the optional variable

if let theErrorOptionalBinding = errorCodeString{ //Conditionally doing without unwrapping
    print(theErrorOptionalBinding)
}
if let theError = errorCodeString{
if let errorCodeInteger = Int(theError) {   //Converting theError to integer, Unwrapping theError to integer and placing in errorCodeInteger
    print("\(theError): \(errorCodeInteger)")
}
}

//Unwrapping Multiple optionals with a where clause
//errorCodeString = "405"
if let theError = errorCodeString{
    if let theError = errorCodeString , errorCodeInteger = Int(theError) where errorCodeInteger != 404 {   //Using two optionals
        print("\(theError): \(errorCodeInteger)")
    }
}

var errorCodeStringImplicit : String!
errorCodeStringImplicit = "12"
print(errorCodeStringImplicit)

//Modifying an Optional in place
var errorDescription: String?
if let theError = errorCodeString, errorCodeInteger = Int(theError) where errorCodeInteger == 404 {
    print("\(theError): \(errorCodeInteger)")
    errorDescription = ("\(errorCodeInteger + 200): the requested resource was not found.")
}
var upCaseErrorDescription = errorDescription?.uppercaseString
errorDescription
upCaseErrorDescription?.appendContentsOf("Please Try again") //Modifying an optional using appendsContentsof
upCaseErrorDescription

// Using nil coalescing operator
let description = errorDescription ?? "No error" // if there is an errorDescription optional it will return value of it otherwise it returns "No error"

//Assignment chapter 9 Optionals
var forceUnwrapppingVariable : String?
//var unwrapped = forceUnwrapppingVariable! // forceful unwrapping of a optional variable equal to nil