//
//  DemoFile.swift
//  Demo
//
//  Created by swathi m on 1/21/16.
//  Copyright © 2016 swathi m. All rights reserved.
//

import Cocoa

class Demo: NSView, NSDraggingSource {
    func draggingSession(session: NSDraggingSession,
      sourceOperationMaskForDraggingContext context: NSDraggingContext)-> NSDragOperation {
        return .Copy
    }
}
