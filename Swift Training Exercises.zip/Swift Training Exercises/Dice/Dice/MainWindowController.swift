//
//  MainWindowController.swift
//  Dice
//
//  Created by swathi m on 1/20/16.
//  Copyright © 2016 swathi m. All rights reserved.
//

import Cocoa

class MainWindowController: NSWindowController {
    var configurationWindowController: ConfigurationWindowController?
    
    override var windowNibName: String! {
        return "MainWindowController"
    }
    @IBAction func showDieConfiguration(sender: AnyObject?) {
       // print("Configuration menu item clicked")
        if let window = window, let dieView = window.firstResponder as? DieView {
            // Create and configure the window controller to present as a sheet:
            let windowController = ConfigurationWindowController()
           // windowController.configuration = DieConfiguration (color: dieView.color,
           // rolls: dieView.numberOfTimesToRoll)
            window.beginSheet(windowController.window!, completionHandler: { response in
            // The sheet has finished. Did the user click 'OK'?
            if response == NSModalResponseOK {
            let configuration = self.configurationWindowController!.configuration
            dieView.color = configuration.color
            dieView.numberOfTimesToRoll = configuration.rolls
            }
            // All done with the window controller.
            self.configurationWindowController = nil
            })
            configurationWindowController = windowController
        }
    }
    override func windowDidLoad() {
        super.windowDidLoad()

        // Implement this method to handle any initialization after your window controller's window has been loaded from its nib file.
    }
    
}
