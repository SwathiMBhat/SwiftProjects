//
//  ConfigurationWindowController.swift
//  Dice
//
//  Created by swathi m on 1/21/16.
//  Copyright © 2016 swathi m. All rights reserved.
//

import Cocoa

class ConfigurationWindowController: NSWindowController {
    var configuration : DieConfiguration {
        set {
            color = newValue.color
            rolls = newValue.rolls
        }
        get {
          return  DieConfiguration(color: color, rolls: rolls)
}
    }
    private dynamic var color: NSColor = NSColor.whiteColor()
    private dynamic var rolls: Int = 10
    
    override var windowNibName: String {
        return "ConfigurationWindowController"
    }
    @IBAction func okayButtonClicked(button: NSButton) {
        print("OK clicked")
        window?.endEditingFor(nil)
        dismissWithModalResponse(NSModalResponseOK)
    }
    @IBAction func cancelButtonClicked(button: NSButton) {
        print("Cancel clicked")
        dismissWithModalResponse(NSModalResponseCancel)
    }
    func dismissWithModalResponse(response: NSModalResponse) {
        window!.sheetParent!.endSheet(window!, returnCode: response)
    }
    struct DieConfiguration {
        let color: NSColor
        let rolls: Int
        init(color: NSColor, rolls: Int) {
        self.color = color
        self.rolls = max(rolls, 1)
        }
    }
//    override func windowDidLoad() {
//        super.windowDidLoad()

        // Implement this method to handle any initialization after your window controller's window has been loaded from its nib file.
//    }
    
}
