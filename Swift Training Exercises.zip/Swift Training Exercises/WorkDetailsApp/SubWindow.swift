//
//  SubWindow.swift
//  WorkDetailsApp
//
//  Created by swathi m on 2/25/16.
//  Copyright © 2016 swathi m. All rights reserved.
//

import Cocoa

class SubWindow: NSWindowController {

    override func windowDidLoad() {
        super.windowDidLoad()

        // Implement this method to handle any initialization after your window controller's window has been loaded from its nib file.
    }
    
}
