//
//  WorkingDetails.swift
//  WorkDetailsApp
//
//  Created by swathi m on 2/25/16.
//  Copyright © 2016 swathi m. All rights reserved.
//

import Cocoa

class WorkingDetails: NSWindowController {
    var windowVar : SubWindow?
    @IBOutlet var officeRadioButtonOutlet: NSButton!
    @IBOutlet var homeRadioButtonOutlet: NSButton!
   
    @IBAction func addSheetAction(sender: AnyObject) {
windowVar = SubWindow(windowNibName: "SubWindow")
       // window.show
        
    }
    @IBAction func homeOfficeRadioButtonAction(sender: AnyObject) {
        if(homeRadioButtonOutlet.integerValue == 0)
        {
            homeRadioButtonOutlet.enabled = true
        }
        else
        {
            officeRadioButtonOutlet.enabled = true
        }
        
    }
    override func windowDidLoad() {
        super.windowDidLoad()

        // Implement this method to handle any initialization after your window controller's window has been loaded from its nib file.
    }
    
    override var windowNibName:String?
        {
            return "WorkingDetails"
    }
}
