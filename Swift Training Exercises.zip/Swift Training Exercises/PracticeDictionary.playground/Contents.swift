//: Playground - noun: a place where people can play

import Cocoa

var str = "Hello, playground"

var dict1: Dictionary<String , Double> = [:]
var dict2 = Dictionary<String,Double>()
var dict3 : [String : Double] = [:]
var dict4 = [String:Double]()
var dict5 = [String:Double]()

let x = ["Hi" : 4 , "hello" : 5 , "morning" : 6]
var y = [x]
//y.append("Matt")

var movieRatings = ["Donnie" : 4 , "Express" : 5, "City" :5]


//Declaring Set
var groceryBag = Set<String> ()
var friendsGroceryBag : Set = ["Oranges" , "Apples" , "Pineapples"]
groceryBag.insert("Apples")
groceryBag.insert("Oranges")

for food in groceryBag{
    print(food)
}

//chk if bag contains bananas

let hasBananas = groceryBag.contains("Bananas")

let commonGroceryBag = groceryBag.union(friendsGroceryBag)
let intersectBag = groceryBag.intersect(friendsGroceryBag)
let disjoint = groceryBag.isDisjointWith(friendsGroceryBag)

let names : Set<String> = ["Swathi" ]
let namesB : Set<String> = ["Swathi"]



let jorseys : Set<Int> = [23,34,45]

let namesSets : Set<Set<NSObject>> = [names , jorseys , namesB] // Passing Set inside set

names == namesB // returns true if all the contents are same
//names == jorseys  //Set string and int cannot be compared


let result = names.subtract(namesB)
print(result)

var myCities = Set(["Atlanta", "Chicago",
    "Jacksonville", "New York", "San Francisco"])

var yourCities = Set(["Chicago", "San Francisco", "Jacksonville"])

myCities.unionInPlace(yourCities)
myCities.intersectInPlace(yourCities)
myCities.isSupersetOf(yourCities)
yourCities.isSubsetOf(myCities)
myCities.isStrictSupersetOf(yourCities)

enum Monster : Int? {
    case Zombie
    case Squid
}

monsterVariable = Monster.Zombie

