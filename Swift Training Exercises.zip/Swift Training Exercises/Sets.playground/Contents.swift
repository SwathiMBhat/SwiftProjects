//: Playground - noun: a place where people can play

import Cocoa

var str = "Hello, playground"


//Set is a type of unordered collection with unique elements

//Creating a set
var groceryBag = Set<String>()
groceryBag.insert("Apples")
groceryBag.insert("PineApple")
groceryBag.insert("Oranges")

//Looping thru a set and printing values
for fruit in groceryBag{
    print(fruit)
}

//Another way of creating a set
groceryBag = (["Apples" , "PineApple" , "Oranges" , "Bananas" , "Pomegranate"])
print(groceryBag)
for fruit in groceryBag{
    print(fruit)
}

//Example of joint sets
var friendsGroceryBag = Set (["Bananas","Guava","Melons"])
let commonGroceryBag = groceryBag.union(friendsGroceryBag)
print(commonGroceryBag)

//Assignment silver challenge chapter 12
//Here we are giving the union values to groceryBag
//groceryBag = groceryBag.union(friendsGroceryBag)

//Assignment Silver challenge chapter 12
//groceryBag = groceryBag.intersect(friendsGroceryBag)

var commonItems = groceryBag.intersect(friendsGroceryBag)
print(commonItems)

//Example of disjoint set
var disjointItems = groceryBag.isDisjointWith(friendsGroceryBag)
var anotherGroceryBag = Set (["Swathi" , "Veda" , "Sush"])
var secondDisjointItems = groceryBag.isDisjointWith(anotherGroceryBag)

let myCities = Set(["Atlanta", "Chicago", "Jacksonville", "New York", "San Francisco"])
let yourCities = Set(["Chicago", "San Francisco", "Jacksonville"])

//Assignment Chapter 12 bronze challenge
var allCities = yourCities.isSubsetOf(myCities)

