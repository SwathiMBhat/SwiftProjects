//
//  MainWindowController.swift
//  DemoRGBWell
//
//  Created by swathi m on 1/18/16.
//  Copyright © 2016 swathi m. All rights reserved.
//

import Cocoa

class MainWindowController : NSWindowController{
    override var windowNibName : String? {
        return "MainWindowController"
    }
}