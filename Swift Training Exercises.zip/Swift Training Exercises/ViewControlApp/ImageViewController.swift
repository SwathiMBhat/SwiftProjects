//
//  ImageViewController.swift
//  ViewControlApp
//
//  Created by swathi m on 1/22/16.
//  Copyright © 2016 swathi m. All rights reserved.
//

import Cocoa

class ImageViewController: NSViewController {
    var image: NSImage?
    override var nibName: String? {
        return "ImageViewController"
    }
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        // Do view setup here.
//    }
//}
}
