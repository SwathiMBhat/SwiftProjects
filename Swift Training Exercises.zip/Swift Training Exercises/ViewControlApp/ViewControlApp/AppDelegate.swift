//
//  AppDelegate.swift
//  ViewControlApp
//
//  Created by swathi m on 1/22/16.
//  Copyright © 2016 swathi m. All rights reserved.
//

import Cocoa

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {
var window: NSWindow?
    //@IBOutlet weak var window: NSWindow!


    func applicationDidFinishLaunching(aNotification: NSNotification) {
        let flowViewController = ImageViewController()
        flowViewController.title = "Flow"
        flowViewController.image = NSImage(named: NSImageNameFlowViewTemplate)
        let window = NSWindow(contentViewController: flowViewController)
        window.makeKeyAndOrderFront(self)
        self.window = window
        // Insert code here to initialize your application
    }

    func applicationWillTerminate(aNotification: NSNotification) {
        // Insert code here to tear down your application
    }


}

