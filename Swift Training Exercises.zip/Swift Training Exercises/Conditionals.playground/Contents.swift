//: Playground - noun: a place where people can play

import Cocoa


//IF, IF-ELSE NESTED IF

var str = "Hello, playground"
var population: Int = 542224
var message: String
var hasPostOffice : Bool = false
if population < 10000 {
    message = "\(population) is a small town!"
} else if population>=10000 && population<=50000{
        message = "\(population) is pretty medium!"
    }
else if population>=50000 && population<=60000{
    
    message = "\(population) is pretty big!"
    }
else{
 message = "\(population) is very big!"
}
print(message)
if !hasPostOffice {
    print("Where to buy stamps")
}

//Using Ternary operator Can be used instead of if else
message = population<10000 ? "\(population) is small town" : "\(population) is big"