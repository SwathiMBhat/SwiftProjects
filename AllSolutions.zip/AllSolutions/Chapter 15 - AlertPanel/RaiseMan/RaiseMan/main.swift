//
//  main.swift
//  RaiseMan
//
//  Created by Nate Chandler on 9/1/14.
//  Copyright (c) 2014 Big Nerd Ranch. All rights reserved.
//

import Cocoa

NSApplicationMain(Process.argc, Process.unsafeArgv)
