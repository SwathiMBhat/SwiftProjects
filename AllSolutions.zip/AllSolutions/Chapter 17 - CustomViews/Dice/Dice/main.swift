//
//  main.swift
//  Dice
//
//  Created by Adam Preble on 8/22/14.
//  Copyright (c) 2014 Big Nerd Ranch. All rights reserved.
//

import Cocoa

NSApplicationMain(Process.argc, Process.unsafeArgv)
