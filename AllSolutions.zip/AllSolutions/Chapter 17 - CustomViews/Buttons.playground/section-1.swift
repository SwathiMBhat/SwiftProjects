import Cocoa

let frame = NSRect(x: 0, y: 0,
                   width: 100, height: 100)
let button = NSButton(frame: frame)
button.bezelStyle = .RoundedBezelStyle
button.title = "I, Button"
button
