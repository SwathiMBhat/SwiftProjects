//
//  NoteFileModel.swift
//  NoteApp
//
//  Created by lakshmi r bhat on 02/08/16.
//  Copyright © 2016 swathi m. All rights reserved.
//

import Foundation
struct NoteFileModel {
    let cellIdentifier = "reuseIdentifier"
    let imageFilename = "note"
    let fileName = "Note one"
    let fileDetails = "10/07/2016 8:23am"
    var noteNames = ["Folder 1","Folder 2","Folder 3", "Folder 4"]
    var searchResults : [String] = []
    let fileImageName = "Files"
    let alertTitle = "New Folder"
    let alertMessage = "Enter Folder Name"
    let cancelText = "Cancel"
    let pickerData = ["Mozzarella","Gorgonzola","Provolone","Brie","Maytag Blue","Sharp Cheddar","Monterrey Jack","Stilton","Gouda","Goat Cheese", "Asiago"]
}
