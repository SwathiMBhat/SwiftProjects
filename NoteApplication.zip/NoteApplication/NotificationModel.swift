//
//  Notifications.swift
//  NoteApp
//
//  Created by lakshmi r bhat on 02/08/16.
//  Copyright © 2016 swathi m. All rights reserved.
//

import Foundation
enum NotificationModel:String {
    case left = "UpdateFrameLeft"
    case right = "UpdateFrameRight"
}
