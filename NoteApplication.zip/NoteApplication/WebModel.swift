//
//  WebModel.swift
//  NoteApp
//
//  Created by lakshmi r bhat on 02/08/16.
//  Copyright © 2016 swathi m. All rights reserved.
//

import Foundation
struct WebModel {
    let url = "https://www.google.co.in"
}
