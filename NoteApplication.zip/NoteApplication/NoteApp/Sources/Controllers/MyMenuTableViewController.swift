//
//  MyMenuTableViewController.swift
//  SwiftSideMenu
//
//  Created by Evgeny Nazarov on 29.09.14.
//  Copyright (c) 2014 Evgeny Nazarov. All rights reserved.
//

import UIKit

class MyMenuTableViewController: UITableViewController {
    var clip = ClipBoardViewController()
    var selectedMenuItem : Int = 0
    var array = ["Font","Annotate"]
    var images  = ["font", "anot"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        clip?.fontMenu = self
        NSNotificationCenter.defaultCenter().addObserver(self, selector:#selector(self.moveLeftNotification(_:)), name: "UpdateFrameLeft", object: nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector:#selector(self.moveRightNotification(_:)), name: "UpdateFrameRight", object: nil)

//        // Customize apperance of table view
//        tableView.contentInset = UIEdgeInsetsMake(150.0, 0, 0, 0) //
//        tableView.separatorStyle = .None
//        tableView.backgroundColor = UIColor.whiteColor()
//        tableView.scrollsToTop = false
//        // Preserve selection between presentations
//        self.clearsSelectionOnViewWillAppear = false
//        
//        tableView.selectRowAtIndexPath(NSIndexPath(forRow: selectedMenuItem, inSection: 0), animated: false, scrollPosition: .Middle)
        tableView.contentInset = UIEdgeInsetsMake(64.0, 0, 0, 0) //
        tableView.separatorStyle = .None
        tableView.backgroundColor = UIColor.whiteColor()
        tableView.scrollsToTop = false
        view.backgroundColor = UIColor.whiteColor()
        // Preserve selection between presentations
        self.clearsSelectionOnViewWillAppear = false
        
        tableView.selectRowAtIndexPath(NSIndexPath(forRow: selectedMenuItem, inSection: 0), animated: false, scrollPosition: .Middle)

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // Return the number of sections.
        return 1
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // Return the number of rows in the section.
        return 2
    }

    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        var cell = tableView.dequeueReusableCellWithIdentifier("CELL")
        
        if (cell == nil) {
            cell = UITableViewCell(style: UITableViewCellStyle.Default, reuseIdentifier: "CELL")
           // cell!.backgroundColor = UIColor.clearColor()
           // cell!.textLabel?.textColor = UIColor.darkGrayColor()
           // let selectedBackgroundView = UIView(frame: CGRectMake(0, 0, cell!.frame.size.width, cell!.frame.size.height))
           // selectedBackgroundView.backgroundColor = UIColor.grayColor().colorWithAlphaComponent(0.2)
           // cell!.selectedBackgroundView = selectedBackgroundView
        }
        // cell!.textLabel!.font = UIFont.systemFontOfSize(12.0)
        cell!.textLabel?.text = array[indexPath.row] as String
        let imageFile = images[indexPath.row]
        cell?.imageView?.image = UIImage(named: imageFile)
        return cell!
    }
    func moveLeftNotification(notification: NSNotification){
        //Take Action on Notification
        UIView.animateWithDuration(0.4, animations: {
            self.view.frame.origin.x = 100
            
        })
    }
    func moveRightNotification(notification: NSNotification){
        //Take Action on Notification
        UIView.animateWithDuration(0.4, animations: {
            self.view.frame.origin.x = 0
            
        })
    }
    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 50.0
    }
    override func tableView(tableView: UITableView,
                              didSelectRowAtIndexPath indexPath: NSIndexPath){
        print(indexPath.row)
        
        toggleSideMenuView()
        if indexPath.row == 1 {
           //clip.fontMenu.tabBarController?.tabBar.hidden = true
            ClipBoardViewController().tabBarController?.tabBar.hidden = true
//            self.hidesBottomBarWhenPushed = true
        }
        NSNotificationCenter.defaultCenter().postNotificationName(NotificationModel.right.rawValue, object: nil)

        UIView.animateWithDuration(0.4, animations: {
            self.view.frame.origin.x = self.isSideMenuOpen() ? (self.view.frame.origin.x + 100) : (self.view.frame.origin.x - 100)
            
        })
        //navigationController!.tabBarController?.tabBar.hidden = true
        //ClipBoardViewController().tabBarController?.tabBar.hidden = true
        
    }
    
//    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
//        
//        print("did select row: \(indexPath.row)")
//        
//        if (indexPath.row == selectedMenuItem) {
//            return
//        }
//        
//        selectedMenuItem = indexPath.row
//        
//        //Present new view controller
//        let mainStoryboard: UIStoryboard = UIStoryboard(name: "Main",bundle: nil)
//        var destViewController : UIViewController
//        switch (indexPath.row) {
//        case 0:
//            destViewController = mainStoryboard.instantiateViewControllerWithIdentifier("ViewController1") 
//            break
//        case 1:
//            destViewController = mainStoryboard.instantiateViewControllerWithIdentifier("ViewController2")
//            break
//        case 2:
//            destViewController = mainStoryboard.instantiateViewControllerWithIdentifier("ViewController3")
//            break
//        default:
//            destViewController = mainStoryboard.instantiateViewControllerWithIdentifier("ViewController4") 
//            break
//        }
//        sideMenuController()?.setContentViewController(destViewController)
//    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue!, sender: AnyObject!) {
        // Get the new view controller using [segue destinationViewController].
        // Pass the selected object to the new view controller.
    }
    */

}
