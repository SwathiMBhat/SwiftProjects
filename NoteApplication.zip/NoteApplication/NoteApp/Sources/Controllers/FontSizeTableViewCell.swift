//
//  FontSizeTableViewCell.swift
//  NoteApp
//
//  Created by lakshmi r bhat on 01/08/16.
//  Copyright © 2016 swathi m. All rights reserved.
//

import UIKit

class FontSizeTableViewCell: UITableViewCell {
    @IBOutlet weak var fontSizeLabel: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    @IBAction func fontSizeChange(sender: UISlider) {
        let senderValue = CGFloat(sender.value)
        fontSizeLabel.font = UIFont(name: (fontSizeLabel?.font.fontName)!, size: senderValue)
    }
}
