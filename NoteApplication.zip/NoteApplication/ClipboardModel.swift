//
//  ClipboardModel.swift
//  NoteApp
//
//  Created by vedashree k on 03/08/16.
//  Copyright © 2016 swathi m. All rights reserved.
//

import Foundation
import UIKit

struct ClipboardModel{
    var copiedContent : String = ""
    var copiedImg : UIImage? = nil
}
