//
//  AdvancedPreferencesViewController.swift
//  DontSleep
//
//  Created by avnish kumar on 10/02/16.
//  Copyright © 2016 avnish kumar. All rights reserved.
//

import Cocoa

let DSBatteryCapacityThresholdDidChangeNotification = "DSBatteryCapacityThresholdDidChangeNotification"
class AdvancedPreferencesViewController: NSViewController {

    var preferences:Array<Preference> = []
    
    // Determines if the current Mac has a built-in battery.
    var batteryStatusAvailable:Bool = BatteryStatus().batteryStatusAvilable
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        self.configureAdvancedPreferences()
    }
    
    override func viewWillAppear() {
        self.preferredContentSize = self.view.fittingSize
    }
    
    func configureAdvancedPreferences()
    {
        var preferences = Array<Preference>()
        preferences.append(Preference(title: "Allow the display to sleep (when connected to AC power)", defaultKey: DSUserDefaultsKeyAllowDisplaySleep))
        preferences.append(Preference(title: "Disable menu bar icon highlight color",defaultKey:DSUserDefaultsKeyMenuBarIconHighlightDisabled))
        self.preferences = preferences
    }
    
    // Mark: - Battery Status Preferences
    
    @IBAction func batteryStatusPreferencesChanged(sender:AnyObject)
    {
        NSNotificationCenter.defaultCenter().postNotificationName(DSBatteryCapacityThresholdDidChangeNotification, object: nil)
    }

    
    // MARK: -Table View Delegate & Data Source
    
    func numberOfRowsInTableView(tableView: NSTableView) -> Int
    {
        return self.preferences.count
    }
    
    func tableView(tableView: NSTableView,
        objectValueForTableColumn tableColumn: NSTableColumn?,
        row: Int) -> AnyObject?
    {
           return self.preferences[row]
    }
    
}
