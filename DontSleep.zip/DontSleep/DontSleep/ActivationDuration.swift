//
//  ActivationDuration.swift
//  DontSleep
//
//  Created by avnish kumar on 11/02/16.
//  Copyright © 2016 varsha sambhajirao aware. All rights reserved.
//

import Cocoa

let DSActivationDurationIndefinite = 0
class ActivationDuration: NSObject {

    var seconds:NSTimeInterval
    var displayUnit:NSCalendarUnit
    
    var localizedTitle:NSString{
        get{
            
            
            let interval = self.seconds;
            
            if(interval == 0)
            {
                return NSLocalizedString("Indefinitely", tableName: nil,comment:"");
            }
            
            let formatter = self.sharedDateComponentsFormatter();
            formatter.allowedUnits = self.displayUnit;
            
            return formatter.stringFromTimeInterval(interval)!;
        }
    }
    
    override var description: String {
        
        get{
            
            return "\(super.description) (\(self.localizedTitle))"
        }
    }
    
    
     init(seconds:NSTimeInterval)
     {
        self.seconds = seconds
        self.displayUnit = NSCalendarUnit.Second
        super.init()
     }
    
    init(seconds:NSTimeInterval, displayUnit:NSCalendarUnit)
    {
        self.seconds = seconds
        self.displayUnit = displayUnit
        super.init()
    }
    
   //  MARK: - Localized Formatter
    
    func sharedDateComponentsFormatter()->NSDateComponentsFormatter
    {
        var once:dispatch_once_t = 0
        var sharedFormatter:NSDateComponentsFormatter?
        
        dispatch_once(&once) { () -> Void in
            
            sharedFormatter = NSDateComponentsFormatter()
            sharedFormatter!.unitsStyle = NSDateComponentsFormatterUnitsStyle.Full
        }
        
       
        return sharedFormatter!
    }
    
    
}

// MARK: - Convenience Helper Functions

func DSMinutesToSeconds(minutes:NSInteger)->NSTimeInterval
{
    return NSTimeInterval(Float(minutes) * 60.0)
}

 func DSHoursToSeconds(hours:NSInteger)->NSTimeInterval
{
    return NSTimeInterval(Float(hours) * 3600.0)
}


func  DSDurationForSeconds(seconds:Int)->ActivationDuration
{
    return ActivationDuration(seconds: NSTimeInterval(seconds))
}

func DSDurationForMinutes(minutes:NSInteger)->ActivationDuration
{
    return ActivationDuration(seconds: DSMinutesToSeconds(minutes), displayUnit: NSCalendarUnit.Minute)
}

func  DSDurationForHours(hours:NSInteger)->ActivationDuration
{
    return ActivationDuration(seconds: DSHoursToSeconds(hours), displayUnit: NSCalendarUnit.Hour)
}

