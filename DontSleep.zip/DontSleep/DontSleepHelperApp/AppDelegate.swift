//
//  AppDelegate.swift
//  DontSleepHelperApp
//
//  Created by avnish kumar on 25/02/16.
//  Copyright © 2016 avnish kumar. All rights reserved.
//

import Cocoa

//This is  Helper application. its sole job is to find out the path for the main application, launch it, and then terminate itself.
@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {


    func applicationDidFinishLaunching(aNotification: NSNotification) {
        
        let path = NSBundle.mainBundle().bundlePath as NSString
        var components = path.pathComponents as NSArray
        
        components = components.subarrayWithRange(NSRange(location: 0, length: components.count - 4))
        
        let newPath = NSString.pathWithComponents(components as! [String])
        
        
        NSWorkspace.sharedWorkspace().launchApplication(newPath)
        
        
        NSApp.terminate(nil)
    }

    func applicationWillTerminate(aNotification: NSNotification) {
        // Insert code here to tear down your application
    }


}

