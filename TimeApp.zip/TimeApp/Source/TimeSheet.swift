//
//  TimeSheet.swift
//  TimeApp
//
//  Created by swathi m on 4/11/16.
//  Copyright © 2016 medidi vv satyanarayana murty. All rights reserved.
//

import Foundation

struct Duration {
    
    var hr: Int?
    var min: Int?
    var amPm: String?
    var endTime: String?
    var startTime: String?
    
}

struct ActivityFrame {
    
    var col: Int?
    var row: Int?
    var cell: NSRect?
    var height : CGFloat = 0
    var y : CGFloat = 0
    var location: CGPoint = CGPoint.zero
}