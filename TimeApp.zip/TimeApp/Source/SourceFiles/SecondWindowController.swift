//
//  SecondWindowController.swift
//  ReportTimeMacApp
//
//  Created by swathi m on 2/4/16.
//  Copyright © 2016 swathi m. All rights reserved.
//

import Cocoa

class SecondWindowController: NSWindowController {
    
    @IBOutlet var abstractArrayControllerOutlet: NSArrayController!
    @IBAction func abstractSearchCloseButtonAction(sender: NSButton) {
        window?.close()
    }
    override func windowDidLoad() {
        super.windowDidLoad()
    }
}
