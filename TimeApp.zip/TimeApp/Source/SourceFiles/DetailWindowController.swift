//
//  DetailWindowController.swift
//  ReportTimeMacApp
//
//  Created by swathi m on 2/4/16.
//  Copyright © 2016 swathi m. All rights reserved.
//

import Cocoa

class DetailWindowController: NSWindowController {
    @IBOutlet var detailArrayController: NSArrayController!
     override func windowDidLoad() {
        super.windowDidLoad()
    }
    
    @IBAction func detailWindowCloseButtonAction(sender: NSButton) {
        window?.close()
    }
    
    
    
    
    
    
    
    
    
    
}







