//
//  LoginWindow.swift
//  TimeTime
//
//  Created by medidi vv satyanarayana murty on 02/02/16.
//  Copyright © 2016 Medidi vv satyanarayana murty. All rights reserved.
//

import Cocoa

let Keychain_keyName = "password"

class LoginWindow: NSWindowController,NSWindowDelegate
{
    @IBOutlet var userName: NSTextField!
    @IBOutlet var password: NSSecureTextField!
    @IBOutlet var loginButton: NSButton!
    @IBOutlet var indicator: NSProgressIndicator!
    @IBOutlet var createButton: NSButton!
    @IBOutlet var forgotPasswordButton: NSButton!
    @IBOutlet var confirmPassword: NSSecureTextField!
    @IBOutlet weak var windowAction: NSTextField!
    @IBOutlet var loginView: NSView!
    
    let createButtonTag = 0
    let loginButtonTag = 1
    
    let keyChain = KeychainSwift()

    var forgotPassword:ForgotPasswordWindow? = nil
    var timeTableView: TimeTableView?
    
    override func windowDidLoad()
    {
        window?.delegate = self
        forgotPassword = ForgotPasswordWindow(windowNibName: "ForgotPasswordWindow")
        forgotPassword?.loginWindowController = self
        window?.backgroundColor = NSColor.lightGrayColor()
        super.windowDidLoad()
        loginView.wantsLayer = true
        loginView.layer?.backgroundColor = NSColor.grayColor().CGColor
        borderDetails()
        
        if let storedUsername = NSUserDefaults.standardUserDefaults().valueForKey("username") as? String
        {
            loginBtn(storedUsername)
        }
        else
        {
            createBtn()
        }
    }
    

    func createBtn()
    {
        createButton.hidden = true
        forgotPasswordButton.hidden = true
        
        print(" No user Found ")
        loginButton.title = "Create"
        windowAction.stringValue = "Create Window"
        loginButton.tag = createButtonTag
    }
    
    func loginBtn(storedUsername:String)
    {
        confirmPassword.hidden = true
        userName.stringValue = storedUsername as String
        loginButton.title = "LogIn"
        windowAction.stringValue = "Login Window"
        loginButton.tag = loginButtonTag
    }
    
    /* Border Color Change While Enter credentials are Wrong */
    
    func borderDetails ()
    {
        password.wantsLayer = true
        password.layer?.borderWidth = 1.0
        password.layer?.borderColor = NSColor.whiteColor().CGColor
        
        confirmPassword.wantsLayer = true
        confirmPassword.layer?.borderWidth = 1.0
        confirmPassword.layer?.borderColor = NSColor.whiteColor().CGColor
        
        userName.wantsLayer = true
        userName.layer?.borderWidth = 1.0
        userName.layer?.borderColor = NSColor.whiteColor().CGColor
    }
    
    func borderColorEnable()
    {
        password.layer?.borderColor = NSColor.redColor().CGColor
        confirmPassword.layer?.borderColor = NSColor.redColor().CGColor
    }
    
    func borderColorDisable()
    {
        password.layer?.borderColor = NSColor.whiteColor().CGColor
        confirmPassword.layer?.borderColor = NSColor.whiteColor().CGColor
    }
    
    func userNameColorDisable()
    {
        if userName.stringValue != ""
        {
            userName.layer?.borderColor = NSColor.whiteColor().CGColor
            
        }
    }
    
    func clearobjects()
    {
        let defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults()
        defaults.removeObjectForKey("username")
        keyChain.delete(Keychain_keyName)
    }
    
    /* Window Resize */
    
    func windowWillResize(sender: NSWindow, toSize frameSize: NSSize) -> NSSize
    {
        return NSSize(width: 651.0, height:390.0)
    }

    override var windowNibName:String
    {
        return "LoginWindow"
    }

    /*  Here it's create new userAccount  */
    
    @IBAction func resetFields(sender: NSButton)
    {
        
        clearobjects()
        
        createButton.hidden = true
        forgotPasswordButton.hidden = true
        confirmPassword.hidden = false
        
        borderColorDisable()
        
        password.stringValue = ""
        userName.stringValue = ""
        confirmPassword.stringValue = ""
        loginButton.title = "Create"
        windowAction.stringValue = "Create Window"
        loginButton.tag = createButtonTag
        
        
    }
    
    /* ForgotPasswordAction */
    
    @IBAction func forgotPassword(sender: NSButton)
    {
        self.window?.close()
        forgotPassword!.showWindow(self)
    }
    
    
    /* LoginCredentials */
    
    @IBAction func login(sender: NSButton)
    {
        if sender.tag == loginButtonTag
        {
           
            if (userName.stringValue != "" && password.stringValue != "")
            {
                if checkLogin(userName.stringValue, password: password.stringValue)
                {
                    indicator.startAnimation(true)
                    
                    password.layer?.borderColor = NSColor.whiteColor().CGColor
                    
                    self.window?.close()
                    confirmPassword.hidden = true

                    let timeTableView = TimeTableView()
                    self.timeTableView = timeTableView
                    self.timeTableView?.loginWindowController = self
                    timeTableView.window!.acceptsMouseMovedEvents = true
                    
                }
                else
                {
                    password.layer?.borderColor = NSColor.redColor().CGColor
                    password.stringValue = ""
                }
                
            }
            else
            {
                password.layer?.borderColor = NSColor.redColor().CGColor
            }
        }
        else
        {
            if (userName.stringValue == ""  && password.stringValue == "" && confirmPassword.stringValue == "")
            {
                userName.layer?.borderColor = NSColor.redColor().CGColor
                borderColorEnable()
            }
            else
            {
                let hasKey = NSUserDefaults.standardUserDefaults().boolForKey("hasLoginKey")
                if hasKey == false
                {
                    NSUserDefaults.standardUserDefaults().setObject(userName.stringValue, forKey: "username")
                }

                keyChain.set(password.stringValue, forKey: Keychain_keyName)
                if (password.stringValue.characters.count > 6 )
                {
                    if confirmPassword.stringValue == password.stringValue && confirmPassword.stringValue != ""
                    {
                        indicator.startAnimation(true)
                    
                        validate(Validation.ispassword(password))
                        validate(Validation.isconfirmPassword(confirmPassword,password:password))
                        
                        password.stringValue = ""
                    
                        createButton.hidden = false
                        forgotPasswordButton.hidden = false
                        confirmPassword.hidden = true
                        
                        password.layer?.borderColor = NSColor.whiteColor().CGColor

                        loginButton.title = "LogIn"
                        windowAction.stringValue = "Login Window"
                        loginButton.tag = loginButtonTag
                    
                        indicator.stopAnimation(true)
                    }
                    else
                    {
                        if password.stringValue != ""
                        {
                            confirmPassword.stringValue =  ""
                            password.layer?.borderColor = NSColor.whiteColor().CGColor
                        }
                        else
                        {
                            borderColorEnable()
                            userNameColorDisable()
                        }
                        clearobjects()
                        print("Creation Field Please Create Again")
                        createBtn()
                    }
            }
            else
            {
                let alert = NSAlert()
                alert.messageText = "Password weak"
                alert.informativeText = "Password should be of minimum 6 characters,with atleast one Uppercase letter , One digit and One special character"
                alert.runModal()
                    
                password.stringValue = ""
                confirmPassword.stringValue = ""
                    
                clearobjects()
                    
                userNameColorDisable()
                borderColorEnable()
                createBtn()
            }
        }
    }
}
    
    /* Validations for username And Password */
    
    func checkLogin(username: String, password: String ) -> Bool
    {
        if (password == keyChain.get (Keychain_keyName)) && username == (NSUserDefaults.standardUserDefaults().valueForKey("username") as? String)!
        {
            return true
        }
        else
        {
            return false
        }
    }
    
    /* Global Validations for username And Password*/
    
    func validate(validateError:ValidationTimeError)
    {
        switch validateError
        {
            case .Password:
                
            let alert = NSAlert()
            alert.messageText = "Warning "
            alert.informativeText = "InvalidPassword "
            alert.runModal()
            
            case.ConfirmPassword:
            let alert = NSAlert()
            alert.messageText = "Error"
            alert.informativeText = "ConfirmPasswordNotMatched"
            alert.runModal()
            
            case .EmptyString(let text):
            let alert = NSAlert()
            alert.messageText = "Warning"
            alert.informativeText = "\(text.placeholderString!) should not empty"
            alert.addButtonWithTitle("OK")
            alert.runModal()
            
            default: break
                
            // print("Success")
        }
    }
}


