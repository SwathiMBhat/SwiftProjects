//
//  MCQuestionTableViewCell.swift
//  TraningApp
//
//  Created by vedashree k on 16/06/16.
//  Copyright © 2016 basagond a mugganauar. All rights reserved.
//

import UIKit

class MCQuestionTableViewCell1: UITableViewCell {

    @IBOutlet var options: [UILabel]!
    
   @IBOutlet var checkBoxButtons: [CheckBox]!
    @IBOutlet weak var questionNumber: UILabel!
    @IBOutlet weak var questionLabel: UILabel!
    
    @IBOutlet weak var optionA: UILabel!
    
    @IBOutlet weak var optionB: UILabel!
    
    @IBOutlet weak var optionC: UILabel!
    
    @IBOutlet weak var optionD: UILabel!
    let checkedImage = UIImage(named: "checked")! as UIImage
    let uncheckedImage = UIImage(named: "unchecked")! as UIImage
    // var isChecked : Bool = false
    
    @IBAction func selectAnswer(sender: UIButton) {
        for button in checkBoxButtons{
            if button != sender{
                if button.isChecked == true{
                    button.isChecked = false
                }
            }
            else{
                button.isChecked = !(button.isChecked)
            }
        }
        
        
    }
    
    
   
   
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }


}
