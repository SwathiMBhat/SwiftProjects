//
//  SelEctTempletViewController.swift
//  TraningApp
//
//  Created by basagond a mugganauar on 09/06/16.
//  Copyright © 2016 basagond a mugganauar. All rights reserved.
//

import UIKit

class SelEctTempletViewController: UIViewController {
    
    @IBOutlet var mcqTempletButton: UIButton!
    @IBOutlet var matchTheFollowingButton: UIButton!
    @IBOutlet var fillInTheBoxButton: UIButton!
    @IBOutlet var yesNoButton: UIButton!
    @IBOutlet var programOutputButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        createButtons()
       
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
 
    func createButtons()
    {
        mcqTempletButton.layer.shadowColor = UIColor.blackColor().CGColor
        mcqTempletButton.layer.shadowOffset = CGSizeMake(5, 5)
        mcqTempletButton.layer.shadowRadius = 10
        mcqTempletButton.layer.shadowOpacity = 1.0
        
        matchTheFollowingButton.layer.shadowColor = UIColor.blackColor().CGColor
        matchTheFollowingButton.layer.shadowOffset = CGSizeMake(5, 5)
        matchTheFollowingButton.layer.shadowRadius = 10
        matchTheFollowingButton.layer.shadowOpacity = 1.0
        
        fillInTheBoxButton.layer.shadowColor = UIColor.blackColor().CGColor
        fillInTheBoxButton.layer.shadowOffset = CGSizeMake(5, 5)
        fillInTheBoxButton.layer.shadowRadius = 10
        fillInTheBoxButton.layer.shadowOpacity = 1.0
        
        yesNoButton.layer.shadowColor = UIColor.blackColor().CGColor
        yesNoButton.layer.shadowOffset = CGSizeMake(5, 5)
        yesNoButton.layer.shadowRadius = 10
        yesNoButton.layer.shadowOpacity = 1.0
        
        programOutputButton.layer.shadowColor = UIColor.blackColor().CGColor
        programOutputButton.layer.shadowOffset = CGSizeMake(5, 5)
        programOutputButton.layer.shadowRadius = 10
        programOutputButton.layer.shadowOpacity = 1.0

    }
    
    @IBAction func clickToSetNumberOfQuestions(sender: UIButton)
    {
        
                    self.performSegueWithIdentifier("mtfSegueIdentifier", sender: self)
           }
    @IBAction func clickToSetMCQ(sender: UIButton) {
        
                self.performSegueWithIdentifier("mcqSegueIdentifier", sender: self)
            }
    
    @IBAction func clickToSetFillInTheBlancksQuestions(sender: AnyObject) {
        
                self.performSegueWithIdentifier("fibSegueIdentifier", sender: self)
            }
    @IBAction func clickToSetOptionalsQuestions(sender: AnyObject) {
        
                self.performSegueWithIdentifier("optSegueIdentifier", sender: self)
            }
    
    @IBAction func prepareForUnwind(segue: UIStoryboardSegue){
        
    }
    @IBAction func close(segue:UIStoryboardSegue) {
        
    }
}
