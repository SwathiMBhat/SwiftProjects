//
//  Participant.swift
//  TrainingManagementApp
//
//  Created by sowmyashree nanjappa on 21/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import Foundation

class Participant: NSObject {
   let name:String?
   let role:String?
    var mailId:String?
    var image:String?
    var chatimage:String
    var callImage:String
    init(name:String,role:String,mailId:String,image:String,callImage:String,chatimage:String) {
        self.name = name
        self.role = role
        self.mailId = mailId
        self.image = image
        self.callImage = callImage
        self.chatimage = chatimage
    }
}