//
//  ProgramOutputViewController.swift
//  TraningApp
//
//  Created by swathi m on 6/15/16.
//  Copyright © 2016 basagond a mugganauar. All rights reserved.
//

import UIKit

class ProgramOutputViewController: UIViewController {

    @IBOutlet var question: UITextView!
    
    @IBOutlet var answer: UITextField!
    
    @IBOutlet var questionNumber: UILabel!
    
    @IBOutlet var briefDescription: UITextView!
    
    var count = 1
    
//    var coreData : CoreData?
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        coreData = CoreData()
        // Do any additional setup after loading the view.
    }

        
    @IBAction func nextButton(sender: UIButton) {
        if question.text == "" || answer.text == ""
        {
            let alertController = UIAlertController(title: "Textfields are empty", message:
                "Please enter text in textfield", preferredStyle: UIAlertControllerStyle.Alert)
            alertController.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.Default,
                handler: nil))
            self.presentViewController(alertController, animated: true, completion: nil)
            
        }
        else {
            
//            coreData?.insert(question.text!, answer: answer.text!, briefDescription : briefDescription.text!, questionNumber: String(count))
            
            count += 1
            questionNumber.text = String(count)
            question.text = ""
            answer.text = ""
            briefDescription.text = ""
        }
        
    }

    
//    @IBAction func clickToSave(sender: UIBarButtonItem) {
//        let secondViewController = self.storyboard?.instantiateViewControllerWithIdentifier("Home") as! TemplatesTableViewController
//        self.presentViewController(secondViewController, animated: true, completion: nil)
//    }
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "ProgramOutputButtonSegue" {
            let destinationController = segue.destinationViewController as! ProgramOutputTableViewController
//            coreData?.fetchProgramOutputList()
//            destinationController.programOutput = (coreData?.ProgramOutputArray)!
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func resetAction(sender: UIButton) {
        question.text = ""
        answer.text = ""
        briefDescription.text = ""
    }
    @IBAction func backToPO(segue:UIStoryboardSegue)
    {
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
