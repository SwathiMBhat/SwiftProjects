//
//  FillInTheBlanks.swift
//  TraningApp
//
//  Created by swathi m on 6/17/16.
//  Copyright © 2016 basagond a mugganauar. All rights reserved.
//

import Foundation
import CoreData


class FillInTheBlanks: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
