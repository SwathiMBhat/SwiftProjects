//
//  TrainerHomeTableViewController.swift
//  TrainingManagementApp
//
//  Created by sowmyashree nanjappa on 14/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import UIKit

class TrainerHomeTableViewController: UITableViewController {
   var sessionArray :[Session] = [Session(session: "Session-Gates", date: "12-2-2015", place: "Richmond", time: "12:15PM"),Session(session: "Session-Circits", date: "13-2-2015", place: "Richmond", time: "12:30 PM"),Session(session: "Session-Minimization", date: "12-2-2015", place: "Audugodi", time: "4:00 PM"),Session(session: "Session- K-Map", date: "13-2-2015", place: "Shanthi nagar", time: "10:00 AM"),]
    var role:String?
  var session = [String]()
    
    @IBOutlet var sessionButton: UIBarButtonItem!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
       self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "Sessions", style: .Plain, target: self, action: nil)
        if role == "Admin"
        {
        navigationItem.rightBarButtonItem = sessionButton
        
        }
        else
        {
        navigationItem.rightBarButtonItem = nil
        
        }
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }

    @IBAction func sessionCreation(sender: AnyObject)
    {
        
         performSegueWithIdentifier("NewSessionCreation", sender: self)
        
//        let storyboard = UIStoryboard(name: "Admin", bundle: nil)
//        let controller = storyboard.instantiateViewControllerWithIdentifier("AdminCall") as! AdminSessionTableViewController
//        self.presentViewController(controller, animated: true, completion: nil)
        
        let alert = UIAlertController(title: "New Session Name",
                                      message: "Add a new session Details",
                                      preferredStyle: .Alert)
        
        let saveAction = UIAlertAction(title: "Save",
                                       style: .Default,
                                       handler: { (action:UIAlertAction) -> Void in
                                        
                                    let textField = alert.textFields!.first
                                     self.session.append(textField!.text!)
                                
                                        let textField1 = alert.textFields?.first
                                        self.session.append(textField1!.text!)
                                        
                                        self.tableView.reloadData()
        })
        
        
        let cancelAction = UIAlertAction(title: "Cancel",
                                         style: .Default) { (action: UIAlertAction) -> Void in
        }
        
        alert.addTextFieldWithConfigurationHandler
            {
                (textField: UITextField) -> Void in
            
        }
        alert.addTextFieldWithConfigurationHandler
            {
                (textField: UITextField) -> Void in
                
        }
        
        
        alert.addAction(saveAction)
        alert.addAction(cancelAction)
        
        presentViewController(alert,
                              animated: true,
                              completion: nil)
        
    }
   
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
      return sessionArray.count
       //return session.count
    }

  
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("SessionCell", forIndexPath: indexPath) as! SessionTableViewCell
        cell.sessionName.text = sessionArray[indexPath.row].session
        cell.sessionDate.text = sessionArray[indexPath.row].date
        cell.sessionTime.text = sessionArray[indexPath.row].time
        cell.sessionVenue.text = sessionArray[indexPath.row].place
        
   //  cell.sessionName.text = session[indexPath.row]

        
        if indexPath.row == 0
        {
        cell.selected = true
            cell.highlighted = true
        }
        return cell
    }
  
//    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
//        let viewController = segue.destinationViewController as! SessionDetailedViewController
//        viewController.role = role
//    }
    
    @IBAction func clickToCreateNewAssessment(sender: UIBarButtonItem) {
        
        
        
        
    }
    /*
    // Override to support conditional editing of the table view.
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == .Delete {
            // Delete the row from the data source
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
        } else if editingStyle == .Insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
