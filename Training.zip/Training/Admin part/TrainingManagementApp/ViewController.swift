//
//  ViewController.swift
//  StudentAssessment
//
//  Created by varsha sambhajirao aware on 14/06/16.
//  Copyright © 2016 varsha sambhajirao aware. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var button1: UIButton!
    @IBOutlet weak var button2: UIButton!
    @IBOutlet weak var button3: UIButton!
    @IBOutlet weak var button4: UIButton!
    
    @IBOutlet weak var falseButton: UIButton!
    @IBOutlet weak var trueButton: UIButton!
    let checkedImage = UIImage(named:"Checked1")! as UIImage
    let uncheckedImage=UIImage(named:"Unchecked1")! as UIImage
   
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func checkBoxChecked(sender: AnyObject) {
        if sender.tag == button1.tag{
               button1.setImage(checkedImage, forState: .Normal)
               button2.setImage(uncheckedImage, forState: .Normal)
               button3.setImage(uncheckedImage, forState: .Normal)
               button4.setImage(uncheckedImage, forState: .Normal)
               }
        if sender.tag == button2.tag{
            button1.setImage(uncheckedImage, forState: .Normal)
            button2.setImage(checkedImage, forState: .Normal)
            button3.setImage(uncheckedImage, forState: .Normal)
            button4.setImage(uncheckedImage, forState: .Normal)
            

        }
        if sender.tag == button3.tag{
            button1.setImage(uncheckedImage, forState: .Normal)
            button2.setImage(uncheckedImage, forState: .Normal)
            button3.setImage(checkedImage, forState: .Normal)
            button4.setImage(uncheckedImage, forState: .Normal)
           

        }
        if sender.tag == button4.tag{
            button1.setImage(uncheckedImage, forState: .Normal)
            button2.setImage(uncheckedImage, forState: .Normal)
            button3.setImage(uncheckedImage, forState: .Normal)
            button4.setImage(checkedImage, forState: .Normal)
            

        }

}
    
    @IBAction func trueFalseAction(sender: UIButton) {
        if sender.tag == trueButton.tag{
            trueButton.setImage(checkedImage, forState: .Normal)
            falseButton.setImage(uncheckedImage, forState: .Normal)
           
        }
        if sender.tag == falseButton.tag{
            trueButton.setImage(uncheckedImage, forState: .Normal)
            falseButton.setImage(checkedImage, forState: .Normal)
        }

    }
    
}
