//
//  JumbledQuestionsViewController.swift
//  TraningApp
//
//  Created by varsha sambhajirao aware on 22/06/16.
//  Copyright © 2016 basagond a mugganauar. All rights reserved.
//

import UIKit

class JumbledQuestionsViewController: UIViewController {

    
    @IBOutlet weak var sentence1: UITextField!
    @IBOutlet weak var sentence2: UITextField!
    @IBOutlet weak var sentence3: UITextField!
    @IBOutlet weak var sentence4: UITextField!
    @IBOutlet weak var answer: UITextField!
    @IBOutlet weak var sentence5: UITextField!
    
    @IBOutlet weak var sentence6: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    @IBAction func nextClicked(sender: UIButton) {
        sentence1.text=nil
        sentence2.text=nil
        sentence3.text=nil
        sentence4.text=nil
        sentence5.text=nil
        sentence6.text=nil
        answer.text=nil
    }
    
//    @IBAction func clickToSave(sender: UIBarButtonItem) {
//        
//        
////        let alertView = UIAlertController(title: "Success", message: "Questions submitted successfully.", preferredStyle: .Alert)
////        
////        
////        alertView.addAction(UIAlertAction(title: "OK", style: .Default, handler:nil))
////        presentViewController(alertView, animated: true, completion: nil)
//        
//        let secondViewController = self.storyboard?.instantiateViewControllerWithIdentifier("Home") as! TemplatesTableViewController
//        self.presentViewController(secondViewController, animated: true, completion: nil)
//   
//    }
    @IBAction func backToJB(segue:UIStoryboardSegue)
    {
        
    }

    
    
}

