//
//  TemplatesTableViewController.swift
//  TraningApp
//
//  Created by basagond a mugganauar on 23/06/16.
//  Copyright © 2016 basagond a mugganauar. All rights reserved.
//

import UIKit

class TemplatesTableViewController: UITableViewController {

    let templates = ["MCQ", "Fill in the blank", "Match the following", "YesNo", "Jumbled", "Ask Opinion", "Form Question", "Program Output","Odd One Out","image_Related_Question"]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
            }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // MARK: - Table view data source
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        
        return 1
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return templates.count
    }
    
    override func tableView(tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
       
        return "Templates"
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("Cell", forIndexPath: indexPath)
        
        
        cell.textLabel?.text = templates[indexPath.row]
        let imageFilename = templates[indexPath.row].lowercaseString.stringByReplacingOccurrencesOfString(" ", withString: "_", options: [], range: nil)
      
        var cellImg : UIImageView = UIImageView(frame: CGRectMake(5, 5, 40, 40))
        cellImg.image = UIImage(named: imageFilename)
        cell.addSubview(cellImg)
            //cell.imageView?.image = UIImage(named: imageFilename)
                    cell.separatorInset.left = 50.0
            cell.separatorInset.right = 50.0
            cell.separatorInset.top = 80.0
            cell.separatorInset.bottom = 80.0
            cell.layer.cornerRadius = 10.0
        
            cell.imageView!.clipsToBounds = true;
            cell.imageView!.layer.borderWidth = 2;

            cell.imageView!.layer.cornerRadius = 10;
            cell.textLabel!.font = UIFont.systemFontOfSize(14.0)
            return cell
    }
    
    
    @IBAction func previewAction(sender: UIBarButtonItem) {
        let secondViewController = self.storyboard?.instantiateViewControllerWithIdentifier("Preview") as! GlobalPreviewViewController
        self.presentViewController(secondViewController, animated: true, completion: nil)
        
    }

    
    
    override func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 40
    }
    
    override func tableView(tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int) {
        
        let headerView = view as! UITableViewHeaderFooterView
        headerView.textLabel?.textColor = UIColor.orangeColor()
        headerView.textLabel?.font = UIFont(name: "Avenir", size: 14.0)
}
    
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
                if (indexPath.row == 0)
                {
                    let nextViewController = self.storyboard?.instantiateViewControllerWithIdentifier("MCQ") as! mcqViewController
                    self.presentViewController(nextViewController, animated: true, completion: nil)
                    
            }

            else if (indexPath.row == 1)
            {
                let firstViewController = self.storyboard?.instantiateViewControllerWithIdentifier("FIB") as!    fillInTheBlancksViewController
            self.presentViewController(firstViewController, animated: true, completion: nil)
            }
            else if(indexPath.row == 2)
            {
                    let secondViewController = self.storyboard?.instantiateViewControllerWithIdentifier("MTF") as! matchTheFollowingViewController
                self.presentViewController(secondViewController, animated: true, completion: nil)
            }
                else if(indexPath.row == 3)
                {
                    let secondViewController = self.storyboard?.instantiateViewControllerWithIdentifier("YN") as! YesOrNoViewController
                    self.presentViewController(secondViewController, animated: true, completion: nil)
        }
                else if(indexPath.row == 4)
                {
                    let secondViewController = self.storyboard?.instantiateViewControllerWithIdentifier("JB") as! JumbledQuestionsViewController
                    self.presentViewController(secondViewController, animated: true, completion: nil)
        }
                else if(indexPath.row == 5)
                {
                    let secondViewController = self.storyboard?.instantiateViewControllerWithIdentifier("AO") as! YourOpinionViewController
                    self.presentViewController(secondViewController, animated: true, completion: nil)
        }
                else if(indexPath.row == 6)
                {
                    let secondViewController = self.storyboard?.instantiateViewControllerWithIdentifier("FQ") as! FormQuestionViewController
                    self.presentViewController(secondViewController, animated: true, completion: nil)
        }
                else if(indexPath.row == 7)
                {
                    let secondViewController = self.storyboard?.instantiateViewControllerWithIdentifier("PO") as! ProgramOutputViewController
                    self.presentViewController(secondViewController, animated: true, completion: nil)
        }
                else if(indexPath.row == 8)
                {
                    let secondViewController = self.storyboard?.instantiateViewControllerWithIdentifier("OOO") as! OddOneOutViewController
                    self.presentViewController(secondViewController, animated: true, completion: nil)
        }
                else if(indexPath.row == 9)
                {
                    let secondViewController = self.storyboard?.instantiateViewControllerWithIdentifier("imageView") as! SituationQuestionTableViewController
                    self.presentViewController(secondViewController, animated: true, completion: nil)
        }

        }
    @IBAction func close(segue:UIStoryboardSegue)
    {
    
    }
}
