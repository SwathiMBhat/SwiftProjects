//
//  MCQ+CoreDataProperties.swift
//  TraningApp
//
//  Created by lakshmi r bhat on 14/06/16.
//  Copyright © 2016 basagond a mugganauar. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

import Foundation
import CoreData

extension MCQ {

    @NSManaged var question: String?
    @NSManaged var option1: String?
    @NSManaged var option2: String?
    @NSManaged var option3: String?
    @NSManaged var option4: String?
    @NSManaged var descrption: String?
    @NSManaged var answer: String?
    @NSManaged var noOfQue: String?

}
