//
//  OddOneOutQuesTableViewCell.swift
//  TrainingManagementApp
//
//  Created by vedashree k on 04/07/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import UIKit

class OddOneOutQuesTableViewCell: UITableViewCell {
    @IBOutlet weak var oooQuestionNumber: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        return 5
    }
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath:
        NSIndexPath) -> UITableViewCell {
        var cellIdentifier : String
        var cell = UITableViewCell()
        if indexPath.row == 0{
            cellIdentifier = "Cell1"
            cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier,forIndexPath: indexPath)
        }
        if indexPath.row == 1{
            cellIdentifier = "Cell2"
            cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier,forIndexPath: indexPath)
        }
        if indexPath.row == 2{
            cellIdentifier = "Cell3"
            tableView.selectRowAtIndexPath(indexPath, animated: true, scrollPosition: UITableViewScrollPosition.None)
            cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier,forIndexPath: indexPath)
        }
        if indexPath.row == 3{
            cellIdentifier = "Cell4"
            cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier,forIndexPath: indexPath)
        }
        if indexPath.row == 4{
            cellIdentifier = "Cell5"
            cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier,forIndexPath: indexPath)
        }
        
        return cell
}
}