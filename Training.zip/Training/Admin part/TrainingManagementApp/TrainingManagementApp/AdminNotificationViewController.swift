//
//  AdminNotificationViewController.swift
//  TrainingManagementApp
//
//  Created by medidi vv satyanarayana murty on 29/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import UIKit

class AdminNotificationViewController: UIViewController,UITableViewDelegate,UITableViewDataSource

    {

    @IBOutlet var mytableView: UITableView!
    
    var group = AdminSendRequestViewController()
    var images = ["stu1","stu2"]
    var names = ["Satyam","Basu","Rajesh"]
    
    var email = ["satyam@gmail.com","Basu@gmail.com","Rajesh@gmail.com"]
    @IBOutlet var sessionTime: UILabel!
    
    @IBOutlet var groupName: UITextField!
 
    
    @IBOutlet var task: UILabel!
   
   

   override func viewDidLoad()
    {
        super.viewDidLoad()
        mytableView.delegate = self
       mytableView.dataSource = self
    }

     override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int
    {
        return names.count
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return names.count
    }
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCellWithIdentifier("Cell") as! TrainersTableViewCell
         cell.notificationImage.image = UIImage(named: "stu1")
         cell.notificationLabel.text = names[indexPath.row]
         cell.notificationEmail.text = email[indexPath.row]
        
        
        return cell
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
