//
//  NotificationRequestToJoinViewController.swift
//  TrainingManagementApp
//
//  Created by manohara reddy p on 14/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import UIKit

class NotificationRequestToJoinViewController: UITableViewController {

    @IBOutlet weak var trainersCollectionView: UICollectionView!
    @IBOutlet weak var studentCollectionView: UICollectionView!
    
    let trainers = ["Ramesh","Suresh","satya narayana murthi","Manohara Reddy P"]
    
    let emailIdsTrainer = ["ramesh@gmail.com","Suresh@gmail.com","satya@gmail.com","Manohara@gmail.com"]
    let students = ["SowmyaShree Nanjappa","Ramesh Gouda","Suresh Gouda","Rahim","Ramesh","Suresh","satya narayana murthi","Manohara Reddy P","SowmyaShree Nanjappa","Ramesh Gouda","Suresh Gouda","Rahim","Ramesh","Suresh","satya narayana murthi","Manohara Reddy P"]
    
    let emailIdsstudents = ["SowmyaShreeNanjappa@gmail.com","RameshGouda@gmail.com","Suresh Gouda@gmail.com","Rahim@gmail.com","Ramesh@gmail.com","Suresh@gmail.com","satya narayanamurthi@gmail.com","ManoharaReddyP@gmail.com","SowmyaShree Nanjappa@gmail.com","RameshGouda@gmail.com","Suresh Gouda@gmail.com","Rahim@gmail.com","Ramesh@gmail.com","Suresh@gmail.com","satya narayanamurthi@gmail.com","ManoharaReddyP@gmail.com"]
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Request"
        trainersCollectionView.delegate = self
        trainersCollectionView.dataSource = self
        studentCollectionView.delegate = self
        studentCollectionView.dataSource = self
        let item = UIBarButtonItem(title: "Accept", style: .Plain, target: nil, action: nil)
        navigationItem.rightBarButtonItem = item
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
      
    }
 

}


extension NotificationRequestToJoinViewController:UICollectionViewDelegate,UICollectionViewDataSource
{
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        
        if collectionView.tag == 0
        {
            return trainers.count
        } else
        {
            return students.count
        }
        
    }
   
   func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell
   {
    
    
    if collectionView.tag == 0
    {
        let cell = collectionView.dequeueReusableCellWithReuseIdentifier("Trainer", forIndexPath: indexPath) as! TrainerCollectionViewCell
        cell.trainerName.text = trainers[indexPath.row]
         cell.trainerEmailId.text = emailIdsTrainer[indexPath.row]
        
        return cell
    } else
    {
       let cell = collectionView.dequeueReusableCellWithReuseIdentifier("Student", forIndexPath: indexPath) as! StudentCollectionViewCell
        
        cell.studentName.text = students[indexPath.row]
        cell.studentEmail.text = emailIdsstudents[indexPath.row]
        return cell
    }
   }
    
    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        switch  indexPath.section
        {
        case 0:
            return UITableViewAutomaticDimension
        case 1:
            return 35
        case 2 :
            return 71
        case  3 :
            return 264
        default:
            return 36
        }
       
    }
    
    override func tableView(tableView: UITableView, estimatedHeightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        
        switch  indexPath.section
        {
        case 1:
            return 35
        case 2 :
            return 71
        case  3 :
          return 264
        default:
            return 36
        }
    }
 
}