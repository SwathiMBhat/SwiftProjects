//
//  ParticipantsAdminTableViewCell.swift
//  TrainingManagementApp
//
//  Created by medidi vv satyanarayana murty on 24/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import UIKit

class ParticipantAdminTableViewCell: UITableViewCell
{
    
    @IBOutlet var adminParticipantImage: UIImageView!
    @IBOutlet var adminPArticipantName: UILabel!
    @IBOutlet var adminParticipantDesignation: UILabel!
    override func awakeFromNib()
    {
        super.awakeFromNib()
    }
    
    override func setSelected(selected: Bool, animated: Bool)
    {
        super.setSelected(selected, animated: animated)
        
        
    }
    
}
