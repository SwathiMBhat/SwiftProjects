//
//  Notification.swift
//  TrainingManagementApp
//
//  Created by manohara reddy p on 13/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import Foundation

enum NotificationType{
    case ScheduleForSession
    case RequestToJoin
    case DocumentShare
}

class Notification {

    let groupName:String
    let type:NotificationType
    let sender:String
    var setFavourite:Bool
    var description:String
    
    init(groupName:String,type:NotificationType,setFavourite:Bool,sender:String,description:String)
    { 
        self.groupName = groupName
        self.type = type
        self.setFavourite = setFavourite
        self.sender = sender
        self.description = description
    }
}