//
//  StudentAssessment.swift
//  TrainingManagementApp
//
//  Created by manohara reddy p on 22/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import Foundation

class StudentAssesment {
 
}