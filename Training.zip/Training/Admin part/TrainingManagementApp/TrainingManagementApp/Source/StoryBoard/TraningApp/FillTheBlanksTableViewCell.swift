//
//  FillTheBlanksTableViewCell.swift
//  TraningApp
//
//  Created by swathi m on 6/14/16.
//  Copyright © 2016 basagond a mugganauar. All rights reserved.
//

import UIKit

class FillTheBlanksTableViewCell: UITableViewCell {
    
    @IBOutlet var textPartOne: UILabel!
    
    @IBOutlet var textPartTwo: UILabel!
    
    @IBOutlet var textPartThree: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
