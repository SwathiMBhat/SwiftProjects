//
//  YesOrNoViewController.swift
//  TraningApp
//
//  Created by lakshmi r bhat on 15/06/16.
//  Copyright © 2016 basagond a mugganauar. All rights reserved.
//

import UIKit

class YesOrNoViewController: UIViewController {
    @IBOutlet var trueOrFalseLbls: [UILabel]!
    @IBOutlet var radioBtns: [RadioButton]!
    let checkedRadioImage = UIImage(named: "checkedRadio.png")! as UIImage
    let uncheckedRadioImage = UIImage(named: "uncheckedRadio.png")! as UIImage
    var coreData:CoreData?
    var answer = true
    var count = 0
    var ques : String = ""
    @IBOutlet weak var nextButton: UIButton!

    @IBOutlet weak var question: UITextView!
    
    @IBOutlet weak var trueButton: UIButton!
    
    @IBOutlet weak var falseButton: UIButton!
    
    @IBOutlet weak var descrption: UITextView!
    var qNum : String = ""
    @IBOutlet weak var queNumber: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        coreData=CoreData()
        reloadView()
        question.text = ques
        if ques != ""{
            nextButton.setTitle("save", forState: .Normal)
            queNumber.text = qNum
            if answer{
                radioBtns[0].isChecked = true
            }
            else{
                radioBtns[1].isChecked = true
            }
        }
        else{
            count = coreData!.fetch(String(FillInTheBlanks)).count + coreData!.fetch(String(YesNo)).count + coreData!.fetch(String(MCQ)).count + 1
            queNumber.text = String(count)
        }
        

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func clickToSave(sender: UIBarButtonItem) {
        let secondViewController = self.storyboard?.instantiateViewControllerWithIdentifier("listYN") as! YesNoListTableViewController
        self.presentViewController(secondViewController, animated: true, completion: nil)

    }
    @IBAction func selectAnswer(sender: RadioButton) {
        for button in radioBtns{
            if button != sender{
                if button.isChecked == true{
                    button.isChecked = false
                }
            }
            else{
                button.isChecked = !(button.isChecked)
            }
        }
        
    }
    @IBAction func nextAction(sender: UIButton) {
        if sender.titleLabel?.text != "save"{
            for i in 0..<radioBtns.count{
                if radioBtns[i].isChecked{
                    if(trueOrFalseLbls[i].text == "True"){
                        answer = true
                    }
                    else{
                        answer = false
                    }
                }
            }
            
            
            if question.text == "" {
                let alertController = UIAlertController(title: "Alert", message:
                    "Enter Question and options properly", preferredStyle: UIAlertControllerStyle.Alert)
                alertController.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.Default,
                    handler: nil))
                self.presentViewController(alertController, animated: true, completion: nil)
            }
            else{
                coreData?.insert(question.text, description: descrption.text! , answer: answer, queNum:queNumber.text!)
                
                reloadView()
                
            }
        }
        else{
            if question.text != ""{
                let yn = coreData?.createInstanceOfEntity(String(YesNo),qNum: qNum)
                (yn as! YesNo).queNum = qNum
                (yn as! YesNo).question = question.text
                for i in 0..<radioBtns.count{
                    if radioBtns[i].isChecked{
                        if(trueOrFalseLbls[i].text == "True"){
                            (yn as! YesNo).answer = true
                        }
                        else{
                            (yn as! YesNo).answer = false
                        }
                    }
                }
                coreData?.update(yn!,entityName: String(YesNo))
                
            }
        }
    }
    func reloadView(){
        trueButton.setImage(uncheckedRadioImage, forState: .Normal)
        falseButton.setImage(uncheckedRadioImage, forState: .Normal)
        question.text = nil
        descrption.text = nil
        count += 1
        queNumber.text = String(count)
        
    }
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "YesNoPreviewSegue" {
            let destinationController = segue.destinationViewController as! YesNoListTableViewController
            coreData?.fetchYesNoList()
            destinationController.yesNo = (coreData?.YesNoArray)!
        }
    }

    @IBAction func resetAction(sender: UIButton) {
        trueButton.setImage(uncheckedRadioImage, forState: .Normal)
        falseButton.setImage(uncheckedRadioImage, forState: .Normal)
        question.text = nil
        descrption.text = nil
    }
    
    
    @IBAction func backToYN(segue:UIStoryboardSegue)
    {
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
