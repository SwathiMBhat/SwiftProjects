//
//  OddOneOutViewController.swift
//  TraningApp
//
//  Created by vedashree k on 24/06/16.
//  Copyright © 2016 basagond a mugganauar. All rights reserved.
//

import UIKit

class OddOneOutViewController: UIViewController {
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var enterTextField: UITextField!
    var oddOneOutArray : [String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        print("true")
        oddOneOutArray.append(textField.text!)
        textField.text = ""
        tableView.reloadData()
       
        
        
        return true
    }
    
     @IBAction func resetAction(sender: UIButton) {
        oddOneOutArray.removeAll()
        tableView.reloadData()
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) ->
        Int {
            return oddOneOutArray.count
    }
    
    
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath:
        NSIndexPath) -> UITableViewCell {
        var cellIdentifier : String
        var cell = UITableViewCell()
        cellIdentifier = "Cell"
        cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier,forIndexPath: indexPath)
        (cell as! OddOneOutTableViewCell).orderLabel.text = String(indexPath.row + 1)
        (cell as! OddOneOutTableViewCell).wordLabel.text = oddOneOutArray[indexPath.row]
        
        return cell

}
    
    @IBAction func clickToSave(sender: UIBarButtonItem) {
        
        
        let alertView = UIAlertController(title: "Success", message: "Questions submitted successfully.", preferredStyle: .Alert)
        alertView.addAction(UIAlertAction(title: "OK", style: .Default, handler:nil))
        
        presentViewController(alertView, animated: true, completion: nil)
        
    }
}
