//
//  MCQListTableViewController.swift
//  TraningApp
//
//  Created by lakshmi r bhat on 14/06/16.
//  Copyright © 2016 basagond a mugganauar. All rights reserved.
//

import UIKit

class MCQListTableViewController: UITableViewController {
    var multiples:[MCQ] = []
    var coreData : CoreData?
//    override func viewDidLoad() {
//        super.viewDidLoad()
//
//        // Uncomment the following line to preserve selection between presentations
//        // self.clearsSelectionOnViewWillAppear = false
//
//        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
//        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
//    }
//
//    override func didReceiveMemoryWarning() {
//        super.didReceiveMemoryWarning()
//        // Dispose of any resources that can be recreated.
//    }
//
//    // MARK: - Table view data source
//
//    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
//        // #warning Incomplete implementation, return the number of sections
//        return 1
//    }
//
//    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        // #warning Incomplete implementation, return the number of rows
//        return multiples.count
//    }
//
//    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
//        let cellIdentifier = "Cell"
//        let cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier, forIndexPath: indexPath)
//        cell.textLabel?.text = multiples[indexPath.row].noOfQue! + ". " + multiples[indexPath.row].question!
//        cell.textLabel?.font = UIFont(name: (cell.textLabel?.font?.fontName)!, size: 18)
//        // Configure the cell...
//
//        return cell
//    }
//    @IBAction func close(segue:UIStoryboardSegue) {
//        
//    }
//    /*
//    // Override to support conditional editing of the table view.
//    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
//        // Return false if you do not want the specified item to be editable.
//        return true
//    }
//    */
//
//    /*
//    // Override to support editing the table view.
//    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
//        if editingStyle == .Delete {
//            // Delete the row from the data source
//            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
//        } else if editingStyle == .Insert {
//            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
//        }    
//    }
//    */
//
//    /*
//    // Override to support rearranging the table view.
//    override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {
//
//    }
//    */
//
//    /*
//    // Override to support conditional rearranging of the table view.
//    override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
//        // Return false if you do not want the item to be re-orderable.
//        return true
//    }
//    */
//
//    /*
//    // MARK: - Navigation
//
//    // In a storyboard-based application, you will often want to do a little preparation before navigation
//    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
//        // Get the new view controller using segue.destinationViewController.
//        // Pass the selected object to the new view controller.
//    }
//    */
//
//}







    let templates = ["1. My name is ? ", "2. Who is a apple CEO", "3. BCCI is which board", "4. Winner of IPL 9 is ?"]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // MARK: - Table view data source
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        
        return 1
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return templates.count
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let newData = ["Name", "Tim-Cook", "Indian Cricket","SRH"]
        let cell = tableView.dequeueReusableCellWithIdentifier("Cell", forIndexPath: indexPath)
        
        
        cell.textLabel?.text = templates[indexPath.row]
        let imageFilename = templates[indexPath.row].lowercaseString.stringByReplacingOccurrencesOfString(" ", withString: "_", options: [], range: nil)
        
        
        cell.imageView?.image = UIImage(named: imageFilename)
        cell.separatorInset.left = 20.0
        cell.separatorInset.right = 20.0
        cell.separatorInset.top = 50.0
        cell.separatorInset.bottom = 50.0
        cell.layer.cornerRadius = 20.0
        
//        let newLabel1 = UILabel(frame: CGRectMake(220.0, 30, 200.0, 15.0))
//        newLabel1.text = newData[indexPath.row]
//        newLabel1.font = newLabel1.font.fontWithSize(8)
//        newLabel1.tag = 1
//        newLabel1.textColor = UIColor.blueColor()
//        cell.addSubview(newLabel1)
//        
//        let newLabel2 = UILabel(frame: CGRectMake(160.0, 30, 200.0, 15.0))
//        newLabel2.text = newData[indexPath.row]
//        newLabel2.font = newLabel2.font.fontWithSize(8)
//        newLabel2.tag = 1
//        newLabel2.textColor = UIColor.redColor()
//        cell.addSubview(newLabel2)
//        
//        let newLabel3 = UILabel(frame: CGRectMake(100.0, 30, 200.0, 15.0))
//        newLabel3.text = newData[indexPath.row]
//        newLabel3.font = newLabel3.font.fontWithSize(8)
//        newLabel3.tag = 1
//        newLabel3.textColor = UIColor.blueColor()
//        cell.addSubview(newLabel3)
//        
//        let newLabel4 = UILabel(frame: CGRectMake(40.0, 30, 200.0, 15.0))
//        newLabel4.text = newData[indexPath.row]
//        newLabel4.font = newLabel4.font.fontWithSize(8)
//        newLabel4.tag = 1
//        newLabel4.textColor = UIColor.blueColor()
//        cell.addSubview(newLabel4)
        
        return cell
    }
    
    
    @IBAction func previewAction(sender: UIBarButtonItem) {
        let secondViewController = self.storyboard?.instantiateViewControllerWithIdentifier("Question") as! QuestionsViewController
        self.presentViewController(secondViewController, animated: true, completion: nil)
        
    }
    
    override func tableView(tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int) {
        
        let headerView = view as! UITableViewHeaderFooterView
        headerView.textLabel?.textColor = UIColor.orangeColor()
        headerView.textLabel?.font = UIFont(name: "Avenir", size: 25.0)
    }
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        let nextViewController = self.storyboard?.instantiateViewControllerWithIdentifier("editMCQ") as! MCQPreviewController
        self.presentViewController(nextViewController, animated: true, completion: nil)
    }
    @IBAction func clickToSave(sender: UIBarButtonItem) {
        
        
        let alertView = UIAlertController(title: "Success", message: "Questions submitted successfully.", preferredStyle: .Alert)
      
       
        alertView.addAction(UIAlertAction(title: "OK", style: .Default, handler:nil
//            {
//                [unowned self] (action) -> Void in
//                
//                let nextViewController = self.storyboard?.instantiateViewControllerWithIdentifier("Home") as! TemplatesTableViewController
//                self.presentViewController(nextViewController, animated: true, completion: nil)
    //        }
    ))

        presentViewController(alertView, animated: true, completion: nil)
        
           }
    @IBAction func backToListOfMCQ(segue:UIStoryboardSegue)
    {
        
    }
}

