//
//  YesNo+CoreDataProperties.swift
//  TraningApp
//
//  Created by lakshmi r bhat on 16/06/16.
//  Copyright © 2016 basagond a mugganauar. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

import Foundation
import CoreData

extension YesNo {

    @NSManaged var question: String?
    @NSManaged var descrption: String?
    @NSManaged var queNum: String?
    @NSManaged var answer: NSNumber?

}
