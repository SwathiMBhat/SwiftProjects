//
//  MyDocTableViewController.swift
//  TrainingManagementApp
//
//  Created by manohara reddy p on 17/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import UIKit

class MyDocTableViewController: UIViewController,UIPopoverPresentationControllerDelegate ,UISearchBarDelegate,UIDocumentInteractionControllerDelegate,Selected
{
    
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var docArray: UITableView!
    
    
    var docController = UIDocumentInteractionController()
    var docAry = [Document(docTypeImage:DocType.Pdf,docName:"JavaNotes.pdf",docSentDate:"12-9-2015",docSize:"40 MB",fromGroup:"Java",setFavourite:true,sender:"Rajendra"),Document(docTypeImage:DocType.voice,docName:"SwiftBook.pdf",docSentDate:"13-9-2015",docSize:"10 MB",fromGroup:"Swift",setFavourite:false,sender:"Surendra"),Document(docTypeImage:DocType.Image,docName:"JavaWorkFlow.png",docSentDate:"13-9-2015",docSize:"20 MB",fromGroup:"Java",setFavourite:true,sender:"Ramesh"),Document(docTypeImage:DocType.Image,docName:"Swift WorkFlow.png",docSentDate:"15-9-2015",docSize:"30 MB",fromGroup:"Java",setFavourite:false,sender:"Suresh"),Document(docTypeImage:DocType.Pdf,docName:"JavaNotes.pdf",docSentDate:"16-9-2015",docSize:"20 MB",fromGroup:"Java",setFavourite:true,sender:"Satyam")]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        searchBar.delegate = self
        docArray.delegate = self
        docArray.dataSource = self
        docController.delegate = self
    }
 
    
   func searchBar(searchBar: UISearchBar, shouldChangeTextInRange range: NSRange, replacementText text: String) -> Bool
   {
    if ((searchBar.text?.isEmpty) != nil)
    {
       docAry.sortInPlace({ (doc1,doc2) -> Bool in
        if doc1.fromGroup.containsString(searchBar.text!) ||
           doc1.docName.containsString(searchBar.text!) ||
           doc1.docSentDate.containsString(searchBar.text!) ||
           doc1.sender.containsString(searchBar.text!)
            {
             return true
            }
                 return false
            })
        docArray.reloadData()
        
    }
    return true
  }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    @IBAction func setFevouriteChanged(sender: UIButton) {
        
        if  docAry[sender.tag].setFavourite {
            docAry[sender.tag].setFavourite = false
            
        } else
        {
            docAry[sender.tag].setFavourite = true
        }
        docArray.reloadData()
    }
    // Document related deligate operations
    
  func documentInteractionControllerViewControllerForPreview(controller: UIDocumentInteractionController) -> UIViewController
    {
    return self
    }
    
    func documentInteractionControllerRectForPreview(controller: UIDocumentInteractionController) -> CGRect {
     return (docArray.cellForRowAtIndexPath(docArray.indexPathForSelectedRow!)?.frame)!
    }
 
    
    func documentInteractionControllerViewForPreview(controller: UIDocumentInteractionController) -> UIView? {
       return self.view
    }
    func value(selected:Int)
    {
        switch selected {
        case 0:
            docAry.sortInPlace({ (d1, d2) -> Bool in
              return d1.docName < d2.docName
            })
            
        case 1:
            docAry.sortInPlace({ (d1, d2) -> Bool in
                 return d1.sender < d2.sender
                })
            
                
        case 2:
                docAry.sortInPlace({ (d1, d2) -> Bool in
                    return d1.docSize < d2.docSize
                    })
        case 3:
            docAry.sortInPlace({ (d1, d2) -> Bool in
                return d1.docSentDate < d2.docSentDate
            })
            
        default:
            print("Error")
        }
        docArray.reloadData()
    }
    @IBAction func popoverToOrganize(sender: UIBarButtonItem) {
        
        let popupController = storyboard!.instantiateViewControllerWithIdentifier("popOver") as! PopUpViewController
        popupController.selected = self
        popupController.modalPresentationStyle = .Popover
        let y =   self.navigationController!.navigationBar.frame.height
        let x = (self.navigationController?.navigationBar.frame.width)! - 45
        popupController.preferredContentSize = CGSizeMake(150, 130)
        if let popoverController = popupController.popoverPresentationController {
            popoverController.sourceView = self.view as UIView
            popoverController.sourceRect = CGRectMake( x,y, 20, 20)
            popoverController.preferredContentSize
            popoverController.backgroundColor = UIColor.whiteColor()
            popoverController.permittedArrowDirections = .Up
            popoverController.delegate = self
            popupController.editing = false
        }
     presentViewController(popupController, animated: true, completion: nil)
        
    }
    func adaptivePresentationStyleForPresentationController(controller: UIPresentationController) -> UIModalPresentationStyle
    {
        return UIModalPresentationStyle.None
    }
}


extension MyDocTableViewController:UITableViewDelegate,UITableViewDataSource
{
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        
        return docAry.count
        
    }
    
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCellWithIdentifier("DocCell") as! MyDocTableViewCell
        
        
        switch docAry[indexPath.row].docTypeImage {
        case .Image:
            cell.docImage.image = UIImage(named: "Image")
        case .Pdf:
            cell.docImage.image = UIImage(named: "pdf-1.jpg")
        case .voice:
            cell.docImage.image = UIImage(named: "High Volume-40.png")
        }
        
        cell.docName.text = docAry[indexPath.row].docName
        cell.docSize.text = docAry[indexPath.row].docSize
        cell.docSharedGroupNameAndSender.text = "\(docAry[indexPath.row].fromGroup), \(docAry[indexPath.row].sender)"
        cell.docSharedDate.text = docAry[indexPath.row].docSentDate
        cell.setFavourite.tag = indexPath.row
        if docAry[indexPath.row].setFavourite {
          cell.setFavourite.setBackgroundImage(UIImage(named: "Selected"), forState: .Normal)
        } else {
            cell.setFavourite.setBackgroundImage(UIImage(named: "NotSelected"), forState: .Normal)
        }
        
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        let urlForPdf = NSBundle.mainBundle().URLForResource("iOS_Size_Class_Cheat_Sheet", withExtension: "pdf")
        let urlForImage = NSBundle.mainBundle().URLForResource("Screen Shot 2016-03-09 at 11.15.50 AM", withExtension: "png")
        if docAry[indexPath.row].docName.hasSuffix("pdf")
        {
            if let urlForPdf = urlForPdf
            {
                docController.URL = urlForPdf
            }
        }else
        {
            
            if let urlForImage = urlForImage
            {
                docController.URL = urlForImage
            }
        }
        docController.presentPreviewAnimated(true)
       // docController.presentOpenInMenuFromRect(cell.frame, inView: self.view, animated: true)
    }
    
    
    
}
