//
//  StudentArrayData.swift
//  TrainingManagementApp
//
//  Created by manohara reddy p on 22/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import Foundation



class StudentArrayData {
 
   static var documents:[StudentDocument] = [
        StudentDocument(docTypeImage:.Pdf, docName: "Objective-C.pdf", docSentDate:"11-02-2015", docSize:"20 Mb", sender: "Swathi"),
        StudentDocument(docTypeImage:.Image, docName: "ControlFlow", docSentDate:"11-02-2015", docSize:"30 Mb", sender: "Sowmya"),
        StudentDocument(docTypeImage:.Pdf, docName: "Properties.pdf", docSentDate:"12-02-2015", docSize:"4.1 Mb", sender: "Suresh"),
        StudentDocument(docTypeImage:.Image, docName: "Methods", docSentDate:"12-02-2015", docSize:"1.5 Mb", sender: "Ramesh"),
        StudentDocument(docTypeImage:.Image, docName: "Protocals", docSentDate:"13-02-2015", docSize:"15 Mb", sender: "You"),
        StudentDocument(docTypeImage:.Pdf, docName: "Generics.pdf", docSentDate:"13-02-2015", docSize:"1 Mb", sender: "Satyam"),
        StudentDocument(docTypeImage:.Image, docName: "Extensions", docSentDate:"13-02-2015", docSize:"2 Mb", sender: "Ramesh")
    ]
 
   static var participants:[StudentParticipant] = [
        
         StudentParticipant(name: "Ramesh", designation: "Trainer", image: "Person Male-48.png"),
         StudentParticipant(name: "Suresh", designation: "Student", image: "Person Male-50.png"),
         StudentParticipant(name: "Amit", designation: "Student", image: "Person Male-50.png"),
         StudentParticipant(name: "Rajeev", designation: "Trainer", image: "Person Male-48.png"),
         StudentParticipant(name: "Sowmya", designation: "Student", image: "Person Female-50.png"),
         StudentParticipant(name: "Vedha", designation: "Student", image: "Person Female-48.png"),
         StudentParticipant(name: "Basu", designation: "Trainer", image: "Person Male-50.png"),
         StudentParticipant(name: "Reddy", designation: "Student", image: "Person Male-48.png"),
    ]
   static var questions:[StudentQASession] = [
        
        StudentQASession(question: "What is the difference between the sequential and combinational circuits? and expanin in detail the differences with correct examples?.", sender:"Sowmya", sentdate: "11-02-2015"),
        StudentQASession(question: "Consider the following boolean function of four variables f(w,x,y,z)=Σ(1,3,4,6,911,12,14) the function is Independent of one variable Independent of two variables Independent of three variables Dependent on all variables.", sender:"Ramesh", sentdate: "12-02-2015"),
        StudentQASession(question: "The binary equivalent of the decimal number 42.75?. ", sender:"Swathi", sentdate: "13-02-2015"),
        StudentQASession(question: "What is digital logic?.", sender:"Suresh", sentdate: "13-02-2015"),
        StudentQASession(question: "Expanin in detail the differences with correct examples?.", sender:"Reddy", sentdate: "14-02-2015"),
        StudentQASession(question: "what is A+A'?.", sender:"You", sentdate: "15-02-2015"),
        StudentQASession(question: "What is the difference between the sequential and combinational circuits? and expanin in detail the differences with correct examples?.", sender:"Basu", sentdate: "16-02-2015")
    ]
   
}