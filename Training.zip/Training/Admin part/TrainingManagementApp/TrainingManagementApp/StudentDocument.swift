//
//  StudentDocument.swift
//  TrainingManagementApp
//
//  Created by manohara reddy p on 22/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import Foundation

class StudentDocument {
    
    let docTypeImage:DocType
    let docName:String
    let docSentDate:String
    let docSize:String
    let sender:String
    
    init(docTypeImage:DocType,docName:String,docSentDate:String,docSize:String,sender:String)
    {
        self.docTypeImage = docTypeImage
        self.docName = docName
        self.docSentDate = docSentDate
        self.docSize = docSize
        self.sender = sender
    }
    
}