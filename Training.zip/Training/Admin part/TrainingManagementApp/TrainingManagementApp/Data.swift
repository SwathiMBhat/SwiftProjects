//
//  Data.swift
//  TrainingManagementApp
//
//  Created by medidi vv satyanarayana murty on 23/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import Foundation

class Data
{
    static var members:[MemberData] =   [ MemberData(generalName:"Satyam",generalType: "Trainer",generalimage: "Trainer.png"),
                                          MemberData(generalName:"Rajesh",generalType: "Student",generalimage: "MaleStudent.png"),
                                          MemberData(generalName:"Basu  ",generalType: "Student",generalimage: "MaleStudent.png"),
                                          MemberData(generalName:"Rajesh",generalType: "Student",generalimage: "MaleStudent.png"),
                                        ]
    
    
    
    static var documents:[DocumentData] =    [
                                                DocumentData(genealNameT:"Swift",genealTypeT: "PDF", genealSizeT: "2MB",generalImage: .Pdf),
                                                DocumentData(genealNameT:"C",genealTypeT: "PPT", genealSizeT: "2MB",generalImage: .Pdf),
                                                DocumentData(genealNameT:"JAVA",genealTypeT: "PDF", genealSizeT: "2MB",generalImage: .Pdf),
                                                DocumentData(genealNameT:"CPP",genealTypeT: "PPT", genealSizeT: "2MB",generalImage: .Pdf),

                                            ]
    
    static var sessions:[SessionsNumbers] = [ SessionsNumbers(sessionNumber:"Session1",sessiontime: "9AM-11AM")]
    
                                                
    
    
    static var memberInfo:[MemberInformation] =    [
                                                        MemberInformation(TrainerName:"Satyam",TrainerEmail: "satyam@gmail.com",ParticipantName: "Participant-1",ParticipantEmail: "AAA@gmail.com"),
                                                        MemberInformation(TrainerName:"Rajesh",TrainerEmail: "Rajesh@gmail.com",ParticipantName: "Participant-2",ParticipantEmail: "BBB@gmail.com"),
                                                        MemberInformation(TrainerName:"Suresh",TrainerEmail: "Suresh@gmail.com",ParticipantName: "Participant-3",ParticipantEmail: "CCC@gmail.com")
        
                                                
                                            ]

}