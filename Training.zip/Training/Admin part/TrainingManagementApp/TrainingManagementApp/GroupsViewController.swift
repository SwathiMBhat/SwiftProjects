//
//  GroupsViewController.swift
//  TrainingManagementApp
//
//  Created by manohara reddy p on 13/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import UIKit

class GroupsViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    @IBOutlet weak var groupsNameTable: UITableView!
    
    
    var sssss = AdminGroupCreationTableViewController()
    var groupNames = ["Java","Objective-C","Swift"]
    var group = [String]()
    var roles = ["Admin","Student","Trainer","Admin","Admin","Admin","Admin","Admin","Admin","Admin","Admin","Admin"]
    var selectedRole:String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
     
                                 
        groupsNameTable.delegate = self
        groupsNameTable.dataSource = self
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
}

extension GroupsViewController
{
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return groupNames.count
        
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCellWithIdentifier("Cell")!
        cell.textLabel!.text = groupNames[indexPath.row]
        cell.detailTextLabel!.text = roles[indexPath.row]
        
                
        return cell
        
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        navigationItem.backBarButtonItem = UIBarButtonItem(title:"Back", style:.Plain, target: nil, action: nil)
        let cell = tableView.cellForRowAtIndexPath(indexPath)
        selectedRole = cell?.detailTextLabel?.text
        performSegueWithIdentifier("Trainer", sender: self)
    }
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "Trainer"
        {
            let viewController = segue.destinationViewController as! TrainerHomeTableViewController
            viewController.role = selectedRole
            
        }
        else
        {
           let viewController = segue.destinationViewController as! AdminSessionTableViewController
           self.performSegueWithIdentifier("Admin", sender: self)
        }
    }
    
    @IBAction func createGroup(sender: AnyObject)
   {
      // self.performSegueWithIdentifier("Admin", sender: self)
    
        let storyboard = UIStoryboard(name: "Admin", bundle: nil)
        let controller = storyboard.instantiateViewControllerWithIdentifier("GroupCreation")
        self.presentViewController(controller, animated: true, completion: nil)
        
    }
    
func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == UITableViewCellEditingStyle.Delete {
            groupNames.removeAtIndex(indexPath.row)
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: UITableViewRowAnimation.Automatic)
        }
    }
    @IBAction func DoneToGroups(segue:UIStoryboardSegue)
    {
        
    }
    @IBAction func CancelToGroups(segue:UIStoryboardSegue)
    {
        
    }
    @IBAction func backAssessments(segue:UIStoryboardSegue)
    {
        
        
        
    }
}
