//
//  GroupDetailedViewController.swift
//  TrainingManagementApp
//
//  Created by medidi vv satyanarayana murty on 24/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import UIKit

class GroupDetailedViewController: UIViewController,UITableViewDelegate,UISearchBarDelegate,UITableViewDataSource
    
{
    
    @IBOutlet var groupSegmentedControl: UISegmentedControl!
    @IBOutlet var groupTableView: UITableView!
    
    var memberData = Data.members
    var documentData = Data.documents
    var names = [String]()
    var size = [String]()
    
     var titleValue:String!
    
    var addMembers:UIBarButtonItem? = nil
    var addDoc :UIBarButtonItem? = nil
    var addAssessments :UIBarButtonItem? = nil
    var addQASession:UIBarButtonItem? = nil
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        title = titleValue
        
        groupTableView.delegate = self
        groupTableView.dataSource = self
        
        groupTableView.estimatedRowHeight = 50
        groupTableView.rowHeight = UITableViewAutomaticDimension
        
        
        addMembers = UIBarButtonItem(title: "+ Members", style: .Plain, target: self, action:
            #selector(GroupDetailedViewController.addMembersToGroup))
        
        addDoc = UIBarButtonItem(title: "+ Doc", style: .Plain, target: self, action:
            #selector(GroupDetailedViewController.addDocumentsToGroup))
        
        addAssessments = UIBarButtonItem(title: "+ Assessments", style: .Plain, target: self, action:
            #selector(GroupDetailedViewController.addAssessmentsToGroup))
        navigationItem.rightBarButtonItem = addMembers
        
        addQASession = UIBarButtonItem(title: "+QA",style: .Plain,target: self,action: #selector(GroupDetailedViewController.addQASessionToGroup))
        
    }
    
    //
    func addMembersToGroup()
    {
        performSegueWithIdentifier("AddMember", sender: self)
    }
    func addDocumentsToGroup()
    {
        performSegueWithIdentifier("AddDocuments", sender: self)
    }
    func addAssessmentsToGroup()
    {
       // performSegueWithIdentifier("AddAssessments", sender: self)
      //  performSegueWithIdentifier("AdminAssessment", sender: self)
        
        let storyboard = UIStoryboard(name: "MainAssessment", bundle: nil)
        let controller = storyboard.instantiateViewControllerWithIdentifier("Home")
        self.presentViewController(controller, animated: true, completion: nil)
    }
    func addQASessionToGroup()
    {
        //performSegueWithIdentifier("AddQA", sender: self)
        
//        let storyboard = UIStoryboard(name: "Trainer", bundle: nil)
//        let controller = storyboard.instantiateViewControllerWithIdentifier("AA")
//        self.presentViewController(controller, animated: true, completion: nil)
        
//        let cell = tableView.dequeueReusableCellWithIdentifier("QACell", forIndexPath: indexPath) as! QATableViewCell
//        
//        cell.question.text = qaArray[indexPath.row].question
//        cell.question.endEditing(true)
//        cell.by.text = "By: \( qaArray[indexPath.row].by!)"
//        cell.viewAnswer.titleLabel?.text = "Reply/View(\(qaArray[indexPath.row].numberOfAnswers!))"
//        return cell
    }
    
    
    
    @IBAction func add(sender: AnyObject)
    {
        switch (groupSegmentedControl.selectedSegmentIndex)
        {
        case 0:
            
            performSegueWithIdentifier("AddMember", sender: self)
        case 1:
            
            performSegueWithIdentifier("AddDocuments", sender: self)
        case 2:
            
            performSegueWithIdentifier("AddAssessments", sender: self)
        case 3:
            performSegueWithIdentifier("AddQA", sender: self)
            
        default:
            break
        }
    }
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        
    }
    
    @IBAction func groupSegmentedControl(sender: UISegmentedControl)
    {
        switch (groupSegmentedControl.selectedSegmentIndex)
        {
        case 0:
            
            navigationItem.rightBarButtonItem = addMembers
            
        case 1:
            
            navigationItem.rightBarButtonItem = addDoc
            
            
        case 2:
            
            navigationItem.rightBarButtonItem = addAssessments
        case 3:
            navigationItem.rightBarButtonItem = addQASession
            
        default:
            break
        }
        groupTableView.reloadData()
    }
    @IBAction func Close(segue:UIStoryboardSegue)
    {
        
    }
    
    @IBAction func cancelHome (segue:UIStoryboardSegue)
    {
        
    }
    //    func numberOfSectionsInTableView(tableView: UITableView) -> Int
    //    {
    //        return numberOfRowsForTable()
    //    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return numberOfRowsForTable()
        //var returnValue = 0
        //        switch (groupSegmentedControl.selectedSegmentIndex)
        //        {
        //        case 0:
        //            returnValue = members.count
        //            break
        //        case 1:
        //            returnValue = document.count
        //            break
        //
        //        default:
        //            break
        //        }
        //
        //        return returnValue
    }
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
        //        let cell = tableView.dequeueReusableCellWithIdentifier("cell") as! TrainersTableViewCell
        //        if groupSegmentedControl.selectedSegmentIndex == 0
        //        {
        //           // cell.generalName.text = members[indexPath.row]
        //           // cell.generalType.text = Role[indexPath.row]
        //            cell.generalimage.image = UIImage(named: "javaa")
        //            cell.genaralSize.hidden = true
        //
        //
        //        }
        //        else
        //        {
        //            cell.genaralSize.hidden = false
        //           // cell.generalName.text = document[indexPath.row]
        //          //  cell.generalType.text = documentType[indexPath.row]
        //          //  cell.genaralSize.text = docSize[indexPath.row]
        //            cell.generalimage.image = UIImage(named: "pdf")
        //
        //
        //        }
        //        return cell
        return homeCell(indexPath.row)
        
        
    }
    
    
    func homeCell(row:Int)->UITableViewCell
    {
        
        switch groupSegmentedControl.selectedSegmentIndex
        {
        case 0:
            let cell = groupTableView.dequeueReusableCellWithIdentifier("cell")as! TrainersTableViewCell
            
            if memberData[row].generalType == "Trainer"
            {
               // cell.generalType.textColor = UIColor.redColor()
            }
            else
            {
               // cell.generalType.textColor = UIColor.purpleColor()
            }
            cell.genaralSize.hidden = true
//            cell.generalName.text = memberData[row].generalName
//            cell.generalType.text = memberData[row].generalType
//            cell.generalimage.image = UIImage(named: memberData[row].generalimage)
            
            cell.generalName.hidden = true
            cell.generalType.hidden = true
            cell.generalimage.hidden = true
            
            return cell
            
        case 1:
            let cell = groupTableView.dequeueReusableCellWithIdentifier("cell2")as! TrainersTableViewCell
            
//           cell.generalNameT.text = documentData[row].genealNameT
//            cell.generalNameT.textColor = UIColor.redColor()
//            cell.generalTypet.text = documentData[row].genealTypeT
//            cell.generalTypet.textColor = UIColor.greenColor()
//            cell.generalSizeT.text = documentData[row].genealSizeT
//            cell.generalSizeT.textColor = UIColor.blueColor()
//            cell.generalImageT.image = UIImage(named: "PDFdoc.png")
             cell.generalNameT.hidden = true
            cell.generalTypet.hidden = true
            cell.generalSizeT.hidden = true
            cell.generalImageT.hidden = true
            
            return cell
        case 2:
            let cell = groupTableView.dequeueReusableCellWithIdentifier("cell2")as! TrainersTableViewCell
            cell.generalNameT.hidden = true
            cell.generalTypet.hidden = true
            cell.generalSizeT.hidden = true
            cell.generalImageT.hidden = true
            
            let storyboard = UIStoryboard(name: "MainAssessment", bundle: nil)
            let controller = storyboard.instantiateViewControllerWithIdentifier("Preview")
            self.presentViewController(controller, animated: true, completion: nil)
            
            // performSegueWithIdentifier("AdminAssessment", sender: self)
            
            return cell
            
        case 3:
            
            
            let cell = groupTableView.dequeueReusableCellWithIdentifier("cell2")as! TrainersTableViewCell
            cell.generalNameT.hidden = true
            cell.generalTypet.hidden = true
            cell.generalSizeT.hidden = true
            cell.generalImageT.hidden = true
            
//            let storyboard = UIStoryboard(name: "Trainer", bundle: nil)
//            let controller = storyboard.instantiateViewControllerWithIdentifier("A")
//            self.presentViewController(controller, animated: true, completion: nil)
            
          //  performSegueWithIdentifier("AddQA", sender: self)

            
          
            return cell
            
        default:
            let cell = groupTableView.dequeueReusableCellWithIdentifier("cell")as! TrainersTableViewCell
            return cell
            
            
        }
    }
    
    func numberOfRowsForTable()->Int
    {
        switch groupSegmentedControl.selectedSegmentIndex
        {
        case 1:
            return 1
        case 2:
            return memberData.count
        default:
            return documentData.count
        }
    }
    
    
    @IBAction func cancelToGroup(segue:UIStoryboardSegue)
    {
        
    }
    
    @IBAction func cancelTo(segue:UIStoryboardSegue)
    {
        
    }
    
    @IBAction func backAssessments(segue:UIStoryboardSegue)
    {
        
        
        
    }
    
}



