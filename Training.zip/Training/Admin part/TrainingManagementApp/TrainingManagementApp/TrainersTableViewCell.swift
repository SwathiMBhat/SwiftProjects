//
//  TrainersTableViewCell.swift
//  TrainingManagementApp
//
//  Created by medidi vv satyanarayana murty on 24/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import UIKit

class TrainersTableViewCell: UITableViewCell
{
    @IBOutlet var trainerImage: UIImageView!
    @IBOutlet var trainerRating: UIImageView!
    @IBOutlet var trainerName: UILabel!
    @IBOutlet var trainerDesig: UILabel!
    @IBOutlet var sendReqBtn: UIButton!
    
   
    @IBOutlet var notificationImage: UIImageView!
   
    @IBOutlet var notificationLabel: UILabel!
    
    @IBOutlet var notificationEmail: UILabel!
    @IBOutlet var role: UILabel!
    @IBOutlet var generalName: UILabel!
    @IBOutlet var generalType: UILabel!
    @IBOutlet var genaralSize: UILabel!
    @IBOutlet var generalimage: UIImageView!
    @IBOutlet var generalNameT: UILabel!
    @IBOutlet var generalSizeT: UILabel!
    @IBOutlet var generalTypet: UILabel!
    @IBOutlet var generalImageT: UIImageView!
    @IBOutlet var downLoadDoc: UIButton!
    
    @IBOutlet var pImage: UIImageView!
    @IBOutlet var pName: UILabel!
    @IBOutlet var pEmail: UILabel!
    @IBOutlet var pSendRequest: UIButton!
    
    @IBOutlet var secondImage: UIImageView!
    @IBOutlet var secondName: UILabel!
    @IBOutlet var secondType: UILabel!
    @IBOutlet var secondSize: UILabel!
    
    @IBOutlet var secongImageT: UIImageView!
    @IBOutlet var secondNameT: UILabel!
    
    
    @IBOutlet var sessionNumber: UILabel!
    @IBOutlet var sessionTime: UILabel!
    @IBOutlet var sessionCource: UILabel!
    @IBOutlet var sessionTrainer: UILabel!
    @IBOutlet var secondTypeT: UILabel!
    @IBOutlet var secondSizeT: UILabel!
   
   
   
    override func awakeFromNib()
    {
        super.awakeFromNib()
    }
    
    override func setSelected(selected: Bool, animated: Bool)
    {
        super.setSelected(selected, animated: animated)
        
        
        
        
    }
    
    @IBAction func downloadDoc(sender: AnyObject)
    {
        
        let bounds = self.downLoadDoc.bounds
        UIView.animateWithDuration(1.0, delay: 0.0, usingSpringWithDamping: 0.2, initialSpringVelocity: 5, options: [], animations:
            {
                self.downLoadDoc.bounds = CGRect(x: bounds.origin.x - 20, y: bounds.origin.y, width: bounds.size.width + 0.2, height: bounds.size.height)
                self.downLoadDoc.enabled = false
                
            }, completion: nil)
    }
    
    @IBAction func sendReqBtn(sender: AnyObject)
    {
        
        let bounds = self.sendReqBtn.bounds
        UIView.animateWithDuration(1.0, delay: 0.0, usingSpringWithDamping: 0.2, initialSpringVelocity: 20, options: [], animations: {
            self.sendReqBtn.bounds = CGRect(x: bounds.origin.x - 20, y: bounds.origin.y, width: bounds.size.width + 40, height: bounds.size.height)
            self.sendReqBtn.enabled = false
            self.sendReqBtn.backgroundColor = UIColor.greenColor()
            
            self.sendReqBtn.setTitle("Sent", forState: .Normal)
            
           
            }, completion: nil)
                
        }
    
    @IBAction func pSendRequest(sender: AnyObject)
    {
        let bounds = self.pSendRequest.bounds
        UIView.animateWithDuration(1.0, delay: 0.0, usingSpringWithDamping: 0.2, initialSpringVelocity: 20, options: [], animations: {
            self.pSendRequest.bounds = CGRect(x: bounds.origin.x - 20, y: bounds.origin.y, width: bounds.size.width + 40, height: bounds.size.height)
            self.pSendRequest.enabled = false
            self.pSendRequest.backgroundColor = UIColor.greenColor()
            
            self.pSendRequest.setTitle("Sent", forState: .Normal)
            
            
            }, completion: nil)

    }
    
    
}
