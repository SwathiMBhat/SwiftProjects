//
//  AddMaterialViewController.swift
//  TrainingManagementApp
//
//  Created by sowmyashree nanjappa on 22/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import UIKit

class AddMaterialViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {

    @IBOutlet var tableView: UITableView!
    var upload  = [AddMaterial]()
    var Multiple = 1
    var lastIndexPath:NSIndexPath?
    override func viewDidLoad() {
        super.viewDidLoad()
     tableView.dataSource = self
      tableView.delegate = self
        tableView.estimatedRowHeight = 160
        tableView.rowHeight = UITableViewAutomaticDimension
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
 
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return Multiple
    }
    
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
            let cell = tableView.dequeueReusableCellWithIdentifier("addCell", forIndexPath: indexPath) as! AddMaterialTableViewCell
        if upload.count > 0 && indexPath.row < upload.count
        {
            cell.fileName.text = upload[indexPath.row].fileName
            cell.fileDescription.text = upload[indexPath.row].fileDescription
            cell.fileLocation.text = upload[indexPath.row].fileLocation
        }
            lastIndexPath = indexPath
                return cell
           }
    
    @IBAction func AddMultiple(sender: UIBarButtonItem) {
        
        
        Multiple = Multiple + 1
        tableView.reloadData()
    }

    @IBAction func Upload(sender: UIButton) {
        let cell = tableView.cellForRowAtIndexPath(lastIndexPath!) as! AddMaterialTableViewCell
        upload.append(AddMaterial(fileName: cell.fileName.text!, fileDescription: cell.fileDescription.text!, fileLocation: cell.fileLocation.text!))
     
    }
    

}
