//
//  PostQuestionViewController.swift
//  TrainingManagementApp
//
//  Created by sowmyashree nanjappa on 23/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import UIKit
import UIKit

class PostQuestionViewController: UIViewController,UITextViewDelegate{
    
    @IBOutlet var postQuestion: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        postQuestion.layer.borderColor = UIColor.blueColor().CGColor
        postQuestion.layer.borderWidth = 2.0
        postQuestion.text = "Type your question?"
        postQuestion.textColor = UIColor.blackColor()
        postQuestion.delegate = self
        postQuestion.becomeFirstResponder()
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func textViewDidBeginEditing(textView: UITextView)
    {
        postQuestion.text = ""
        postQuestion.textColor = UIColor.blackColor()
        
    }
    
    @IBAction func postButton(sender: UIButton) {
        
        
        
    }
}

