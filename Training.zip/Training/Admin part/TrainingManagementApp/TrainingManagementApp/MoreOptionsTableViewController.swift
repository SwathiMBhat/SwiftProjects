//
//  MoreOptionsTableViewController.swift
//  TrainingManagementApp
//
//  Created by manohara reddy p on 13/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import UIKit

class MoreOptionsTableViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
      
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        
        switch indexPath.row {
        case 1:
             performSegueWithIdentifier("ViewProfile", sender: self)
        case 6:
        let alert = UIAlertController(title: "Logout", message:"Are u sure?", preferredStyle: .Alert)
         let yes = UIAlertAction(title: "Yes", style:.Default, handler:nil)
          let no = UIAlertAction(title: "No", style:.Cancel, handler: nil)
            alert.addAction(no)
            alert.addAction(yes)
        
            self.presentViewController(alert, animated: true , completion: nil)
        default:
            print("Error")
        }
        if indexPath.row == 1
        {
       
        }
        
        
        
    }
}
