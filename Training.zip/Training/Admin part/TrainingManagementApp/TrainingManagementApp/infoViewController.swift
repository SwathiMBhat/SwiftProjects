//
//  infoViewController.swift
//  TrainingManagementApp
//
//  Created by medidi vv satyanarayana murty on 21/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import UIKit

class infoViewController: UIViewController ,UITableViewDelegate,UITableViewDataSource
{

    @IBOutlet var downloadButton: UIButton!
    @IBOutlet var sendRequest: UIButton!
    @IBOutlet var rating: UIImageView!
    @IBOutlet var name: UILabel!
    @IBOutlet var mail: UILabel!
    @IBOutlet var phone: UILabel!
    @IBOutlet var infoImage: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
      
        

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func login(sender: UIButton)
    {
        let bounds = self.downloadButton.bounds
        UIView.animateWithDuration(1.0, delay: 0.0, usingSpringWithDamping: 0.2, initialSpringVelocity: 10, options: [], animations: {
            self.downloadButton.bounds = CGRect(x: bounds.origin.x - 20, y: bounds.origin.y, width: bounds.size.width + 60, height: bounds.size.height)
            self.downloadButton.enabled = false
            self.downloadButton.backgroundColor = UIColor.blueColor()
            }, completion: nil)
    }
 
    @IBAction func sendRequest(sender: UIButton)
    {
        let bounds = self.sendRequest.bounds
        UIView.animateWithDuration(1.0, delay: 0.0, usingSpringWithDamping: 0.2, initialSpringVelocity: 20, options: [], animations: {
            self.sendRequest.bounds = CGRect(x: bounds.origin.x - 20, y: bounds.origin.y, width: bounds.size.width + 20, height: bounds.size.height)
            self.sendRequest.enabled = false
            self.sendRequest.backgroundColor = UIColor.greenColor()
            self.sendRequest.setTitle("Sent", forState: .Normal)
                        
            }, completion: nil)
        
        
        
//        if self.sendRequest.titleLabel?.text == "Sent"
//        {
//            
//        }
     
       
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return 1
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int
    {
        return 1
    }
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
        
        let cell = tableView.dequeueReusableCellWithIdentifier("Trainers") as! TrainersTableViewCell
        
        
               return cell
        
    }

    
    

}
