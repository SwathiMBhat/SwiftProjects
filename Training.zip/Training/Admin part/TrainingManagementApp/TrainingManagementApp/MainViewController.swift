//
//  MainViewController.swift
//  TrainingManagementApp
//
//  Created by medidi vv satyanarayana murty on 24/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import UIKit

class MainViewController: UITableViewController
{
    var group = [String]()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        group = ["SWIFT", "JAVA","C", "C++"]
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return group.count
    }
    
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("member", forIndexPath: indexPath)
        
        
        
        cell.textLabel!.text = group[indexPath.row]
        
        return cell
    }
    
}
