//
//  StudentHomeTableViewController.swift
//  TrainingManagementApp
//
//  Created by manohara reddy p on 21/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import UIKit

class StudentHomeTableViewController: UIViewController{
    
    @IBOutlet weak var studentHomeTable: UITableView!
    
    @IBOutlet weak var switchSelection: UISegmentedControl!
     var barButtonItems:[UIBarButtonItem]!

    var docData  = StudentArrayData.documents
    var participantData = StudentArrayData.participants
    var quectionData = StudentArrayData.questions
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Objective-C"
        studentHomeTable.delegate = self
        studentHomeTable.dataSource = self
       barButtonItems =  navigationItem.rightBarButtonItems
      studentHomeTable.estimatedRowHeight =  44
      studentHomeTable.rowHeight = UITableViewAutomaticDimension
    }
  
    @IBAction func searchContent(sender: UIBarButtonItem) {
        print("searchDocuments")
    }
    @IBAction func addDocuments(sender: UIBarButtonItem) {
       print("Add Documents")
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func taskSegmentController(sender: UISegmentedControl) {
       
        if sender.selectedSegmentIndex == 0 {
            navigationItem.rightBarButtonItems = barButtonItems
        } else {
            navigationItem.rightBarButtonItems = nil
            navigationItem.rightBarButtonItem = barButtonItems[1]
        }
        studentHomeTable.reloadData()
    }
    

    func  configureCell(row:Int)->UITableViewCell {
        
        switch switchSelection.selectedSegmentIndex {
        case 1:
            let cell = studentHomeTable.dequeueReusableCellWithIdentifier("Assessments") as!
            AssesmentTableViewCell
          
            
            
            return cell
            
        case 2:
            let cell = studentHomeTable.dequeueReusableCellWithIdentifier("QASession") as!
            QASessionTableViewCell
            cell.question.text = quectionData[row].question
            cell.sender.text = "By: \(quectionData[row].sender)"
            cell.quectionAskedDate.text = quectionData[row].sentdate
            return cell
        case 3:
            let cell = studentHomeTable.dequeueReusableCellWithIdentifier("Participant") as!
            ParticipantStudentTableViewCell
            cell.designation.text = participantData[row].designation
            if participantData[row].designation == "Trainer"
            {
                cell.designation.textColor = UIColor.brownColor()
            } else
            {
                cell.designation.textColor = UIColor.blackColor()
            }
            cell.name.text = participantData[row].name
            cell.participantImage.image = UIImage(named: participantData[row].image)
            return cell
        default :
            let cell = studentHomeTable.dequeueReusableCellWithIdentifier("Document") as!
            DocArrayTableViewCell
            
            switch docData[row].docTypeImage {
            case .Pdf:
                cell.docImage.image = UIImage(named: "pdf.jpg")
            default:
                cell.docImage.image = UIImage(named: "Image")
            }
            
            cell.docName.text = docData[row].docName
            cell.docSender.text = "By: \(docData[row].sender)"
            cell.docSize.text = docData[row].docSize
            cell.sharedDate.text = docData[row].docSentDate
            
            return cell
        }
    
  }
    
    func numberOfRowsForTable()->Int
    {
        switch switchSelection.selectedSegmentIndex {
        case 1:
           return 5
        case 2:
           return quectionData.count
        case 3:
           return participantData.count
        default :
           return  docData.count
        }
        
    }

}

extension StudentHomeTableViewController:UITableViewDataSource,UITableViewDelegate
{
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return numberOfRowsForTable()
    }
   func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
   {
    return configureCell(indexPath.row)
   }
  
}





