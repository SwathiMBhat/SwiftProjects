//
//  ViewProfileViewController.swift
//  TrainingManagementApp
//
//  Created by manohara reddy p on 20/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import UIKit

class ViewProfileViewController: UITableViewController {

    var edit:UIBarButtonItem?
    var update:UIBarButtonItem?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Profile"
      edit = UIBarButtonItem(barButtonSystemItem:.Edit, target: self, action: #selector(ViewProfileViewController.editProfile))
     update = UIBarButtonItem(title:"Update", style:.Plain,target: self, action: #selector(ViewProfileViewController.UpdateProfile))
        navigationItem.rightBarButtonItem = edit
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
   func editProfile()
   {
   navigationItem.rightBarButtonItem = update
   // let selectedCell = tableView.cellForRowAtIndexPath(indexPath) as UITableViewCell!
    let selectedCells = tableView.visibleCells
    for selectedCell in selectedCells
    {
        for subViews in selectedCell.contentView.subviews {
            
            for subview in subViews.subviews
            {
                if subview is UITextField{
                  let textField =   subview as! UITextField
                   textField.enabled =  true
                    textField.borderStyle = .RoundedRect
                    if textField.tag == 1
                    {
                        textField.becomeFirstResponder()
                    }
                }
            }
        }
     }
   }
    
   func UpdateProfile()
   {
    
    navigationItem.rightBarButtonItem = edit
    let selectedCells = tableView.visibleCells
    for selectedCell in selectedCells
    {
        for subViews in selectedCell.contentView.subviews {
            
            for subview in subViews.subviews
            {
                if subview is UITextField{
                    let textField =   subview as! UITextField
                    textField.enabled =  false
                    textField.borderStyle = .None
                   
                }
            }
        }
    }
    
  let alert = UIAlertController(title: "Status", message: "Do u want update changes?", preferredStyle: .Alert)
    alert.addAction(UIAlertAction(title: "No", style:.Default, handler: nil))
    alert.addAction(UIAlertAction(title: "Yes", style:.Default, handler: nil))
  
    
    self.presentViewController(alert, animated: true, completion: nil)
    
   }
  
}
