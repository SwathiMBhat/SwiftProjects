//
//  MyDocTableViewCell.swift
//  TrainingManagementApp
//
//  Created by manohara reddy p on 17/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import UIKit

class MyDocTableViewCell: UITableViewCell {
    @IBOutlet weak var docSharedGroupNameAndSender: UILabel!
    @IBOutlet weak var docSize: UILabel!
    @IBOutlet weak var docSharedDate: UILabel!
    @IBOutlet weak var docName: UILabel!
    @IBOutlet weak var docImage: UIImageView!
    @IBOutlet weak var setFavourite: UIButton!
  
}
