//
//  SearchMembersViewController.swift
//  TrainingManagementApp
//
//  Created by medidi vv satyanarayana murty on 24/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import UIKit

class SearchMembersViewController: UIViewController,UITableViewDelegate,UISearchBarDelegate,UITableViewDataSource
{
    @IBOutlet var tableView: UITableView!
    @IBOutlet var searchBar: UISearchBar!
    @IBOutlet var segmentedControl: UISegmentedControl!
    @IBOutlet var sendReq: UIButton!
    
    
    @IBOutlet var image: UIImageView!
    var searchActive : Bool = false
    
    var  memberInformation = Data.memberInfo
   
    
    
    
    var images = ["student","pdf"]
    
    
    var designation = ["Trainer"]
    
    var filtered:[String] = []
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        tableView.delegate = self
        tableView.dataSource = self
        searchBar.delegate = self
        
    }
    func searchBarTextDidBeginEditing(searchBar: UISearchBar)
    {
        searchActive = true;
    }
    
    func searchBarTextDidEndEditing(searchBar: UISearchBar)
    {
        searchActive = false;
    }
    
    func searchBarCancelButtonClicked(searchBar: UISearchBar)
    {
        searchActive = false;
    }
    
    func searchBarSearchButtonClicked(searchBar: UISearchBar)
    {
        searchActive = false;
    }
    
    @IBAction func segmentedControlStateChange(sender: AnyObject)
    {
        tableView.reloadData()
        
    }
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        
    }
    
//    func searchBar(searchBar: UISearchBar, textDidChange searchText: String)
//    {
//        
//        filtered = ParticipantEmails.filter({ (text) -> Bool in
//            let tmp: NSString = text
//            let range = tmp.rangeOfString(searchText, options: NSStringCompareOptions.CaseInsensitiveSearch)
//            return range.location != NSNotFound
//        })
//        if(filtered.count == 0)
//        {
//            searchActive = false;
//        } else {
//            searchActive = true;
//        }
//        self.tableView.reloadData()
//    }
    
    
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int
    {
        return 2
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        if(searchActive)
        {
            return filtered.count
        }
        return memberInformation.count
        
        // return TrinersEmails.count
        var returnValue = 0
        switch (segmentedControl.selectedSegmentIndex)
        {
        case 0:
            returnValue = memberInformation.count
            //returnValue = TrainersNames.count
            break
        case 1:
           
            //returnValue = ParticipantNames.count
            returnValue = memberInformation.count
            break
            
        default:
            break
        }
        
        return returnValue
        
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
        
        
        
        if  segmentedControl.selectedSegmentIndex == 0
        {
            let cell = tableView.dequeueReusableCellWithIdentifier("Cell1") as! TrainersTableViewCell
            
            cell.trainerName.text = memberInformation[indexPath.row].TrainerName
            cell.trainerName.textColor = UIColor.blueColor()
            
            cell.trainerDesig.text = memberInformation[indexPath.row].TrainerEmail
            cell.trainerDesig.textColor = UIColor.blackColor()
            
            
            cell.trainerImage.layer.cornerRadius = cell.trainerImage.frame.size.width/2
            cell.trainerImage.clipsToBounds = true
            
            cell.trainerImage.image = UIImage(named: "Administrator")
            cell.trainerRating.hidden = false
            cell.trainerRating.image = UIImage(named: "aaa")
            return cell
            
        }
        else
        {
            let cell = tableView.dequeueReusableCellWithIdentifier("Cell2") as! TrainersTableViewCell
          
            cell.pName.text = memberInformation[indexPath.row].ParticipantName
            cell.pEmail.text = memberInformation[indexPath.row].ParticipantEmail
            cell.pImage.image = UIImage(named:  "MaleStudent")
           
             return cell
            
        }
        
        
        
    }
    
    
  
    
        
        
        
    @IBAction func CancelToSearchmember(segue:UIStoryboardSegue)
    {
        
    }
    
    
    
    
    @IBAction func Cancel(segue:UIStoryboardSegue)
    {
        
    }
    
    
}


