//
//  AdminSendRequestViewController.swift
//  TrainingManagementApp
//
//  Created by medidi vv satyanarayana murty on 29/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import UIKit

class AdminSendRequestViewController: UIViewController {

    @IBOutlet var groupName: UITextField!
    @IBOutlet var SessionTime: UITextField!
    @IBOutlet var task: UITextField!
    override func viewDidLoad()
    {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func sendRequest(sender: AnyObject)
    {
        let myAlert = UIAlertView()
        myAlert.title = "Title"
        myAlert.message = "Request Send Successfully"
        myAlert.addButtonWithTitle("Ok")
        
        myAlert.delegate = self
        myAlert.show()
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
