//
//  AddMaterial.swift
//  TrainingManagementApp
//
//  Created by sowmyashree nanjappa on 23/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import UIKit

class AddMaterial: NSObject {
    
    var fileName:String!
    var fileDescription:String!
    var fileLocation:String!
    init(fileName:String,fileDescription:String,fileLocation:String) {
        self.fileName = fileName
        self.fileDescription = fileDescription
        self.fileLocation = fileLocation
    }

}
