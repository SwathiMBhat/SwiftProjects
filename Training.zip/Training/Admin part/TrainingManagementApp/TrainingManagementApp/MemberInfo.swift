//
//  MemberInfo.swift
//  TrainingManagementApp
//
//  Created by medidi vv satyanarayana murty on 27/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import Foundation
class MemberInformation
{
    let TrainerName:String
    let TrainerEmail:String
    let ParticipantName:String
    let ParticipantEmail:String
    
    init (TrainerName:String,TrainerEmail:String,ParticipantName:String,ParticipantEmail:String)
    {
        self.TrainerName = TrainerName
        self.TrainerEmail  = TrainerEmail
        self.ParticipantName = ParticipantName
        self.ParticipantEmail = ParticipantEmail
    }
}