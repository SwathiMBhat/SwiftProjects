//
//  QATableViewCell.swift
//  TrainingManagementApp
//
//  Created by sowmyashree nanjappa on 14/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import UIKit

class QATableViewCell: UITableViewCell {

   
    @IBOutlet var question: UILabel!
    
    @IBOutlet var by: UILabel!
  
    @IBOutlet var viewAnswer: UIButton!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    

}
