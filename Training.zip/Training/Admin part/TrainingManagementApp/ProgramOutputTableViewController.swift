//
//  ProgramOutputTableViewController.swift
//  TraningApp
//
//  Created by swathi m on 6/16/16.
//  Copyright © 2016 basagond a mugganauar. All rights reserved.
//

import UIKit

class ProgramOutputTableViewController: UITableViewController {

    var programOutput:[ProgramOutput] = []
//    var coreData : CoreData?
    
//    override func viewDidLoad() {
//        super.viewDidLoad()
//
//        // Uncomment the following line to preserve selection between presentations
//        // self.clearsSelectionOnViewWillAppear = false
//
//        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
//        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
//    }
//
//    override func didReceiveMemoryWarning() {
//        super.didReceiveMemoryWarning()
//        // Dispose of any resources that can be recreated.
//    }
//
//    // MARK: - Table view data source
//
//    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
//        // #warning Incomplete implementation, return the number of sections
//        return 1
//    }
//
//    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        // #warning Incomplete implementation, return the number of rows
//        return programOutput.count
//    }
//
//    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
//        let cellIdentifier = "cell"
//        let cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier, forIndexPath: indexPath)
//        cell.textLabel?.text = programOutput[indexPath.row].questionNumber! + " . " + programOutput[indexPath.row].question!
//        
//        //  Configure the cell...
//        
//        return cell
//        
//    }
//
//    @IBAction func close(segue:UIStoryboardSegue) {
//        
//    }
//    /*
//    // Override to support conditional editing of the table view.
//    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
//        // Return false if you do not want the specified item to be editable.
//        return true
//    }
//    */
//
//    /*
//    // Override to support editing the table view.
//    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
//        if editingStyle == .Delete {
//            // Delete the row from the data source
//            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
//        } else if editingStyle == .Insert {
//            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
//        }    
//    }
//    */
//
//    /*
//    // Override to support rearranging the table view.
//    override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {
//
//    }
//    */
//
//    /*
//    // Override to support conditional rearranging of the table view.
//    override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
//        // Return false if you do not want the item to be re-orderable.
//        return true
//    }
//    */
//
//    /*
//    // MARK: - Navigation
//
//    // In a storyboard-based application, you will often want to do a little preparation before navigation
//    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
//        // Get the new view controller using segue.destinationViewController.
//        // Pass the selected object to the new view controller.
//    }
//    */
    
    let templates = ["1. Output of following code?", "2.find output?", "3. What will be the value of i?", "4. Program will compile successfully?"]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // MARK: - Table view data source
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        
        return 1
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return templates.count
    }
    
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let newData = ["Yes", "No", "No","Yes"]
        let cell = tableView.dequeueReusableCellWithIdentifier("Cell", forIndexPath: indexPath)
        
        
        cell.textLabel?.text = templates[indexPath.row]
        let imageFilename = templates[indexPath.row].lowercaseString.stringByReplacingOccurrencesOfString(" ", withString: "_", options: [], range: nil)
        
        
        cell.imageView?.image = UIImage(named: imageFilename)
        cell.separatorInset.left = 20.0
        cell.separatorInset.right = 20.0
        cell.separatorInset.top = 50.0
        cell.separatorInset.bottom = 50.0
        cell.layer.cornerRadius = 20.0
        
        cell.imageView!.clipsToBounds = true;
        cell.imageView!.layer.borderWidth = 2;
        
        cell.imageView!.layer.cornerRadius = 10;
        cell.imageView!.sizeToFit()
        var newLabel1 = UILabel(frame: CGRectMake(200.0, 35, 200.0, 15.0))
      //  newLabel1.text = newData[indexPath.row]
        newLabel1.tag = 1
        newLabel1.textColor = UIColor.redColor()
        cell.addSubview(newLabel1)
        
        return cell
    }
    
    
    @IBAction func previewAction(sender: UIBarButtonItem) {
        let secondViewController = self.storyboard?.instantiateViewControllerWithIdentifier("Question") as! QuestionsViewController
        self.presentViewController(secondViewController, animated: true, completion: nil)
        
    }
    
    override func tableView(tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int) {
        
        let headerView = view as! UITableViewHeaderFooterView
        headerView.textLabel?.textColor = UIColor.orangeColor()
        headerView.textLabel?.font = UIFont(name: "Avenir", size: 25.0)
    }
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        let nextViewController = self.storyboard?.instantiateViewControllerWithIdentifier("editPO") as! ProgramOutputPreviewController
        self.presentViewController(nextViewController, animated: true, completion: nil)
    }
    @IBAction func backToListOfFIB(segue:UIStoryboardSegue)
    {
        
    }
    
    @IBAction func backToListPO(segue:UIStoryboardSegue) {
        
    }
    @IBAction func clickToSave(sender: UIBarButtonItem) {
        
        
        let alertView = UIAlertController(title: "Success", message: "Questions submitted successfully.", preferredStyle: .Alert)
        alertView.addAction(UIAlertAction(title: "OK", style: .Default, handler:nil))
        
        presentViewController(alertView, animated: true, completion: nil)
        
    }}
