//
//  Material.swift
//  TrainingManagementApp
//
//  Created by sowmyashree nanjappa on 21/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import Foundation
class Material : NSObject
 {

    let title:String?
    let by:String?
    let date:String?
    let size:String?
    let image:String?
    init(title:String,by:String,date:String,size:String,image:String) {
        self.title = title
        self.by = by
        self.date = date
        self.size = size
        self.image = image
    }

}