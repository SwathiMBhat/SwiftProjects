//
//  CustomCollectionViewCell.swift
//  ImageDragging
//
//  Created by lakshmi r bhat on 22/06/16.
//  Copyright © 2016 Exilant. All rights reserved.
//

import UIKit

class CustomCollectionViewCell: UICollectionViewCell {
    @IBOutlet var imageView:UIImageView!
    var baseBackgroundColor : UIColor?

    var dragging : Bool = false {
        
        didSet {
            
            if dragging == true {
                
                self.baseBackgroundColor = self.backgroundColor
                self.backgroundColor = UIColor.clearColor()
                
            } else {
                
                self.backgroundColor = self.baseBackgroundColor
                
            }
        }
    }

}
