//
//  matchTheFollowingViewController.swift
//  TraningApp
//
//  Created by basagond a mugganauar on 09/06/16.
//  Copyright © 2016 basagond a mugganauar. All rights reserved.
//

import UIKit

class matchTheFollowingViewController: UIViewController, UIPopoverPresentationControllerDelegate {

    @IBOutlet var questionLBL: UITextField!
   
    @IBOutlet var a1optTXT: UITextField!
    @IBOutlet var a2optTXT: UITextField!
    @IBOutlet var b1optTXT: UITextField!
    @IBOutlet var b2optTXT: UITextField!
    @IBOutlet var c1optTXT: UITextField!
    @IBOutlet var c2optTXT: UITextField!
    @IBOutlet var d1optTXT: UITextField!
    @IBOutlet var d2optTXT: UITextField!
    
    @IBOutlet var questionNoLBL: UILabel!
    
//    var ans1Arrya:[String] = []
//    var ans2Arrya:[String] = []
    var no = 2
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func clickToGoBack(sender: UIButton) {
        self.performSegueWithIdentifier("unwindToViewController1", sender: self)
    }
    
    @IBAction func clickToGoNextQuestion(sender: UIButton) {
        nextQuestion()
    }
    @IBAction func clickToShowTheFormat(sender: UIButton) {
        
        
    }
//    @IBAction func clickToSave(sender: UIBarButtonItem) {
//        
//        let secondViewController = self.storyboard?.instantiateViewControllerWithIdentifier("Home") as! TemplatesTableViewController
//        self.presentViewController(secondViewController, animated: true, completion: nil)
//    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "popoverSegue" {
            let popoverViewController = segue.destinationViewController as! UIViewController
            popoverViewController.modalPresentationStyle = UIModalPresentationStyle.Popover
            popoverViewController.popoverPresentationController!.delegate = self
        }
    }

    func adaptivePresentationStyleForPresentationController(controller: UIPresentationController) -> UIModalPresentationStyle {
        return UIModalPresentationStyle.None
    }
    
    func nextQuestion()
    {
        questionLBL.text = "Question"
        
        questionLBL.text = ""
        questionLBL.placeholder = "Enter Next Question"
        
        a1optTXT.text = ""
        a2optTXT.text = ""
        a1optTXT.placeholder = "1"
        a2optTXT.placeholder = "1"
        
        b1optTXT.text = ""
        b2optTXT.text = ""
        b1optTXT.placeholder = "2"
        b2optTXT.placeholder = "2"

        
        c1optTXT.text = ""
        c2optTXT.text = ""
        c1optTXT.placeholder = "3"
        c2optTXT.placeholder = "3"

        
        d1optTXT.text = ""
        d2optTXT.text = ""
        d1optTXT.placeholder = "4"
        d2optTXT.placeholder = "4"

    }
    
    @IBAction func resetAction(sender: UIButton) {
        nextQuestion()
    }
    
    @IBAction func backToMTF(segue:UIStoryboardSegue)
    {
        
    }
    
   
}
