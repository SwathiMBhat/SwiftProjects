//
//  JumbledViewController.swift
//  StudentAssessment
//
//  Created by lakshmi r bhat on 28/06/16.
//  Copyright © 2016 varsha sambhajirao aware. All rights reserved.
//

import UIKit

class JumbledViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate, KDRearrangeableCollectionViewDelegate {
    
    var doodleImages = ["I keep on flapping my big ears all day.","They also fear that I will flip them all away.","But children wonder why I flap them so.","I flap them so to make sure they are in my mind", "But I know what I am doing.","Am I not a smart, intelligent elephant?"]
    @IBOutlet var collectionView:UICollectionView!
    @IBOutlet weak var collectionViewRearrangeableLayout: KDRearrangeableCollectionViewFlowLayout!
    
    var stickerImage:UIImage!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.collectionViewRearrangeableLayout.draggable = true
        
        self.collectionViewRearrangeableLayout.axis = .Free
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    //    @IBAction func handlePan(recognizer:UIPanGestureRecognizer) {
    //            if recognizer.state == UIGestureRecognizerState.Began || recognizer.state == UIGestureRecognizerState.Changed {
    //                let translation = recognizer.translationInView(self.view)
    //                recognizer.view!.center = CGPointMake(recognizer.view!.center.x + translation.x, recognizer.view!.center.y + translation.y)
    //                recognizer.setTranslation(CGPointMake(0,0), inView: self.view)
    //            }
    //        }
    
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection
        section: Int) -> Int {
        return doodleImages.count
    }
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath
        indexPath: NSIndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCellWithReuseIdentifier("CellReuse",
                                                                         forIndexPath: indexPath) as! JumbledCollectionViewCell
        cell.label.text = doodleImages[indexPath.row]
        return cell
    }
    func moveDataItem(fromIndexPath : NSIndexPath, toIndexPath: NSIndexPath) {
        
        let name = doodleImages[fromIndexPath.row]
        self.doodleImages.removeAtIndex(fromIndexPath.item)
        
        self.doodleImages.insert(name, atIndex: toIndexPath.item)
        
    }
}