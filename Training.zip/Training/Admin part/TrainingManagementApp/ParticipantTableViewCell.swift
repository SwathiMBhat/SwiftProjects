//
//  ParticipantTableViewCell.swift
//  TrainingManagementApp
//
//  Created by sowmyashree nanjappa on 14/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import UIKit

class ParticipantTableViewCell: UITableViewCell {


    @IBOutlet var mailId: UILabel!
    @IBOutlet var participantImage: UIImageView!
    @IBOutlet var role: UILabel!
    @IBOutlet var name: UILabel!
    
    @IBOutlet var chatimage: UIImageView!
    @IBOutlet var callImage: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
