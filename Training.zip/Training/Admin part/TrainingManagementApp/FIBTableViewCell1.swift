//
//  FIBTableViewCell.swift
//  TraningApp
//
//  Created by vedashree k on 16/06/16.
//  Copyright © 2016 basagond a mugganauar. All rights reserved.
//

import UIKit

class FIBTableViewCell1: UITableViewCell {
    @IBOutlet weak var fibAnswer: UILabel!
    @IBOutlet weak var fibQuestion: UILabel!
    @IBOutlet weak var fibQuestionNumber: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }

}
