//
//  SessionDetailedViewController.swift
//  TrainingManagementApp
//
//  Created by sowmyashree nanjappa on 22/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import UIKit

class SessionDetailedViewController: UIViewController ,UITableViewDataSource,UITableViewDelegate,UIPopoverPresentationControllerDelegate{

    
    @IBOutlet var tableView: UITableView!
    @IBOutlet var mainSegment: UISegmentedControl!
    var flag = true
    @IBOutlet var addButton: UIBarButtonItem!
     var role:String?
    @IBOutlet var postbutton: UIBarButtonItem!
    var documentArray:[Material] = [Material(title: "optionals.pdf", by: "sindu", date: "10-2-2015", size: "10 MB",image:"PDF"),Material(title: "array.pdf", by: "sanath", date: "10-12-2014", size: "10 MB",image:"PDF"),Material(title: "loops.pdf", by: "akshay", date: "11-9-2015", size: "12 MB",image:"PDF"),Material(title: "swift1.pdf", by: "sanjay", date: "10-8-2015", size: "14 MB",image:"PDF"),Material(title: "introduction.pdf", by: "saritha", date: "15-4-2015", size: "2 MB",image:"PDF"),Material(title: "swift_intro.pdf", by: "ajay", date: "1-2-2015", size: "11 MB",image:"PDF")]
    var assesmentArray:[Assesment] = [Assesment(title: "Level 1", date: "12-3-2016", time: "10 ", numberOfQuestion: 50 ),Assesment(title: "Level 2", date: "12-6-2016", time: "30", numberOfQuestion: 25 ),Assesment(title: "Level 3", date: "12-4-2016", time: "120", numberOfQuestion: 100 ),Assesment(title: "Level 4", date: "12-3-2015", time: "10", numberOfQuestion: 30),Assesment(title: "Level 5", date: "1-3-2016", time: "50", numberOfQuestion: 13 )]
    
    var qaArray : [QA] = [QA(question: "What is the difference between the sequential and combinational circuits? and expanin in detail the differences with correct examples?", by: "Ajay", numberOfAnswers: 4),QA(question: "Consider the following boolean function of four variables f(w,x,y,z)=Σ(1,3,4,6,911,12,14) the function is Independent of one variable Independent of two variables Independent of three variables Dependent on all variables?", by: "Anup", numberOfAnswers: 10),QA(question: "What is digital logic?", by: "Vijay", numberOfAnswers: 12),QA(question: "And expanin in detail the differences with correct examples?", by: "Arpith", numberOfAnswers: 12),QA(question: "What is A+A?", by: "Ashrith", numberOfAnswers: 12),]
    
    var participantArray :[Participant] = [Participant(name: "Anup", role: "Trainer", mailId: "anu_1@gmail.com",image:"Unknown-1",callImage: "Callback Filled-40",chatimage: "Message-40"),
                                           Participant(name: "Sushanth", role: "Trainer", mailId: "su_1@gmail.com",image:"",callImage: "Callback Filled-40",chatimage: "Message-40"),
                                           Participant(name: "Shanay", role: "Student", mailId: "shanay@gmail.com",image:"Unknown-1",callImage: "Callback Filled-40",chatimage: "Message-40"),
                                           Participant(name: "Jay", role: "Student", mailId: "jay134@gmail.com",image:"Unknown-1",callImage: "Callback Filled-40",chatimage: "Message-40"),
                                           Participant(name: "Karan", role: "Student", mailId: "kk1@gmail.com",image:"Unknown-1",callImage: "Callback Filled-40",chatimage: "Message-40"),
                                           Participant(name: "Zahid", role: "Student", mailId: "zahid@gmail.com",image:"Unknown-1",callImage: "Callback Filled-40",chatimage: "Message-40"),
                                           Participant(name: "Raj", role: "Student", mailId: "ray_raj@gmail.com",image:"Unknown-1",callImage: "Callback Filled-40",chatimage: "Message-40"),]
    var buttonArray : [UIBarButtonItem]!
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.delegate = self
        buttonArray = navigationItem.rightBarButtonItems
        print(buttonArray?.count)
        navigationItem.rightBarButtonItem = buttonArray[0]
        postbutton.tintColor = UIColor.clearColor()
        postbutton.enabled = true
        addButton.tintColor = UIColor.blueColor()
        addButton.enabled = true
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Table view data source
    
    @IBAction func SegmentSelectionChanged(sender: UISegmentedControl) {
        tableView.reloadData()
        
        if mainSegment.selectedSegmentIndex == 0
        {
            navigationItem.rightBarButtonItem = buttonArray[0]
            postbutton.tintColor = UIColor.clearColor()
            postbutton.enabled = true
            addButton.tintColor = UIColor.blueColor()
            addButton.enabled = true
            
        }
        else if mainSegment.selectedSegmentIndex == 1
        {
            
            if role != "Student"
            {
                navigationItem.rightBarButtonItem = buttonArray[0]
                postbutton.tintColor = UIColor.clearColor()
                postbutton.enabled = true
                addButton.tintColor = UIColor.blueColor()
                addButton.enabled = true
                
                
                
            }
            else
            {
                navigationItem.rightBarButtonItem = nil
                addButton.tintColor = UIColor.clearColor()
                addButton.enabled = false
                postbutton.tintColor = UIColor.clearColor()
                postbutton.enabled = false
                
                
                
            }
            
            
        }
            
        else  if mainSegment.selectedSegmentIndex == 2
        {
            navigationItem.rightBarButtonItem = buttonArray[1]
            
            tableView.estimatedRowHeight = 60.0
            tableView.rowHeight = UITableViewAutomaticDimension
            addButton.tintColor = UIColor.clearColor()
            addButton.enabled = true
            postbutton.tintColor = UIColor.blueColor()
            postbutton.enabled = true
        }
        else
        {
            if role != "Admin"
            {
                navigationItem.rightBarButtonItem = nil
            }
            else
            {
                navigationItem.rightBarButtonItem = buttonArray[0]
                postbutton.tintColor = UIColor.clearColor()
                postbutton.enabled = true
                addButton.tintColor = UIColor.blueColor()
                addButton.enabled = true
                
                
            }
        }
    }
     func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        if mainSegment.selectedSegmentIndex == 0
        {
            return documentArray.count
        }
        else if mainSegment.selectedSegmentIndex == 1
        {
            return  assesmentArray.count
            
        }
        else if mainSegment.selectedSegmentIndex == 2
        {
            return qaArray.count
            
        }
        else
        {
            
            return participantArray.count
            
        }
        
    }
    
    
     func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        if mainSegment.selectedSegmentIndex == 0
        {
            
            let cell = tableView.dequeueReusableCellWithIdentifier("MaterialCell", forIndexPath: indexPath) as! MaterialTableViewCell
            
            cell.title.text = documentArray[indexPath.row].title
            cell.date.text =  documentArray[indexPath.row].date
            cell.size.text =  documentArray[indexPath.row].size
            cell.postedBy.text = documentArray[indexPath.row].by
          
            cell.documentImage.image = UIImage(named: "PDF")
            return cell
        }
        else if mainSegment.selectedSegmentIndex == 1
        {
            let cell = tableView.dequeueReusableCellWithIdentifier("assesmentCell", forIndexPath: indexPath) as! AssesmentsTableViewCell
            
            cell.assesmentName.text = assesmentArray[indexPath.row].title
            cell.numberOfQuestions.text = "\(assesmentArray[indexPath.row].numberOfQuestion!) Questions"
            cell.date.text = assesmentArray[indexPath.row].date
            cell.time.text = "\(assesmentArray[indexPath.row].time!) minutes"
            
            
            return cell
        }
        else if mainSegment.selectedSegmentIndex == 2
        {
            let cell = tableView.dequeueReusableCellWithIdentifier("QACell", forIndexPath: indexPath) as! QATableViewCell
            
            cell.question.text = qaArray[indexPath.row].question
            cell.question.endEditing(true)
            cell.by.text = "By: \( qaArray[indexPath.row].by!)"
            cell.viewAnswer.titleLabel?.text = "Reply/View(\(qaArray[indexPath.row].numberOfAnswers!))"
            return cell
        }
            
            
        else
        {
            
            
            let cell = tableView.dequeueReusableCellWithIdentifier("ParticipantCell", forIndexPath: indexPath) as! ParticipantTableViewCell
            
            cell.participantImage.layer.cornerRadius = cell.participantImage.frame.size.width/2
            cell.participantImage.clipsToBounds = true
            cell.callImage.image = UIImage(named: "Callback Filled-40")
            cell.chatimage.image = UIImage(named: "Message-40")
            cell.participantImage.image = UIImage(named: "Unknown-1")
            cell.name.text = participantArray[indexPath.row].name
            cell.role.text = participantArray[indexPath.row].role
            cell.mailId.text = participantArray[indexPath.row].mailId!
            return cell
        }
    }
    
    //-----------------------------------------------------------
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath)
    {
        print("You selected cell #\(indexPath.row)!")

            if mainSegment.selectedSegmentIndex == 1
            {
                if role == "Trainer"
                {
                
                    let storyboard = UIStoryboard(name: "MainAssessment", bundle: nil)
                    let controller = storyboard.instantiateViewControllerWithIdentifier("Preview")
                    self.presentViewController(controller, animated: true, completion: nil)
                }
                else if role == "Student"
                {
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    let controller = storyboard.instantiateViewControllerWithIdentifier("StudentAssessment")
                    self.presentViewController(controller, animated: true, completion: nil)
                }
                else
                {
                    let storyboard = UIStoryboard(name: "MainAssessment", bundle: nil)
                    let controller = storyboard.instantiateViewControllerWithIdentifier("Preview")
                    self.presentViewController(controller, animated: true, completion: nil)
                }
            }
       
        

       
    }
    //-----------------------------------------------------------

    @IBAction func AddButton(sender: UIBarButtonItem) {
        if mainSegment.selectedSegmentIndex == 0
        {
            performSegueWithIdentifier("AddMaterial", sender: self)
        }
        else if mainSegment.selectedSegmentIndex == 1
        {
           
            
            let alert = UIAlertController(title: "New Level",
                                          message: "Level Details",
                                          preferredStyle: .Alert)
            
            let OkAction = UIAlertAction(title: "Ok",
                                         style: .Default,
                                         handler: { (action:UIAlertAction) -> Void in
                                            
                                            // let textField = alert.textFields!.first
                                            // self.session.append(textField!.text!)
                                            
                                            // let textField1 = alert.textFields?.first
                                            // self.session.append(textField1!.text!)
                                            
                                            //  self.tableView.reloadData()
                                        self.performSegueWithIdentifier("TrainerAssessment", sender: self)
                                  
                                            
            })
            
            
            
            let cancelAction = UIAlertAction(title: "Cancel",
                                             style: .Default) { (action: UIAlertAction) -> Void in
                                                
                                                
                                                
            }
            
            alert.addTextFieldWithConfigurationHandler
                {
                    (textField: UITextField) -> Void in
                    
                    textField.placeholder = "Level Type"
                    textField.textColor = UIColor.redColor()
                    
            }
            
            alert.addAction(OkAction)
            alert.addAction(cancelAction)
            
            presentViewController(alert,
                                  animated: true,
                                  completion:nil)
            
        }
        
           }
    @IBAction func postButton(sender: UIBarButtonItem) {
        
        if mainSegment.selectedSegmentIndex == 2
        {
            postQuestion()
        }

        
    }
    func adaptivePresentationStyleForPresentationController(controller: UIPresentationController) -> UIModalPresentationStyle
    {
        return UIModalPresentationStyle.None
    }
    func postQuestion(){
        let popupController = storyboard!.instantiateViewControllerWithIdentifier("PostQuestion") as! PostQuestionViewController
     
        popupController.modalPresentationStyle = .Popover
        let y =   self.navigationController!.navigationBar.frame.height
        let x = (self.navigationController?.navigationBar.frame.width)! - 45
        popupController.preferredContentSize = CGSizeMake(560, 160)
        if let popoverController = popupController.popoverPresentationController {
            popoverController.sourceView = self.view as UIView
            popoverController.sourceRect = CGRectMake( x,y, 20, 20)
            popoverController.preferredContentSize
            popoverController.backgroundColor = UIColor.whiteColor()
            popoverController.permittedArrowDirections = .Up
            popoverController.delegate = self
            popupController.editing = false
        }
        presentViewController(popupController, animated: true, completion: nil)
        
    }
   
    
    
    
    
    @IBAction func closeQA(segue:UIStoryboardSegue)
    {
        
        
        
    }
    
    @IBAction func closeAdd(segue:UIStoryboardSegue)
    {
        
        
        
    }
    
    @IBAction func closePost(segue:UIStoryboardSegue)
    {
        
        
        
    }
    @IBAction func backAssessments(segue:UIStoryboardSegue)
    {
        
        
        
    }
    

}
