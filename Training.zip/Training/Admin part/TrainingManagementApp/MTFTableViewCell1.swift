//
//  MTFTableViewCell.swift
//  TraningApp
//
//  Created by vedashree k on 16/06/16.
//  Copyright © 2016 basagond a mugganauar. All rights reserved.
//

import UIKit

class MTFTableViewCell1: UITableViewCell {
    @IBOutlet weak var colBAnswerA: UILabel!
    
    @IBOutlet weak var colBAnswerB: UILabel!
    @IBOutlet weak var colBAnswerC: UILabel!
    @IBOutlet weak var colBAnswerD: UILabel!
    
    @IBOutlet weak var colAQuestionB: UILabel!
    @IBOutlet weak var colAQuestionC: UILabel!
    @IBOutlet weak var colAQuestionD: UILabel!
    
    
    
    @IBOutlet weak var colAQuestionA: UILabel!
    @IBOutlet weak var mtfQuestion: UILabel!
    @IBOutlet weak var mtfQuestionNumber: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }

}
