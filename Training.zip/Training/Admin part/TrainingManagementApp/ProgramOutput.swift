//
//  ProgramOutput.swift
//  TraningApp
//
//  Created by swathi m on 6/16/16.
//  Copyright © 2016 basagond a mugganauar. All rights reserved.
//

import Foundation
import CoreData


class ProgramOutput: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
