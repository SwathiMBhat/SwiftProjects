//
//  QuestionsViewController.swift
//  TraningApp
//
//  Created by basagond a mugganauar on 24/06/16.
//  Copyright © 2016 basagond a mugganauar. All rights reserved.
//

import UIKit

class QuestionsViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    
    @IBOutlet var tableView: UITableView!
    var questions = ["1.Question", "2.Question", "3.Question","4.Question"]
    
    var questionDict = [String: [String]]()
    
    let questionType = ["MCQ","Fill in the blanks","Jumbles","Match the following","Program output","Give Opinion","Say YES or NO","Odd one out"]
        
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.delegate = self
        let longPressRecognizer = UILongPressGestureRecognizer(target: self, action: "longPress:")
        self.view.addGestureRecognizer(longPressRecognizer)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Table view data source
    
     func numberOfSectionsInTableView(tableView: UITableView) -> Int {
       
        return questionType.count
    }
    
     func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
             return questions.count
    }
    
     func tableView(tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return questionType[section]
    }
    
     func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let newData = ["1", "2", "3","4"]
        let cell = tableView.dequeueReusableCellWithIdentifier("Cell", forIndexPath: indexPath)
        
            cell.textLabel?.text = questions[indexPath.row]
            
            // Convert the animal name to lower case and
            // then replace all occurrences of a space with an underscore
            //let imageFilename = animalValues[indexPath.row].lowercaseString.stringByReplacingOccurrencesOfString(" ", withString: "_", options: [], range: nil)
            let num = newData[indexPath.row]
            //cell.imageView?.image = num as? UIImage//UIImage(named: imageFilename)
            cell.detailTextLabel?.text = num
            //            var newLabel1 = UILabel(frame: CGRectMake(280.0, 30, 200.0, 15.0))
            //            newLabel1.text = newData[indexPath.row]
            //            newLabel1.tag = 1
            //            cell.addSubview(newLabel1)
            //
            //            var newLabel2 = UILabel(frame: CGRectMake(230.0, 30, 200.0, 15.0))
            //            newLabel2.text = newData[indexPath.row]
            //            newLabel2.tag = 1
            //            cell.addSubview(newLabel2)
            //
            //            var newLabel3 = UILabel(frame: CGRectMake(180.0, 30, 200.0, 15.0))
            //            newLabel3.text = newData[indexPath.row]
            //            newLabel3.tag = 1
            //            cell.addSubview(newLabel3)
            //
            //            var newLabel4 = UILabel(frame: CGRectMake(130.0, 30, 200.0, 15.0))
            //            newLabel4.text = newData[indexPath.row]
            //            newLabel4.tag = 1
            //            cell.addSubview(newLabel4)
      
        
        
        return cell
    }
    
     func tableView(tableView: UITableView, sectionForSectionIndexTitle title: String, atIndex index: Int) -> Int {
        
        guard let index = questionType.indexOf(title) else {
            return -1
        }
        
        return index
    }
    
     func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        
        return 50
    }
    
     func tableView(tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int) {
        
        let headerView = view as! UITableViewHeaderFooterView
        headerView.textLabel?.textColor = UIColor.orangeColor()
        headerView.textLabel?.font = UIFont(name: "Avenir", size: 16.0)
    }
    
    }
//    
//     func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {
//        let itemToMove = questions[fromIndexPath.row]
//        questions.removeAtIndex(fromIndexPath.row)
//        questions.insert(itemToMove, atIndex: toIndexPath.row)
//        
//    }
//    
//    
//    
//    
//     func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
//        return true
//    }
//    
//    
//    
//    func longPress(longPressGestureRecognizer: UILongPressGestureRecognizer) {
//        
//        if longPressGestureRecognizer.state == UIGestureRecognizerState.Began {
//            
//            let touchPoint = longPressGestureRecognizer.locationInView(self.view)
//            if let indexPath = tableView.indexPathForRowAtPoint(touchPoint) {
//                self.editing = !self.editing
//                
//                // your code here, get the row for the indexPath or do whatever you want
//            }
//        }


//}

